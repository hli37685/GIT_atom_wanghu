#ifndef D3D_EFFECT_POOL_HEAD_FILE
#define D3D_EFFECT_POOL_HEAD_FILE
#pragma once


//////////////////////////////////////////////////////////////////////////////////

class CD3DEffectPool
{
public:
	CD3DEffectPool(void);
	virtual ~CD3DEffectPool(void);
};
