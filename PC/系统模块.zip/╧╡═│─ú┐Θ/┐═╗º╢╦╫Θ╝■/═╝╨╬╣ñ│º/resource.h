//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by FGuimfcFactory.rc
//
#define IDC_SKIN_CURSOR                 2000
#define IDI_SKIN_ICON                   2002
#define IDB_ENCIRCLE_TR                 2003
#define IDB_ENCIRCLE_BL                 2004
#define IDB_ENCIRCLE_BM                 2005
#define IDB_ENCIRCLE_BR                 2006
#define IDB_ENCIRCLE_ML                 2007
#define IDB_ENCIRCLE_MR                 2008
#define IDB_ENCIRCLE_TL                 2009
#define IDB_ENCIRCLE_TM                 2010
#define IDB_SKIN_BUTTON                 2011
#define IDB_SKIN_WND_MAX                2018
#define IDB_SKIN_WND_MIN                2019
#define IDB_SKIN_WND_RESORE             2020
#define IDB_SKIN_WND_RESTORE            2020
#define IDB_SKIN_COMBOBOX_BUTTON        2025
#define IDB_SKIN_MENU_FLAGS             2026
#define IDB_SKIN_HEADER_R               2027
#define IDB_SKIN_HEADER_L               2028
#define IDB_SKIN_HEADER_M               2029
#define IDB_SKIN_WND_CLOSE              2031
#define IDB_BITMAP1                     2032
#define IDB_SKIN_SCROLL                 2032
#define IDR_PNG1                        2033
#define IDR_PNG2                        2034
#define IDB_BITMAP2                     2039
#define IDB_SKIN_WND_BUTTON             2039

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        2040
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         2000
#define _APS_NEXT_SYMED_VALUE           2000
#endif
#endif
