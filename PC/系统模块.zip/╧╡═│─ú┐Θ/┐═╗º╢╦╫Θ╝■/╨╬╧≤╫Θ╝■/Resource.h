//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by AvatarControl.rc
//
#define IDC_HAND_CUR                    1010
#define IDC_VIDEO_WND                   2005
#define IDC_CAMERA_CONTROL              2005
#define IDC_STRING                      2008
#define IDC_STRING_CONTROL              2008
#define IDC_BT_REPEAT                   2010
#define IDC_BT_SAVE_EDIT                2011
#define IDB_IMAGE_CAMERA                2011
#define IDC_BT_CAMERA_DICT              2012
#define IDD_DLG_FACE_SELECT             3001
#define IDD_CAPTURE_VIDEO               3002
#define IDD_DLG_CAMERA                  3002
#define IDB_BT_FACE_BACK                4009

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        2012
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         2009
#define _APS_NEXT_SYMED_VALUE           2001
#endif
#endif
