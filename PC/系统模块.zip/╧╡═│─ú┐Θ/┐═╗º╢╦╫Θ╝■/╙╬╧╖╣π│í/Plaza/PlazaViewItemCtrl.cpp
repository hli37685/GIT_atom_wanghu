#include "StdAfx.h"
#include "GlobalUnits.h"
#include "PlazaViewItemCtrl.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


//////////////////////////////////////////////////////////////////////////////////
//��������
#define BUTTON_XOFFSET				12							//��ťƫ��

//////////////////////////////////////////////////////////////////////////////////

//��̬����
CLMTPlazaViewItemCtrl * CLMTPlazaViewItemCtrl::m_pPlazaViewItemCtrl=NULL;			//����ָ��

//�ؼ�����
//////////////////////////////////////////////////////////////////////////////////

//��ť�ؼ�
const TCHAR* const szButtonSearchControlName=TEXT("ButtonSearch");
const TCHAR* const szButtonCheckInControlName=TEXT("ButtonCheckIn");
const TCHAR* const szButtonSkinPeelerControlName=TEXT("ButtonSkinPeeler");
const TCHAR* const szButtonBaseEnsureControlName=TEXT("ButtonBaseEnsure");
const TCHAR* const szButtonCloseRoomControlName=TEXT("ButtonCloseRoom");
const TCHAR* const szButtonLockMachineControlName=TEXT("ButtonLockMachine");
const TCHAR* const szButtonSettingControlName=TEXT("ButtonSetting");

//////////////////////////////////////////////////////////////////////////////////

BEGIN_MESSAGE_MAP(CLMTPlazaViewItemCtrl, CFGuiWnd)

	//ϵͳ��Ϣ
	ON_WM_SIZE()
	ON_WM_SETCURSOR()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONUP()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONDBLCLK()
	ON_MESSAGE(WM_MOUSELEAVE,OnMouseLeave)

END_MESSAGE_MAP()

//////////////////////////////////////////////////////////////////////////////////

//���캯��
CLMTPlazaViewItemCtrl::CLMTPlazaViewItemCtrl()
{
	//���Ϣ
	m_bHovering=false;
	m_wItemDown=INVALID_WORD;
	m_wItemHover=INVALID_WORD;
	m_wItemActive=INVALID_WORD;

	//��Դ��Ϣ
	m_pIViewItemEvent=NULL;
	m_RectViewItem.SetRect(0,0,0,0);

	//���ö���
	ASSERT(m_pPlazaViewItemCtrl==NULL);
	if (m_pPlazaViewItemCtrl==NULL) m_pPlazaViewItemCtrl=this;

	//�����Դ
	tagEncircleResource	EncircleFrame;
	EncircleFrame.pszImageTL=MAKEINTRESOURCE(LMT_IDB_VIEW_TL);
	EncircleFrame.pszImageTM=MAKEINTRESOURCE(LMT_IDB_VIEW_TM);
	EncircleFrame.pszImageTR=MAKEINTRESOURCE(LMT_IDB_VIEW_TR);
	EncircleFrame.pszImageML=MAKEINTRESOURCE(LMT_IDB_VIEW_ML);
	EncircleFrame.pszImageMR=MAKEINTRESOURCE(LMT_IDB_VIEW_MR);
	EncircleFrame.pszImageBL=MAKEINTRESOURCE(LMT_IDB_VIEW_BL);
	EncircleFrame.pszImageBM=MAKEINTRESOURCE(LMT_IDB_VIEW_BM);
	EncircleFrame.pszImageBR=MAKEINTRESOURCE(LMT_IDB_VIEW_BR);
	m_FrameEncircle.InitEncircleResource(EncircleFrame,AfxGetInstanceHandle());

	//��ȡ��С
	CImage ItemButtonImage;
	ItemButtonImage.LoadFromResource(AfxGetInstanceHandle(),LMT_IDB_ITEM_BUTTON);
	m_SizeButton.SetSize(ItemButtonImage.GetWidth()/3,ItemButtonImage.GetHeight()/2);

	//������ɫ
	CSkinRenderManager * pSkinRenderManager=CSkinRenderManager::GetInstance();
	m_LinkBoradHSB=pSkinRenderManager->RGBToHSB(ItemButtonImage.GetPixel(2,m_SizeButton.cy*2-1));

	return;
}

//��������
CLMTPlazaViewItemCtrl::~CLMTPlazaViewItemCtrl()
{
	//���ö���
	ASSERT(m_pPlazaViewItemCtrl==this);
	if (m_pPlazaViewItemCtrl==this) m_pPlazaViewItemCtrl=NULL;

	//�ͷ���Դ
	for (INT_PTR i=0;i<m_ViewItemArray.GetCount();i++)
	{
		//��ȡ����
		ASSERT(m_ViewItemArray[i]!=NULL);
		SafeDelete(m_ViewItemArray[i]);
	}

	return;
}

//��Ϣ����
void CLMTPlazaViewItemCtrl::Notify(TNotifyUI &  msg)
{
	__super::Notify(msg);

	//��ȡ����
	CControlUI * pControlUI = msg.pSender;

	//����¼�
	if (lstrcmp(msg.sType,TEXT("click"))==0)
	{
		if (lstrcmp(pControlUI->GetName(),szButtonSkinPeelerControlName)==0) 
		{
			/*ASSERT(CGlobalUnits::GetInstance());
			CGlobalUnits::GetInstance()->PerformShowSkinPeeler();*/

			return;
		}
		else if (lstrcmp(pControlUI->GetName(),szButtonSearchControlName)==0)
		{
			ASSERT(CGlobalUnits::GetInstance());
			CGlobalUnits::GetInstance()->PerformShowSearchUser();

			return;
		}
		else if (lstrcmp(pControlUI->GetName(),szButtonCheckInControlName)==0)
		{
			ASSERT(CGlobalUnits::GetInstance());
			CGlobalUnits::GetInstance()->PerformShowCheckIn();

			return;
		}
		else if (lstrcmp(pControlUI->GetName(),szButtonBaseEnsureControlName)==0)
		{
			ASSERT(CGlobalUnits::GetInstance());
			CGlobalUnits::GetInstance()->PerformShowBaseEnsure();

			return;
		}
		else if (lstrcmp(pControlUI->GetName(),szButtonCloseRoomControlName)==0)
		{
			//�ر�����
			if ((m_wItemHover!=0L)&&(m_wItemHover!=INVALID_WORD))
			{
				tagViewItemInfo * pViewItemInfo=m_ViewItemArray[m_wItemHover];
				if (pViewItemInfo!=NULL) pViewItemInfo->pItemView->PostMessage(WM_COMMAND,IDM_DELETE_SERVER_ITEM,0L);
			}
			return;
		}
		else if (lstrcmp(pControlUI->GetName(),szButtonLockMachineControlName)==0)
		{
			ASSERT(CGlobalUnits::GetInstance());
			CGlobalUnits::GetInstance()->PerformShowLockMachine();

			return;
		}
		else if (lstrcmp(pControlUI->GetName(),szButtonSettingControlName)==0)
		{
			/*ASSERT(CGlobalUnits::GetInstance());
			CGlobalUnits::GetInstance()->PerformShowSystemSetup();*/

			return;
		}
	}
}

//��ʼ�滭
void CLMTPlazaViewItemCtrl::OnBeginPaintWindow(HDC hDC)
{
	//��ȡ�豸
	CDC * pDC=CDC::FromHandle(hDC);

	//��ȡλ��
	CRect rcClient;
	GetClientRect(&rcClient);

	//�滭���
	CRect rcFrame;
	rcFrame.top=0;
	rcFrame.left=0;
	rcFrame.right=rcClient.Width();
	rcFrame.bottom=rcClient.Height();
	m_FrameEncircle.DrawEncircleFrame(pDC,rcFrame);

	//������Ϣ
	tagEncircleInfo EncircleInfoFrame;
	m_FrameEncircle.GetEncircleInfo(EncircleInfoFrame);

	//������Դ
	CBitImage ItemButtonImage;
	ItemButtonImage.LoadFromResource(AfxGetInstanceHandle(),LMT_IDB_ITEM_BUTTON);

	//�滭����
	for (INT_PTR i=0;i<m_ViewItemArray.GetCount();i++)
	{
		//��������
		CPoint ImagePosion;
		ImagePosion.SetPoint(0,0);

		//��ȡ����
		ASSERT(m_ViewItemArray[i]!=NULL);
		tagViewItemInfo * pViewItemInfo=m_ViewItemArray[i];

		//����λ��
		if (m_wItemActive==i) ImagePosion.y=m_SizeButton.cy;

		//����λ��
		if (m_wItemDown==i) ImagePosion.x=m_SizeButton.cx;
		if ((m_wItemHover==i)&&(m_wItemDown!=i)) ImagePosion.x=m_SizeButton.cx*2;

		//�滭��ť
		CPoint PointButton(m_SizeButton.cx*i+BUTTON_XOFFSET,EncircleInfoFrame.nTBorder-m_SizeButton.cy+1);
		ItemButtonImage.BitBlt(hDC,PointButton.x,PointButton.y,m_SizeButton.cx,m_SizeButton.cy,ImagePosion.x,ImagePosion.y);

		//�滭����
		if (pViewItemInfo->szItemTitle[0]!=0)
		{
			//���û���			
			pDC->SetBkMode(TRANSPARENT);
			pDC->SelectObject(m_PaintManager.GetFont(5));
			pDC->SetTextColor((m_wItemActive==i)?RGB(0,0,0):RGB(255,255,255));

			//����λ��
			CRect rcItemText;
			rcItemText.top=PointButton.y+7;
			rcItemText.bottom=rcItemText.top+12;
			rcItemText.left=PointButton.x;
			rcItemText.right=rcItemText.left+m_SizeButton.cx;

			//�������
			INT nItemLen=lstrlen(pViewItemInfo->szItemTitle);
			DrawText(hDC,pViewItemInfo->szItemTitle,nItemLen,rcItemText,DT_SINGLELINE|DT_VCENTER|DT_CENTER|DT_END_ELLIPSIS);
		}

		//�滭ͼ��
		if (i==0)
		{
			CPngImage ImageHome;
			ImageHome.LoadImage(AfxGetInstanceHandle(),TEXT("PLAZA_HOME"));
			ImageHome.DrawImage(pDC,BUTTON_XOFFSET+12,10);
		}
	}
}

//��ȡ��С
VOID CLMTPlazaViewItemCtrl::GetViewItemSize(CSize & ResultSize)
{
	//���ñ���
	ResultSize.cy=m_SizeButton.cy;
	ResultSize.cx=m_SizeButton.cx*(m_ViewItemArray.GetCount());
	
	return;
}

//�滭�ν�
VOID CLMTPlazaViewItemCtrl::DrawLinkBoradLine(CWnd * pWnd, CDC * pDC)
{
	//�滭�ж�
	if (m_wItemActive==INVALID_WORD) return;
	if (m_ViewItemArray[m_wItemActive]->pItemView!=pWnd) return;

	//��ȡ����
	ASSERT(CSkinRenderManager::GetInstance()!=NULL);
	CSkinRenderManager * pSkinRenderManager=CSkinRenderManager::GetInstance();

	//�滭�ν�
	INT nXPos=m_wItemActive*m_SizeButton.cx+BUTTON_XOFFSET-6;
	pDC->FillSolidRect(nXPos,0,m_SizeButton.cx,1,RGB(26,122,195)/*pSkinRenderManager->RenderColor(m_LinkBoradHSB.S,m_LinkBoradHSB.B)*/);

	return;
}

//���ýӿ�
VOID CLMTPlazaViewItemCtrl::SetViewItemEvent(IViewItemEvent * pIViewItemEvent)
{
	//���ýӿ�
	m_pIViewItemEvent=pIViewItemEvent;

	return;
}

//��������
VOID CLMTPlazaViewItemCtrl::ActiveViewItem(CWnd * pItemView)
{
	//��������
	WORD wItemIndex=GetViewItemIndex(pItemView);
	
	//״̬�ж�
	ASSERT(wItemIndex!=INVALID_WORD);
	if (wItemIndex==INVALID_WORD) return;

	//���ÿؼ�
	CControlUI * pControlUI=NULL;
	bool bVisibleButton=wItemIndex==0;

	//���Ұ�ť
	pControlUI=GetControlByName(szButtonSearchControlName);
	if (pControlUI) pControlUI->SetVisible(bVisibleButton);

	//ǩ����ť
	pControlUI=GetControlByName(szButtonLockMachineControlName);
	if (pControlUI) pControlUI->SetVisible(bVisibleButton);

	//������ť
	pControlUI=GetControlByName(szButtonSkinPeelerControlName);
	if (pControlUI) pControlUI->SetVisible(bVisibleButton);

	//�ͱ���ť
	pControlUI=GetControlByName(szButtonSettingControlName);
	if (pControlUI) pControlUI->SetVisible(bVisibleButton);

	//����״̬
	if (m_wItemActive!=wItemIndex)
	{
		//��ǰ����
		tagViewItemInfo * pCurrentItem=NULL;
		if (m_wItemActive!=INVALID_WORD) pCurrentItem=m_ViewItemArray[m_wItemActive];

		//���ش���
		if (pCurrentItem!=NULL) pCurrentItem->pItemView->ShowWindow(SW_HIDE);

		//��ȡ����
		CRect rcClient;
		GetClientRect(&rcClient);

		//������Ϣ
		tagEncircleInfo EncircleInfoFrame;
		m_FrameEncircle.GetEncircleInfo(EncircleInfoFrame);

		//�����
		DWORD dwFlags=SWP_NOZORDER|SWP_SHOWWINDOW;
		pItemView->SetWindowPos(NULL,EncircleInfoFrame.nLBorder,EncircleInfoFrame.nTBorder,rcClient.Width()-EncircleInfoFrame.nLBorder-EncircleInfoFrame.nRBorder,rcClient.Height()-EncircleInfoFrame.nTBorder-EncircleInfoFrame.nBBorder,dwFlags);

		//�ػ�����
		pItemView->Invalidate(FALSE);

		//����״̬
		m_wItemActive=wItemIndex;

		//���´���
		RedrawWindow(NULL,NULL,RDW_INVALIDATE|RDW_ERASE|RDW_UPDATENOW|RDW_ERASENOW);

		//�¼�֪ͨ
		ASSERT(m_pIViewItemEvent!=NULL);
		if (m_pIViewItemEvent!=NULL) m_pIViewItemEvent->OnViewItemEvent(m_wItemActive,pItemView);

		//�滭��ť
		CPoint PointButton(m_SizeButton.cx*(m_wItemActive+1)+BUTTON_XOFFSET,EncircleInfoFrame.nTBorder-m_SizeButton.cy);

		pControlUI=GetControlByName(szButtonCloseRoomControlName);
		if (pControlUI==NULL) return;

		//if (m_wItemActive>0)
		//{
		//	pControlUI->SetVisible(true);
		//	pControlUI->SetPos(PointButton.x-28,PointButton.y+3);
		//}
		//else
		//{
		//	pControlUI->SetVisible(false);
		//}
	}

	return;
}

//ɾ������
VOID CLMTPlazaViewItemCtrl::RemoveViewItem(CWnd * pItemView)
{
	//Ч��״̬
	if (GetViewItemIndex(pItemView)==INVALID_WORD) return;
	if (m_ViewItemArray[GetViewItemIndex(pItemView)]==NULL) return;

	//��ȡ����
	WORD wItemIndex=GetViewItemIndex(pItemView);
	tagViewItemInfo * pViewItemInfo=m_ViewItemArray[wItemIndex];

	//ɾ������
	SafeDelete(pViewItemInfo);
	m_ViewItemArray.RemoveAt(wItemIndex);

	//��ǰ����
	if (m_wItemActive==wItemIndex) m_wItemActive=INVALID_WORD;
	if ((m_wItemActive!=INVALID_WORD)&&(m_wItemActive>wItemIndex)) m_wItemActive--;

	return;
}

//��������
VOID CLMTPlazaViewItemCtrl::InsertViewItem(CWnd * pItemView, LPCTSTR pszTitleImage)
{
	//�����ж�
	if (GetViewItemIndex(pItemView)!=INVALID_WORD) return;

	//��������
	tagViewItemInfo * pViewItemInfo=NULL;
	try
	{
		pViewItemInfo=new tagViewItemInfo;
		ZeroMemory(pViewItemInfo,sizeof(tagViewItemInfo));
	}
	catch (...)
	{
		ASSERT(FALSE);
		return;
	}

	//�������
	m_ViewItemArray.Add(pViewItemInfo);

	//���ñ���
	pItemView->SetParent(this);
	pViewItemInfo->pItemView=pItemView;
	lstrcpyn(pViewItemInfo->szItemTitle,pszTitleImage,CountArray(pViewItemInfo->szItemTitle));

	//����λ��
	WORD wItemCount=(WORD)m_ViewItemArray.GetCount();
	SetWindowPos(NULL,0,0,m_SizeButton.cx*wItemCount,m_SizeButton.cy,SWP_NOZORDER|SWP_NOMOVE);

	//�������
	ActiveViewItem(pItemView);

	return;
}

//��������
WORD CLMTPlazaViewItemCtrl::GetViewItemIndex(CPoint MousePoint)
{
	//������Ϣ
	tagEncircleInfo EncircleInfoFrame;
	m_FrameEncircle.GetEncircleInfo(EncircleInfoFrame);

	//�ж�Y����
	if (MousePoint.y<EncircleInfoFrame.nTBorder-m_SizeButton.cy || 
		MousePoint.y>EncircleInfoFrame.nTBorder)
	{
		return INVALID_WORD;
	}

	//�ж�X����
	if (MousePoint.x<BUTTON_XOFFSET)
	{
		return INVALID_WORD;
	}

	//��������
	WORD wItemIndex=(WORD)((MousePoint.x-BUTTON_XOFFSET)/m_SizeButton.cx);
	if (wItemIndex>=m_ViewItemArray.GetCount()) wItemIndex=INVALID_WORD;

	return wItemIndex;
}

//��������
WORD CLMTPlazaViewItemCtrl::GetViewItemIndex(CWnd * pItemView)
{
	//��������
	for (INT_PTR i=0;i<m_ViewItemArray.GetCount();i++)
	{
		if (m_ViewItemArray[i]->pItemView==pItemView)
		{
			return (WORD)i;
		}
	}

	return INVALID_WORD;
}

//λ����Ϣ
VOID CLMTPlazaViewItemCtrl::OnSize(UINT nType, INT cx, INT cy)
{
	__super::OnSize(nType,cx,cy);

	//��������
	if (m_wItemActive!=INVALID_WORD && cx>0 && cy>0)
	{
		//��ȡ����
		ASSERT(m_wItemActive<m_ViewItemArray.GetCount());
		tagViewItemInfo * pViewItemInfo=m_ViewItemArray[m_wItemActive];

		//������Ϣ
		tagEncircleInfo EncircleInfoFrame;
		m_FrameEncircle.GetEncircleInfo(EncircleInfoFrame);

		//����λ��
		if (pViewItemInfo->pItemView!=NULL)
		{
			DWORD dwFlags=SWP_NOZORDER|SWP_NOCOPYBITS|SWP_DEFERERASE;
			pViewItemInfo->pItemView->SetWindowPos(NULL,EncircleInfoFrame.nLBorder,EncircleInfoFrame.nTBorder,cx-EncircleInfoFrame.nLBorder-EncircleInfoFrame.nRBorder,cy-EncircleInfoFrame.nTBorder-EncircleInfoFrame.nBBorder,dwFlags);
		}
	}
}
//�����Ϣ
VOID CLMTPlazaViewItemCtrl::OnMouseMove(UINT nFlags, CPoint Point)
{
	__super::OnMouseMove(nFlags, Point);

	//����λ��
	CRect rcClient;
	GetClientRect(&rcClient);

	//λ�ü���
	WORD wItemHover=GetViewItemIndex(Point);

	//��������
	if (wItemHover!=m_wItemHover)
	{
		//���ñ���
		m_wItemHover=wItemHover;

		//���½���
		RedrawWindow(NULL,NULL,RDW_ERASE|RDW_UPDATENOW|RDW_INVALIDATE);
	}

	//�����ж�
	if (m_bHovering==false)
	{
		//���ñ���
		m_bHovering=true;

		//��������
		TRACKMOUSEEVENT TrackMouseEvent;
		ZeroMemory(&TrackMouseEvent,sizeof(TrackMouseEvent));

		//ע����Ϣ
		TrackMouseEvent.hwndTrack=m_hWnd;
		TrackMouseEvent.dwFlags=TME_LEAVE;
		TrackMouseEvent.dwHoverTime=HOVER_DEFAULT;
		TrackMouseEvent.cbSize=sizeof(TrackMouseEvent);

		//ע���¼�
		_TrackMouseEvent(&TrackMouseEvent);
	}

	return;
}

//�����Ϣ
VOID CLMTPlazaViewItemCtrl::OnLButtonUp(UINT nFlags, CPoint Point)
{
	__super::OnLButtonUp(nFlags,Point);

	//��������
	if ((m_wItemHover!=INVALID_WORD)&&(m_wItemHover==m_wItemDown))
	{
		tagViewItemInfo * pViewItemInfo=m_ViewItemArray[m_wItemHover];
		if (pViewItemInfo!=NULL) ActiveViewItem(pViewItemInfo->pItemView);
	}

	//������
	if (m_wItemDown!=INVALID_WORD)
	{
		//�ͷ����
		ReleaseCapture();

		//���ñ���
		m_wItemDown=INVALID_WORD;

		//���½���
		RedrawWindow(NULL,NULL,RDW_INVALIDATE|RDW_ERASE|RDW_UPDATENOW|RDW_ERASENOW);
	}

	return;
}

//�����Ϣ
VOID CLMTPlazaViewItemCtrl::OnLButtonDown(UINT nFlags, CPoint Point)
{
	__super::OnLButtonDown(nFlags,Point);

	//���ý���
	SetFocus();

	//���´���
	if (m_wItemHover!=INVALID_WORD)
	{
		//����˻�
		SetCapture();

		//���ñ���
		m_wItemDown=m_wItemHover;

		//���½���
		RedrawWindow(NULL,NULL,RDW_INVALIDATE|RDW_ERASE|RDW_UPDATENOW|RDW_ERASENOW);
	}

	return;
}

//���˫��
VOID CLMTPlazaViewItemCtrl::OnLButtonDblClk(UINT nFlags, CPoint Point)
{
	__super::OnLButtonDblClk(nFlags,Point);

	//�ر�����
	if ((m_wItemHover!=0L)&&(m_wItemHover!=INVALID_WORD))
	{
		tagViewItemInfo * pViewItemInfo=m_ViewItemArray[m_wItemHover];
		if (pViewItemInfo!=NULL) pViewItemInfo->pItemView->PostMessage(WM_COMMAND,IDM_DELETE_SERVER_ITEM,0L);
	}

	return;
}

//�����Ϣ
LRESULT CLMTPlazaViewItemCtrl::OnMouseLeave(WPARAM wParam, LPARAM lParam)
{
	//����״̬
	m_bHovering=false;

	//���½���
	if (m_wItemHover!=INVALID_WORD)
	{
		//���ñ���
		m_wItemHover=INVALID_WORD;

		//���½���
		RedrawWindow(NULL,NULL,RDW_INVALIDATE|RDW_ERASE|RDW_UPDATENOW|RDW_ERASENOW);
	}

	return 0;
}

//�����Ϣ
BOOL CLMTPlazaViewItemCtrl::OnSetCursor(CWnd * pWnd, UINT nHitTest, UINT uMessage)
{
	//���ù��
	if (m_wItemHover!=INVALID_WORD)
	{
		SetCursor(LoadCursor(AfxGetInstanceHandle(),MAKEINTRESOURCE(IDC_HAND_CUR)));
		return TRUE;
	}

	return __super::OnSetCursor(pWnd,nHitTest,uMessage);
}

//////////////////////////////////////////////////////////////////////////////////
