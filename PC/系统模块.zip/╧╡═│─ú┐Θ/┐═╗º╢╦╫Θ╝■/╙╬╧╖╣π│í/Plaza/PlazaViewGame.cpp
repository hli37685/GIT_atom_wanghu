#include "StdAfx.h"
#include "ExDispID.h"
#include "..\GamePlaza.h"
#include "..\Define.h"
#include "PlazaViewGame.h"
#include "PlatformFrame.h"


#include "..\FileIO\MyFileLog.h"
//////////////////////////////////////////////////////////////////////////////////

//Բ�Ǵ�С
#define ROUND_CX					12									//Բ�ǿ���
#define ROUND_CY					12									//Բ�Ǹ߶�

//��Ļλ��
#define LAYERED_SIZE				6									//�ֲ��С
#define CAPTION_SIZE				35									//�����С

//ʱ�Ӷ���
#define IDI_UPDATE_TIME				100									//����ʱ��
#define TIME_UPDATE_TIME			1000								//���¼��

//ʱ�Ӷ���
#define IDI_ZOOM_SUB_ITEM			100									//��������		
#define IDI_SWITCH_VIEW_PAGE		101									//����ҳ��

//ʱ�䶨��
#define TIME_ZOOM_SUB_ITEM			20									//����Ƶ��
#define TIME_SWITCH_PAGE			18									//����Ƶ��

//���ű���
#define KIND_ITEM_ZOOM_MAX  		3.0f								//��������
#define KIND_ITEM_ZOOM_MIN			1.0f								//��������

//�����
#define MATCH_COMMAND_SIGNUP		1									//��������
#define MATCH_COMMAND_UNSIGNUP		2									//ȡ������
#define MATCH_COMMAND_CHECKSCORE	3									//�鿴����
#define MATCH_COMMAND_INTRODUCE		4									//��������
#define MATCH_COMMAND_ENTER			5									//��������



//�ؼ���ʶ
#define IDC_WEB_PUBLICIZE			300									//����ؼ�



//////////////////////////////////////////////////////////////////////////////////

BEGIN_MESSAGE_MAP(CDlgMatchIntroduce, CFGuiDialog)
	//ϵͳ��Ϣ
	ON_WM_TIMER()
END_MESSAGE_MAP()

BEGIN_MESSAGE_MAP(CPlazaViewGame, CFGuiWnd)

	//ϵͳ��Ϣ
	ON_WM_SIZE()
	ON_WM_TIMER()

	ON_WM_CREATE()
	ON_WM_MOUSEWHEEL()
END_MESSAGE_MAP()

//////////////////////////////////////////////////////////////////////////////////
//��̬����
CStdString  CGameViewKindItem::m_ImageKindFrame=TEXT("file='KIND_FRAME' restype='PNG'");
CStdString  CGameViewKindItem::m_ImageKindHover=TEXT("file='KIND_HOVER' restype='PNG'");
CStdString  CGameViewKindItem::m_ImageUnSure=TEXT("file='KIND_UNSURE' restype='PNG'");
CStdString  CGameViewKindItem::m_ImageNameUnknown=TEXT("file='KIND_NAME_UNKNOWN' restype='PNG'");

//��̬����
CStdString  CGameViewServerItem::m_ImageHoverServer=TEXT("file='SERVER_HOVER' restype='PNG'");
CStdString  CGameViewServerItem::m_ImagePayloadStatus=TEXT("file='SERVER_NETSTATUS' restype='PNG'");

//��̬����
CStdString  CGameViewMatchItem::m_ImageHoverMatch=TEXT("file='SERVER_HOVER' restype='PNG'");

//////////////////////////////////////////////////////////////////////////////////
//�ؼ�����

//�����ؼ�
const TCHAR* const szContainerPageLayerControlName = TEXT("PageLayer");

//��ť�ؼ�
const TCHAR* const szButtonKindLeftControlName = TEXT("ButtonKindLeft");
const TCHAR* const szButtonKindRightControlName = TEXT("ButtonKindRight");

//////////////////////////////////////////////////////////////////////////////////
//���캯��
CDlgMatchIntroduce::CDlgMatchIntroduce(): CFGuiDialog(IDD_DLG_POPUP)
{
	//�������
	m_pbtQuit=NULL;

	//���ñ���
	m_pGameMatchInfo = NULL;

	//��������
	m_AwardFont.CreateFont(16,0,0,0,100,0,0,0,134,3,2,1,2,TEXT("����"));	
	m_RuleFont.CreateFont(14,0,0,0,100,0,0,0,134,3,2,1,2,TEXT("����"));	
}

//��������
CDlgMatchIntroduce::~CDlgMatchIntroduce()
{
	//������Դ
	if(m_AwardFont.GetSafeHandle()!=NULL)
	{
		m_AwardFont.DeleteObject();
	}

	//������Դ
	if(m_RuleFont.GetSafeHandle()!=NULL)
	{
		m_RuleFont.DeleteObject();
	}
}

//��Ϣ����
BOOL CDlgMatchIntroduce::PreTranslateMessage(MSG * pMsg)
{
	return __super::PreTranslateMessage(pMsg);
}

//��������
BOOL CDlgMatchIntroduce::OnInitDialog()
{
	__super::OnInitDialog();

	//������Դ
	HINSTANCE hInstance=GetModuleHandle(PLATFORM_RESOURCE_DLL_NAME);

	//����ͼ��
	m_ImageNumber.LoadImage(hInstance,TEXT("IMAGE_TIME_NUMBER"));
	
	//������Դ
	CPngImage ImageBack;
	ImageBack.LoadImage(hInstance,TEXT("DIALOG_MATCH_BACK"));

	//���ô�С
	CSize SizeWindow(ImageBack.GetWidth(),ImageBack.GetHeight());
	SetWindowPos(NULL,0,0,SizeWindow.cx,SizeWindow.cy,SWP_NOZORDER|SWP_NOMOVE|SWP_NOREDRAW);

	//��ȡ����
	CRect rctWindow;
	GetWindowRect(&rctWindow);

	//����λ��
	CRect rcUnLayered;
	rcUnLayered.top=LAYERED_SIZE;
	rcUnLayered.left=LAYERED_SIZE;
	rcUnLayered.right=rctWindow.Width()-LAYERED_SIZE;
	rcUnLayered.bottom=rctWindow.Height()-LAYERED_SIZE;

	//��������
	CRgn RgnWindow;
	RgnWindow.CreateRoundRectRgn(LAYERED_SIZE,LAYERED_SIZE,SizeWindow.cx-LAYERED_SIZE+1,SizeWindow.cy-LAYERED_SIZE+1,ROUND_CX,ROUND_CY);

	//��������
	SetWindowRgn(RgnWindow,FALSE);

	//�ֲ㴰��
	m_SkinLayered.CreateLayered(m_hWnd);
	m_SkinLayered.InitLayeredArea(ImageBack,255,rcUnLayered,CPoint(ROUND_CX,ROUND_CY),false);

	return TRUE;
}

//ȡ����Ϣ
VOID CDlgMatchIntroduce::OnCancel()
{
	//���ش���
	ShowWindow(SW_HIDE);

	//�رն�ʱ��
	KillTimer(IDI_UPDATE_TIME);
}

//��ʼ�滭
void CDlgMatchIntroduce::OnBeginPaintWindow(HDC hDC)
{
	//��ȡ�豸
	CDC * pDC = CDC::FromHandle(hDC);

	//��ȡλ��
	CRect rctClient;
	GetClientRect(&rctClient);

	//���û���
	pDC->SetBkMode(TRANSPARENT);
	pDC->SelectObject(m_AwardFont);

	//������Դ
	CPngImage ImageBack;
	ImageBack.LoadImage(GetModuleHandle(PLATFORM_RESOURCE_DLL_NAME),TEXT("DIALOG_MATCH_BACK"));

	//�滭����
	ImageBack.DrawImage(pDC,0,0);

	//��ȡ����
	tagGameMatch GameMatch = m_pGameMatchInfo->pGameServerItem->m_GameMatch;

	//��������
	SYSTEMTIME StartTime;	
	CTime CurrentTime = CTime::GetCurrentTime();		
	StartTime = GameMatch.MatchStartTime;

	//����ʱ���
	DWORD dwCurrentStamp = CurrentTime.GetHour()*3600+CurrentTime.GetMinute()*60+CurrentTime.GetSecond();
	DWORD dwStartStamp = StartTime.wHour*3600+StartTime.wMinute*60+StartTime.wSecond;
	DWORD dwDiffStemp = dwStartStamp>dwCurrentStamp?dwStartStamp-dwCurrentStamp:0;

	//����ʱ��
	DWORD wDiffHour = dwDiffStemp/3600;
	DWORD wDiffMinute = (dwDiffStemp-wDiffHour*3600)/60;
	DWORD wDiffSecond = dwDiffStemp-wDiffHour*3600-wDiffMinute*60;

	//��������
	DrawNumber(pDC,207,68,&m_ImageNumber,TEXT("0123456789"),wDiffHour,TEXT("%02d"));
	DrawNumber(pDC,295,68,&m_ImageNumber,TEXT("0123456789"),wDiffMinute,TEXT("%02d"));
	DrawNumber(pDC,380,68,&m_ImageNumber,TEXT("0123456789"),wDiffSecond,TEXT("%02d"));

	//���û���
	pDC->SetTextColor(RGB(160,53,0));

	//��������
	CRect rcMatchAward(108,238,462,258);
	for(INT_PTR nIndex=0;nIndex<m_strAwardArray.GetCount();nIndex++)
	{		
		pDC->DrawText(m_strAwardArray[nIndex],rcMatchAward,DT_LEFT|DT_VCENTER|DT_SINGLELINE|DT_END_ELLIPSIS);		
		rcMatchAward.OffsetRect(0,24);
	}	

	//���û���
	pDC->SelectObject(m_RuleFont);
	pDC->SetTextColor(RGB(0,0,0));

	//��������
	CRect rcMatchContent(108,130,484,228);
	TCHAR szMatchContent[532]=TEXT("");	
	/*_sntprintf(szMatchContent,CountArray(szMatchContent),TEXT("%s"),GameMatch.szMatchContent);
	pDC->DrawText(szMatchContent,rcMatchContent,DT_LEFT|DT_VCENTER|DT_WORDBREAK|DT_END_ELLIPSIS);*/	

	return;
}

//��ʼ�ؼ�
void CDlgMatchIntroduce::InitControlUI()
{
	//���ñ�������
	m_PaintManager.SetCaptionRect(CRect(0,0,0,CAPTION_SIZE));

	//��ȡ����
	CContainerUI * pParent = static_cast<CContainerUI *>(m_PaintManager.GetRoot());

	//�˳���ť
	m_pbtQuit = CButtonUI::Create(&m_PaintManager,pParent,TEXT(""));
	m_pbtQuit->SetStatusImage(TEXT("file='BT_MATCH_CLOSE' restype='PNG'"));
	m_pbtQuit->SetPos(470,10);
}

//��Ϣ����
void CDlgMatchIntroduce::Notify(TNotifyUI &  msg)
{
	//��ȡ����
	CControlUI * pControlUI = msg.pSender;

	//����¼�
	if (lstrcmp(msg.sType, TEXT("click")) == 0)
	{
		if(m_pbtQuit==pControlUI) return OnCancel();			
	}
}

//������Ϣ
VOID CDlgMatchIntroduce::SetGameMatchInfo(tagGameMatchInfo * pGameMatchInfo)
{
	//����У��
	if(pGameMatchInfo==NULL) return;
	if(m_pGameMatchInfo==pGameMatchInfo) return;

	//���ñ���
	m_strAwardArray.RemoveAll();
	m_pGameMatchInfo=pGameMatchInfo;

	//��ȡ����
	/*CString strAwardContent(m_pGameMatchInfo->pGameServerItem->m_GameMatch.szMatchAwardContent);
	INT nPos = strAwardContent.Find(TEXT(';'));
	while(nPos>0)
	{
		m_strAwardArray.Add(strAwardContent.Left(nPos));
		strAwardContent.Delete(0,nPos+1);
		nPos = strAwardContent.Find(TEXT(';'));
	}*/

	//if(strAwardContent.GetLength()>0) m_strAwardArray.Add(strAwardContent);
}

//��ʾ����
VOID CDlgMatchIntroduce::ShowMatchIntroduce()
{
	//���ö�ʱ��
	SetTimer(IDI_UPDATE_TIME,TIME_UPDATE_TIME,NULL);

	//��ʾ����
	ShowWindow(SW_SHOW);
}

//��������
VOID CDlgMatchIntroduce::DrawNumber(CDC * pDC,INT nXPos,INT nYPos,CPngImage * pNumberImage,LPCTSTR pszNumber,INT nNumber,LPCTSTR pszFormat,UINT nFormat)
{
	//����У��
	if(pNumberImage==NULL) return;

	//��������
	CString strNumber(pszNumber);
	CSize SizeNumber(pNumberImage->GetWidth()/strNumber.GetLength(),pNumberImage->GetHeight());

	//��������	
	TCHAR szValue[32]=TEXT("");
	_sntprintf(szValue,CountArray(szValue),pszFormat,nNumber);

	//����������
	if((nFormat&DT_LEFT)!=0) nXPos -= 0;
	if((nFormat&DT_CENTER)!=0) nXPos -= (lstrlen(szValue)*SizeNumber.cx)/2;
	if((nFormat&DT_RIGHT)!=0) nXPos -= lstrlen(szValue)*SizeNumber.cx;
	
	//����������
	if((nFormat&DT_TOP)!=0) nYPos -= 0;
	if((nFormat&DT_VCENTER)!=0) nYPos -= SizeNumber.cy/2;
	if((nFormat&DT_BOTTOM)!=0) nYPos -= SizeNumber.cy;

	//�滭����
	INT nIndex=0;
	for(INT i=0; i<lstrlen(szValue);i++)
	{
		nIndex = strNumber.Find(szValue[i]);
		if(nIndex!=-1)
		{
			pNumberImage->DrawImage(pDC,nXPos,nYPos,SizeNumber.cx,SizeNumber.cy,SizeNumber.cx*nIndex,0,SizeNumber.cx,SizeNumber.cy);
			nXPos += SizeNumber.cx;
		}
	}

	return;
}

//ʱ����Ϣ
VOID CDlgMatchIntroduce::OnTimer(UINT nIDEvent)
{
	__super::OnTimer(nIDEvent);

	if(IDI_UPDATE_TIME==nIDEvent)
	{
		//ˢ�½���
		RedrawWindow(NULL,NULL,RDW_INVALIDATE|RDW_UPDATENOW|RDW_ERASE|RDW_ERASENOW);
	}
}

//////////////////////////////////////////////////////////////////////////////////
//���캯��
CMissionMatch::CMissionMatch()
{
	//�����ʶ
	m_bSignup=false;
	m_pGameMatchInfo=NULL;

	//��������
	m_MissionManager.InsertMissionItem(this);
}

//��������
CMissionMatch::~CMissionMatch()
{
}

//�����¼�
bool CMissionMatch::OnEventMissionLink(INT nErrorCode)
{
	if (nErrorCode!=0L)
	{
		//��ʾ��ʾ
		CInformation Information;
		Information.ShowMessageBox(TEXT("�޷����ӵ���¼��������������Ϣ����ʧ�ܣ����Ժ����ԣ�"),MB_ICONERROR);
	}
	else
	{
		//��������
		if(m_bSignup==true)
		{
			//��ȡ����
			CGlobalUserInfo * pGlobalUserInfo = CGlobalUserInfo::GetInstance();
			tagGlobalUserData * pGlobalUserData = pGlobalUserInfo->GetGlobalUserData();

			//������
			CMD_GP_MatchSignup MatchSignup;

			//��ȡ����
			tagGameMatch GameMatch = m_pGameMatchInfo->pGameServerItem->m_GameMatch;

			//������Ϣ
			MatchSignup.wServerID = GameMatch.wServerID;
			MatchSignup.dwMatchID = GameMatch.dwMatchID;
			MatchSignup.dwMatchNO = GameMatch.dwMatchNO;

			//������Ϣ
			MatchSignup.dwUserID = pGlobalUserData->dwUserID;
			lstrcpyn(MatchSignup.szPassword,pGlobalUserData->szPassword,CountArray(MatchSignup.szPassword));

			//������ʶ
			CWHService::GetMachineIDEx(MatchSignup.szMachineID);

			//��������
			ASSERT(GetMissionManager()!=NULL);
			GetMissionManager()->SendData(MDM_GP_USER_SERVICE,SUB_GP_MATCH_SIGNUP,&MatchSignup,sizeof(MatchSignup));

			return true;
		}

		//ȡ������
		if(m_bSignup==false)
		{
			//��ȡ����
			CGlobalUserInfo * pGlobalUserInfo = CGlobalUserInfo::GetInstance();
			tagGlobalUserData * pGlobalUserData = pGlobalUserInfo->GetGlobalUserData();

			//������
			CMD_GP_MatchUnSignup MatchUnSignup;

			//��ȡ����
			tagGameMatch GameMatch = m_pGameMatchInfo->pGameServerItem->m_GameMatch;

			//������Ϣ
			MatchUnSignup.wServerID = GameMatch.wServerID;
			MatchUnSignup.dwMatchID = GameMatch.dwMatchID;
			MatchUnSignup.dwMatchNO = GameMatch.dwMatchNO;

			//������Ϣ
			MatchUnSignup.dwUserID = pGlobalUserData->dwUserID;
			lstrcpyn(MatchUnSignup.szPassword,pGlobalUserData->szPassword,CountArray(MatchUnSignup.szPassword));

			//������ʶ
			CWHService::GetMachineIDEx(MatchUnSignup.szMachineID);

			//��������
			ASSERT(GetMissionManager()!=NULL);
			GetMissionManager()->SendData(MDM_GP_USER_SERVICE,SUB_GP_MATCH_UNSIGNUP,&MatchUnSignup,sizeof(MatchUnSignup));

			return true;
		}
	}
	return true;
}

//�ر��¼�
bool CMissionMatch::OnEventMissionShut(BYTE cbShutReason)
{
	return true;
}

//��ȡ�¼�
bool CMissionMatch::OnEventMissionRead(TCP_Command Command, VOID * pData, WORD wDataSize)
{
	//�������
	if(Command.wMainCmdID!=MDM_GP_USER_SERVICE) return true;

	//�������
	if(SUB_GP_MATCH_SIGNUP_RESULT==Command.wSubCmdID)
	{
		//��ȡ����
		CMD_GP_MatchSignupResult * pMatchSignupResult = (CMD_GP_MatchSignupResult *)pData;
		if(pMatchSignupResult==NULL) return false;

		//��ȡ����
		ASSERT(CServerListData::GetInstance()!=NULL);
		CServerListData * pServerListData=CServerListData::GetInstance();

		//��ȡ����
		tagGameMatch GameMatch = m_pGameMatchInfo->pGameServerItem->m_GameMatch;

		//���ҷ���
		CGameServerItem * pGameServerItem = pServerListData->SearchGameServer(GameMatch.wServerID);
		if(pGameServerItem==NULL) return false;

		//���ñ�ʶ
		if(pMatchSignupResult->bSuccessed==true)
		{
			pGameServerItem->m_bSignuped = pMatchSignupResult->bSignup;
		}

		//���½���
		if(m_pGameMatchInfo->pGameViewMatchItem!=NULL)
		{
			m_pGameMatchInfo->pGameViewMatchItem->UpdateResource();
		}

		//��Ϣ��ʾ
		if(pMatchSignupResult->szDescribeString[0]!=0)
		{
			CInformation Information;
			Information.ShowMessageBox(TEXT("ϵͳ��ʾ"),pMatchSignupResult->szDescribeString,MB_OK);
		}

		return true;
	}

	return true;
}

//��������
VOID CMissionMatch::PerformSignupMatch(tagGameMatchInfo *	pGameMatchInfo)
{
	//���ñ���
	m_bSignup=true;
	m_pGameMatchInfo=pGameMatchInfo;

	//��������
	if (m_MissionManager.AvtiveMissionItem(this,false)==false)  
	{
		return;
	}
}

//ȡ������
VOID CMissionMatch::PerformUnSignupMatch(tagGameMatchInfo *	pGameMatchInfo)
{
	//���ñ���
	m_bSignup=false;
	m_pGameMatchInfo=pGameMatchInfo;

	//��������
	if (m_MissionManager.AvtiveMissionItem(this,false)==false)  
	{
		return;
	}
}

//////////////////////////////////////////////////////////////////////////////////
//���캯��
CGameViewSubItem::CGameViewSubItem()
{
	//��������
	m_bFloat=true;
	m_bScrollProcess=false;
}

//��������
CGameViewSubItem::~CGameViewSubItem()
{
}

//����λ��
void CGameViewSubItem::SetPos(RECT rc)
{
	__super::SetPos(rc);
}

//�¼�����
void CGameViewSubItem::DoEvent(TEventUI& event)
{
	__super::DoEvent(event);
}

//�滭����
void CGameViewSubItem::DoPaint(HDC hDC, const RECT& rcPaint)
{
	__super::DoPaint(hDC,rcPaint);
}

//���Ž��
LONG CGameViewSubItem::ZoomResult(LONG nNumber)
{
	//���ű���
	float fInflateScall = KIND_ITEM_ZOOM_MIN;
	CGameViewPage * pPlazaViewPage = static_cast<CGameViewPage *>(GetParent());
	if(pPlazaViewPage!=NULL) fInflateScall=pPlazaViewPage->m_fZoomScall;

	return LONG(nNumber*fInflateScall);
}

//������Դ
VOID CGameViewSubItem::UpdateResource()
{
}

//��������
VOID CGameViewSubItem::ActiveSubItem(INT nWidth,INT hHeight,VOID * pData)
{
}

//////////////////////////////////////////////////////////////////////////////////

//���캯��
CGameViewKindItem::CGameViewKindItem()
{
	
	//������Ϣ
	m_pGameKindInfo=NULL;

	//��Դ����
	m_ImageKindView.Empty();
	m_ImageKindName.Empty();
	m_ImageModify.Empty();

	//ģ�����
	m_bHoverKind=false;
	m_rcKindFrame.SetRect(0,0,116,121);


	
	/*//���ؼ�
	CRect rctCreate(0,0,0,0);
	m_PlatformPublicize.Create(NULL,NULL,WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN,rctCreate,this,IDC_WEB_PUBLICIZE);

	//��ȡ����
	CGlobalWebLink * pGlobalWebLink=CGlobalWebLink::GetInstance();

	//�����ַ
	TCHAR szBillUrl[256]=TEXT("");
	_sntprintf(szBillUrl,CountArray(szBillUrl),TEXT("%s/Ads/LogonLogo.aspx"),pGlobalWebLink->GetPlatformLink());


	//���ù��
	m_PlatformPublicize.Navigate(szBillUrl);*/



}

//��������
CGameViewKindItem::~CGameViewKindItem()
{
}

//����λ��
void CGameViewKindItem::SetPos(RECT rc)
{
	CGameViewPage * pPlazaViewPage = static_cast<CGameViewPage *>(GetParent());
	if(pPlazaViewPage!=NULL)
	{
		float fZoomScall = pPlazaViewPage->m_fZoomScall;
		const TImageInfo * pImageInfo = m_pManager->GetImageEx(m_ImageKindFrame);
		if(pImageInfo!=NULL)
		{
			//��������
			m_rcKindFrame.right = LONG(pImageInfo->nX*fZoomScall);
			m_rcKindFrame.bottom = LONG(pImageInfo->nY*fZoomScall);
		}
	}
	__super::SetPos(rc);
}

//�¼�����
void CGameViewKindItem::DoEvent(TEventUI& event)
{
	//������
	if( event.Type == UIEVENT_MOUSEENTER ) 
    {
		//ʹ���ж�
		if(m_pParent!=NULL && m_pParent->IsEnabled())
		{
			//��������
			CRect rcKindFrame = ClientToWindow(m_rcKindFrame);
			if(rcKindFrame.PtInRect(event.ptMouse)==TRUE)
			{
				m_bHoverKind = true;
				Invalidate();
			}
		}

        return;
    }

	//����ƶ�
	if( event.Type == UIEVENT_MOUSEMOVE ) 
    {
		//ʹ���ж�
		if(m_pParent!=NULL && m_pParent->IsEnabled())
		{
			CRect rcKindFrame = ClientToWindow(m_rcKindFrame);
			if(rcKindFrame.PtInRect(event.ptMouse)==TRUE)
			{
				if(m_bHoverKind==false)
				{
					m_bHoverKind = true;
					Invalidate();
				}			
			}
			else
			{
				if(m_bHoverKind=true)
				{
					m_bHoverKind = false;
					Invalidate();
				}
			}
		}

        return;
    }

	//����뿪
    if( event.Type == UIEVENT_MOUSELEAVE ) 
    {
        m_bHoverKind = false;
        Invalidate();
        return;
    }

	//����¼�
	if(event.Type == UIEVENT_BUTTONDOWN )
	{
		//ʹ���ж�
		if(m_pParent!=NULL && m_pParent->IsEnabled())
		{
			//�����ж�
			CRect rcKindFrame = ClientToWindow(m_rcKindFrame);
			if(rcKindFrame.PtInRect(event.ptMouse)==TRUE)
			{
				//��ȡ����
				IViewPageSubItemSink * pIViewPageSubItemSink=NULL;
				CGameViewPage * pPlazaViewPage = static_cast<CGameViewPage *>(m_pParent);
				if(pPlazaViewPage!=NULL) pIViewPageSubItemSink = pPlazaViewPage->m_pIViewPageSubItemSink;

				//����¼�
				if(pIViewPageSubItemSink!=NULL)
				{
					pIViewPageSubItemSink->OnViewPageKindItemClicked(m_pGameKindInfo);
				}

				return;
			}
		}
	}

	if( m_pParent != NULL ) m_pParent->DoEvent(event);
}

//�滭����
void CGameViewKindItem::DoPaint(HDC hDC, const RECT& rcPaint)
{
	//ethj
	
	//	m_PlatformPublicize.SetWindowPos(NULL,LAYERED_SIZE+2,73,1900,1000,SWP_NOZORDER|SWP_NOCOPYBITS|SWP_NOACTIVATE);

	/*	
	if( !::IntersectRect(&m_rcPaint, &rcPaint, &m_rcItem) ) return;


	//���ƿ��
	if( m_ImageKindFrame.IsEmpty()==false )
	{
		m_ImageModify.SmallFormat(TEXT("dest='%d,%d,%d,%d'"),m_rcKindFrame.left,m_rcKindFrame.top,m_rcKindFrame.right,m_rcKindFrame.bottom);
		if( !DrawImage(hDC,(LPCTSTR)m_ImageKindFrame,m_ImageModify )) m_ImageKindFrame.Empty();
	}

	//������ͼ
	if( m_ImageKindView.IsEmpty()==false )
	{
		m_ImageModify.SmallFormat(TEXT("dest='%d,%d,%d,%d'"),m_rcKindFrame.left+ZoomResult(12),m_rcKindFrame.top+ZoomResult(10),m_rcKindFrame.right-ZoomResult(12),m_rcKindFrame.bottom-ZoomResult(19));
		if( !DrawImage(hDC,(LPCTSTR)m_ImageKindView,m_ImageModify )) m_ImageKindView.Empty();
	}

	//������ͼ
	if( m_bHoverKind && m_ImageKindHover.IsEmpty()==false )
	{
		m_ImageModify.SmallFormat(TEXT("dest='%d,%d,%d,%d'"),m_rcKindFrame.left,m_rcKindFrame.top,m_rcKindFrame.right,m_rcKindFrame.bottom);
		if( !DrawImage(hDC,(LPCTSTR)m_ImageKindHover,m_ImageModify )) m_ImageKindHover.Empty();
	}

	//��������
	if( m_ImageKindName.IsEmpty()==false )
	{
		const TImageInfo * pImageInfo = m_pManager->GetImageEx(m_ImageKindName);
		if(pImageInfo!=NULL)
		{
			m_ImageModify.SmallFormat(TEXT("dest='%d,%d,%d,%d'"),(m_rcItem.right-m_rcItem.left-ZoomResult(pImageInfo->nX))/2,m_rcItem.bottom-m_rcItem.top-ZoomResult(pImageInfo->nY),(m_rcItem.right-m_rcItem.left-ZoomResult(pImageInfo->nX))/2+ZoomResult(pImageInfo->nX),m_rcItem.bottom-m_rcItem.top);
			if( !DrawImage(hDC,(LPCTSTR)m_ImageKindName,m_ImageModify )) m_ImageKindName.Empty();

		}
	}
	*/
}

//��������
void CGameViewKindItem::GetProcessName(TCHAR szProcessName[LEN_PROCESS])
{
	//ָ��У��
	if(m_pGameKindInfo==NULL) return;

	//��������
	lstrcpyn(szProcessName,m_pGameKindInfo->pGameKindItem->m_GameKind.szProcessName,sizeof(TCHAR)*LEN_PROCESS);

	//��������
	LPTSTR pszProcess = (_tcsrchr(szProcessName,TEXT('.'))); 

	//�����ַ�
	pszProcess[0]=TEXT('\0');

	return;
}

////���Ž��
//LONG CGameViewKindItem::ZoomResult(LONG nNumber)
//{
//	//���ű���
//	float fInflateScall = KIND_ITEM_ZOOM_MIN;
//	CGameViewPage * pPlazaViewPage = static_cast<CGameViewPage *>(GetParent());
//	if(pPlazaViewPage!=NULL) fInflateScall=pPlazaViewPage->m_fZoomScall;
//
//	return LONG(nNumber*fInflateScall);
//}

//��ȡ����
CRect CGameViewKindItem::ClientToWindow(CRect & rctClient)
{
	//��������
	CRect rcWindowRect(m_rcItem.left+rctClient.left,m_rcItem.top+rctClient.top,m_rcItem.left+rctClient.left+rctClient.Width(),m_rcItem.top+rctClient.top+rctClient.Height());

	return rcWindowRect;
}

//������Դ
VOID CGameViewKindItem::UpdateResource()
{
	
	//ָ���ж�
	if(m_pGameKindInfo==NULL) return;

	//�Ƴ���Դ
	m_pManager->RemoveImage(m_ImageKindView);
	m_pManager->RemoveImage(m_ImageKindName);

	//��������
	TCHAR szProcessName[LEN_PROCESS]=TEXT("");
	GetProcessName(szProcessName);

	//��Ϸδ��װ
	if (m_pGameKindInfo->pGameKindItem->m_dwProcessVersion==0L)
	{
		m_ImageKindView.Format(TEXT("GAME_KIND\\UnInstall_%s.png"),szProcessName);
		if(m_pManager->GetImageEx(m_ImageKindView,NULL)==NULL) m_ImageKindView.Empty();
	}
	else
	{
		m_ImageKindView.Format(TEXT("GAME_KIND\\GameKind_%s.png"),szProcessName);
		if(m_pManager->GetImageEx(m_ImageKindView,NULL)==NULL) m_ImageKindView.Empty();
	}

	//δ֪��Ϸ
	if(m_ImageKindView.IsEmpty()==true) m_ImageKindView = m_ImageUnSure;

	//��������
	m_ImageKindName.Format(TEXT("GAME_KIND\\GameName_%s.png"),szProcessName);
	if(m_pManager->GetImageEx(m_ImageKindName,NULL)==NULL) m_ImageKindName = m_ImageNameUnknown;

	//���½���
	Invalidate();
}

//��������
VOID CGameViewKindItem::ActiveSubItem(INT nWidth,INT hHeight,VOID * pData)
{

	//ת������
	tagGameKindInfo * pGameKindInfo = (tagGameKindInfo *)pData;
	if(pGameKindInfo==NULL) return;

	//���ñ���
	m_bHoverKind = false;
	m_pGameKindInfo = pGameKindInfo;

	//������Դ
	UpdateResource();

	//��������
	const TImageInfo * pImageInfo = m_pManager->GetImageEx(m_ImageKindFrame);
	if(pImageInfo!=NULL) m_rcKindFrame.SetRect(0,0,pImageInfo->nX,pImageInfo->nY);

	//����λ��
	SetFixedWidth(nWidth);
	SetFixedHeight(hHeight);
	
}


///////////////////////////////////////////////////////////////////////////////////
CGameViewAppItem::CGameViewAppItem()
{
	m_pGameAppInfo = NULL;

	//��Դ����
	m_ImageKindView.Empty();
	
	m_ImageModify.Empty();

	m_rcKindFrame.SetRect(0,0,116,121);
}
CGameViewAppItem::~CGameViewAppItem()
{
}
void CGameViewAppItem::DoEvent(TEventUI& event)
{

}
void CGameViewAppItem::DoPaint(HDC hDC, const RECT& rcPaint)
{
	if( !::IntersectRect(&m_rcPaint, &rcPaint, &m_rcItem) ) return;

	//���Ʊ���
	CStdString  m_ImageKindFrame=TEXT("file='KIND_FRAME' restype='PNG'");

	if(m_ImageKindView.IsEmpty()==false )
	{
		m_ImageModify.SmallFormat(TEXT("dest='%d,%d,%d,%d'"),m_rcKindFrame.left+ZoomResult(12),m_rcKindFrame.top+ZoomResult(10),m_rcKindFrame.right-ZoomResult(12),m_rcKindFrame.bottom-ZoomResult(19));
		if( !DrawImage(hDC,(LPCTSTR)m_ImageKindView,m_ImageModify )) m_ImageKindView.Empty();
	}

		//��������
	if( m_ImageAppName.IsEmpty()==false )
	{
		const TImageInfo * pImageInfo = m_pManager->GetImageEx(m_ImageAppName);
		if(pImageInfo!=NULL)
		{
			m_ImageModify.SmallFormat(TEXT("dest='%d,%d,%d,%d'"),(m_rcKindFrame.right-m_rcKindFrame.left-ZoomResult(pImageInfo->nX))/2,m_rcKindFrame.bottom-m_rcKindFrame.top-ZoomResult(pImageInfo->nY),(m_rcKindFrame.right-m_rcKindFrame.left-ZoomResult(pImageInfo->nX))/2+ZoomResult(pImageInfo->nX),m_rcKindFrame.bottom-m_rcKindFrame.top);
			if( !DrawImage(hDC,(LPCTSTR)m_ImageAppName,m_ImageModify )) m_ImageAppName.Empty();
		}
	}

}
VOID CGameViewAppItem::UpdateResource()
{
	if(m_pGameAppInfo==NULL) return;

	//�Ƴ���Դ
	m_pManager->RemoveImage(m_ImageKindView);
	m_pManager->RemoveImage(m_ImageAppName);

	if(m_pGameAppInfo!=NULL)
	{
		//�����ͷ �������� �Ҹ���ţ 13��
		if(m_pGameAppInfo->wUIID == 0)
		{
			m_ImageKindView=TEXT("GAME_KIND\\GameKind_yfmt6.png");
			m_ImageAppName=TEXT("GAME_KIND\\GameName_yfmt6.png");
		}
		if(m_pGameAppInfo->wUIID == 1)
		{
			m_ImageKindView=TEXT("GAME_KIND\\GameKind_lkpy6.png");
			m_ImageAppName=TEXT("GAME_KIND\\GameName_lkpy6.png");
		}
		if(m_pGameAppInfo->wUIID == 2)
		{
			m_ImageKindView=TEXT("GAME_KIND\\GameKind_OxNew.png");
			m_ImageAppName=TEXT("GAME_KIND\\GameName_OxNew.png");
		}
		if(m_pGameAppInfo->wUIID == 3)
		{
			m_ImageKindView=TEXT("GAME_KIND\\GameKind_ThirteenEx.png");
			m_ImageAppName=TEXT("GAME_KIND\\GameName_ThirteenEx.png");
		}
		
		if(m_pManager->GetImageEx(m_ImageKindView,NULL)==NULL) m_ImageKindView.Empty();
		if(m_pManager->GetImageEx(m_ImageAppName,NULL)==NULL) m_ImageAppName.Empty();


	}

	//���½���
	Invalidate();
}
VOID CGameViewAppItem::ActiveSubItem(INT nWidth,INT hHeight,VOID * pData)
{
	//ת������
	tagGameAppInfo * pGameAppInfo = (tagGameAppInfo *)pData;
	if(pGameAppInfo==NULL) return;

	//���ñ���

	m_pGameAppInfo = pGameAppInfo;

	//������Դ
	UpdateResource();

	//��������
	CStdString  m_ImageKindFrame=TEXT("file='KIND_FRAME' restype='PNG'");
	const TImageInfo * pImageInfo = m_pManager->GetImageEx(m_ImageKindFrame);
	if(pImageInfo!=NULL) m_rcKindFrame.SetRect(0,0,pImageInfo->nX,pImageInfo->nY);

	//����λ��
	SetFixedWidth(nWidth);
	SetFixedHeight(hHeight);
}
//////////////////////////////////////////////////////////////////////////////////

//���캯��
CGameViewServerItem::CGameViewServerItem()
{
	//���ñ���
	m_pGameServerInfo=NULL;
	m_ImageModify.Empty();
}

//��������
CGameViewServerItem::~CGameViewServerItem()
{
}

//�¼�����
void CGameViewServerItem::DoEvent(TEventUI& event)
{
	//������
	if( event.Type == UIEVENT_MOUSEENTER ) 
    {
		//ʹ���ж�
		if(m_pParent!=NULL && m_pParent->IsEnabled())
		{
			m_bHoverServer = true;
			Invalidate();
		}

        return;
    }

	//����뿪
    if( event.Type == UIEVENT_MOUSELEAVE ) 
    {
        m_bHoverServer = false;
        Invalidate();
        return;
    }

	//����¼�
	if(event.Type == UIEVENT_BUTTONDOWN )
	{
		//ʹ���ж�
		if(m_pParent!=NULL && m_pParent->IsEnabled())
		{
			//��ȡ����
			IViewPageSubItemSink * pIViewPageSubItemSink=NULL;
			CGameViewPage * pPlazaViewPage = static_cast<CGameViewPage *>(m_pParent);
			if(pPlazaViewPage!=NULL) pIViewPageSubItemSink = pPlazaViewPage->m_pIViewPageSubItemSink;

			//����¼�
			if(pIViewPageSubItemSink!=NULL)
			{
				m_bHoverServer = false;
				pIViewPageSubItemSink->OnViewPageServerItemClicked(m_pGameServerInfo);
			}

			return;
		}
	}

	if( m_pParent != NULL ) m_pParent->DoEvent(event);
}

//�滭����
void CGameViewServerItem::DoPaint(HDC hDC, const RECT& rcPaint)
{
	if( !::IntersectRect(&m_rcPaint, &rcPaint, &m_rcItem) ) return;

	CString strLog;

	//��־
	strLog.Format(_T("%s,%s,%d,m_rcPaint.left:%d,m_rcPaint.top:%d,m_rcPaint.right:%d,m_rcPaint.bottom:%d,"), 
					PREFIX_LOG,__FUNCTIONW__, __LINE__,
					m_rcPaint.left,
					m_rcPaint.top,
					m_rcPaint.right,
					m_rcPaint.bottom);
	//::OutputDebugString(strLog);

	//��־
	strLog.Format(_T("%s,%s,%d,rcPaint.left:%d,rcPaint.top:%d,rcPaint.right:%d,rcPaint.bottom:%d,"), 
					PREFIX_LOG,__FUNCTIONW__, __LINE__,
					rcPaint.left,
					rcPaint.top,
					rcPaint.right,
					rcPaint.bottom);
	//::OutputDebugString(strLog);

	//��־
	strLog.Format(_T("%s,%s,%d,m_rcItem.left:%d,m_rcItem.top:%d,m_rcItem.right:%d,m_rcItem.bottom:%d,"), 
					PREFIX_LOG,__FUNCTIONW__, __LINE__,
					m_rcItem.left,
					m_rcItem.top,
					m_rcItem.right,
					m_rcItem.bottom);
	//::OutputDebugString(strLog);

	//��������
	const TImageInfo * pImageInfo=NULL;

	CRect rct = m_rcPaint;

	TCHAR szBuffer[128];

	rct.right -= rct.left;
	rct.bottom -= rct.top;
	rct.left	= 0;
	rct.top		= 0;
	
	const int nWidthBar = 10;

	//���Ʊ���
	if( m_ImageServerBack.IsEmpty()==false)
	{
		//������
		m_ImageModify.SmallFormat(TEXT("dest='%d,%d,%d,%d'"), rct.left, rct.top, rct.left+nWidthBar, rct.bottom);
		DrawImage(hDC,(LPCTSTR)m_ImageBarLeft, m_ImageModify);

		m_ImageModify.SmallFormat(TEXT("dest='%d,%d,%d,%d'"), rct.left+nWidthBar,rct.top,rct.right-nWidthBar-m_rcPaint.left, rct.bottom);
		DrawImage(hDC,(LPCTSTR)m_ImageBarMid, m_ImageModify);

		m_ImageModify.SmallFormat(TEXT("dest='%d,%d,%d,%d'"), rct.right-nWidthBar-m_rcPaint.left,rct.top,rct.right-m_rcPaint.left, rct.bottom);
		DrawImage(hDC,(LPCTSTR)m_ImageBarRight, m_ImageModify);

		//if( !DrawImage(hDC,(LPCTSTR)m_ImageServerBack)) m_ImageServerBack.Empty();

		//���Ʒ�������
		//m_ImageModify.SmallFormat(TEXT("dest='%d,%d,%d,%d'"),24,81,188,261);
		//DrawImage(hDC,(LPCTSTR)m_ImageServerKindView,m_ImageModify);

		//��������
		tagGameServer GameServer = m_pGameServerInfo->pGameServerItem->m_GameServer;
		
		//���뷿��
		if(GameServer.wServerKind==SERVER_GENRE_PASSWD)
		{
			//��������
			CStdString strServerLocker(TEXT("file='SERVER_LOCKER' restype='PNG'"));

			//���Ʒ�����
			//m_ImageModify.SmallFormat(TEXT("dest='%d,%d,%d,%d'"),131,39,131+30,39+35);
			//DrawImage(hDC,(LPCTSTR)strServerLocker,m_ImageModify);
		}

		//����״̬
		if(m_ImagePayloadStatus.IsEmpty()==false)
		{
			//��ȡ��Ϣ
			pImageInfo = m_pManager->GetImageEx(m_ImagePayloadStatus);
			if(pImageInfo!=NULL)
			{
				//״̬��С
				CSize SizeStatus(pImageInfo->nX/5,pImageInfo->nY);

				//����״̬
				//WORD wStatusIndex = GetPayloadStatusIndex();	
				//m_ImageModify.SmallFormat(TEXT("source='%d,%d,%d,%d' dest='%d,%d,%d,%d'"),wStatusIndex*SizeStatus.cx,0,(wStatusIndex+1)*SizeStatus.cx,SizeStatus.cy,143,8,143+SizeStatus.cx,8+SizeStatus.cy);
				//if( !DrawImage(hDC,(LPCTSTR)m_ImagePayloadStatus,m_ImageModify)) m_ImagePayloadStatus.Empty();
			}
		}

		//���û���
		::SetBkMode(hDC,TRANSPARENT);

		//��������
		if(GameServer.szServerName[0]!=0)
		{
			//��������		
			::SetTextColor(hDC,RGB(194,218,243));
			::SelectObject(hDC,m_pManager->GetFont(3));

			CRect rctServerName(m_rcItem.left+44,m_rcItem.top+13,m_rcItem.left+44+150,m_rcItem.top+30);
			DrawText(hDC,GameServer.szServerName,lstrlen(GameServer.szServerName),rctServerName,DT_LEFT|DT_SINGLELINE|DT_END_ELLIPSIS);
		}

		/*//��������		
		::SetTextColor(hDC,RGB(255,255,255));
		::SelectObject(hDC,m_pManager->GetFont(3));

		const DWORD dwFullCount		= m_pGameServerInfo->pGameServerItem->m_GameServer.dwFullCount;
		const DWORD dwOnLineCount	= m_pGameServerInfo->pGameServerItem->m_GameServer.dwOnLineCount;

		_sntprintf(szBuffer,CountArray(szBuffer),TEXT("%d/%d"),dwOnLineCount,dwFullCount);
		CRect rctOnline(m_rcItem.left+200,m_rcItem.top+19,m_rcItem.left+300,m_rcItem.top+37);
		//if (dwOnLineCount>0)DrawText(hDC,szBuffer,lstrlen(szBuffer),rctOnline,DT_CENTER|DT_SINGLELINE|DT_END_ELLIPSIS);//��ʱȡ����ʾ�����������������

		//�������ͱ�־
		pImageInfo = m_pManager->GetImageEx(m_ImageServerKindLogo);
		if(pImageInfo!=NULL)
		{			
		//	m_ImageModify.SmallFormat(TEXT("dest='%d,%d,%d,%d'"),30-pImageInfo->nX/2,40-pImageInfo->nY/2,30+pImageInfo->nX/2,40+pImageInfo->nY/2);
		//	DrawImage(hDC,(LPCTSTR)m_ImageServerKindLogo,m_ImageModify);
		}*/
		//��������		
		::SetTextColor(hDC,RGB(194,218,243));
		::SelectObject(hDC,m_pManager->GetFont(3));			

		const bool bMatchRoom = m_pGameServerInfo->pGameServerItem->IsMatchRoom();

		//��������
		if(bMatchRoom)
		{
			//��������
			tagGameMatch GameMatch = m_pGameServerInfo->pGameServerItem->m_GameMatch;

			//��������
			TCHAR szMatchFee[32]=TEXT("");
			_sntprintf(szMatchFee,CountArray(szMatchFee),TEXT("��������:%I64d %s"),GameMatch.lMatchFee,GameMatch.cbMatchFeeType==MATCH_FEE_TYPE_GOLD?TEXT("��Ϸ��"):TEXT("Ԫ��"));

			//��ʱ����
			if(GameMatch.cbMatchType==MATCH_TYPE_LOCKTIME)
			{
				//��������
				CTime CurrTime=CTime::GetCurrentTime();
				DWORD dwCurrInterval = CurrTime.GetHour()*3600+CurrTime.GetMinute()*60+CurrTime.GetSecond();
				DWORD dwEndInterval = GameMatch.MatchEndTime.wHour*3600+GameMatch.MatchEndTime.wMinute*60+GameMatch.MatchEndTime.wSecond;

				//����ʱ��
				TCHAR szStartTime[32]=TEXT("");
				_sntprintf(szStartTime,CountArray(szStartTime),TEXT("��ʼ:%02d:%02d:%02d"),GameMatch.MatchStartTime.wHour,GameMatch.MatchStartTime.wMinute,GameMatch.MatchStartTime.wSecond);

				//����ʱ��
				TCHAR szEndTime[32]=TEXT("");
				_sntprintf(szEndTime,CountArray(szEndTime),TEXT("����:%02d:%02d:%02d"),GameMatch.MatchEndTime.wHour,GameMatch.MatchEndTime.wMinute,GameMatch.MatchEndTime.wSecond);

				//��������								
				CRect rcStartTime(m_rcItem.left+180,m_rcItem.top+13,m_rcItem.left+320,m_rcItem.top+30);
				CRect rcEndTime(m_rcItem.left+330,m_rcItem.top+13,m_rcItem.left+480,m_rcItem.top+30);
				CRect rcMatchFee(m_rcItem.left+490,m_rcItem.top+13,m_rcItem.left+680,m_rcItem.top+30);

				//����ʱ��
				DrawText(hDC,szStartTime,lstrlen(szStartTime),rcStartTime,DT_SINGLELINE|DT_VCENTER|DT_LEFT|DT_END_ELLIPSIS);

				//����ʱ��		
				DrawText(hDC,szEndTime,lstrlen(szEndTime),rcEndTime,DT_SINGLELINE|DT_VCENTER|DT_LEFT|DT_END_ELLIPSIS);	

				//��������
				DrawText(hDC,szMatchFee,lstrlen(szMatchFee),rcMatchFee,DT_SINGLELINE|DT_VCENTER|DT_LEFT|DT_END_ELLIPSIS);
			}

			//��ʱ����
			if(GameMatch.cbMatchType==MATCH_TYPE_IMMEDIATE)
			{
				//��������
				TCHAR szStartUserCount[32]=TEXT("");
				_sntprintf(szStartUserCount,CountArray(szStartUserCount),TEXT("��%d�˿���"),GameMatch.wStartUserCount);

				//��������
				CRect rcStartUserCount(m_rcItem.left+210,m_rcItem.top+13,m_rcItem.left+350,m_rcItem.top+30);
				CRect rcMatchFee(m_rcItem.left+394,m_rcItem.top+13,m_rcItem.left+560,m_rcItem.top+30);

				//��������
				DrawText(hDC,szStartUserCount,lstrlen(szStartUserCount),rcStartUserCount,DT_SINGLELINE|DT_VCENTER|DT_LEFT|DT_END_ELLIPSIS);

				//��������
				DrawText(hDC,szMatchFee,lstrlen(szMatchFee),rcMatchFee,DT_SINGLELINE|DT_VCENTER|DT_LEFT|DT_END_ELLIPSIS);
			}
		}
		//��ͨ����
		else
		{
			

			//�����ע
			TCHAR szCellScore[16]=TEXT("");
			CRect rcCellScore(m_rcItem.left+210,m_rcItem.top+13,m_rcItem.left+350,m_rcItem.top+30);
			_sntprintf(szCellScore,CountArray(szCellScore),TEXT("�׷�:%I64d "),GameServer.lEnterScore);

			

			DrawText(hDC,szCellScore,lstrlen(szCellScore),rcCellScore,DT_LEFT|DT_SINGLELINE|DT_END_ELLIPSIS);




			//��ʾ��������
		
			TCHAR szOnLineCount[16]=TEXT("");
			CRect rcOnLineCount(m_rcItem.left+394,m_rcItem.top+13,m_rcItem.left+560,m_rcItem.top+32);
			_sntprintf(szOnLineCount,CountArray(szOnLineCount),TEXT("����:%d"),GameServer.dwOnLineCount+GameServer.dwAndroidCount);
			DrawText(hDC,szOnLineCount,lstrlen(szOnLineCount),rcOnLineCount,DT_LEFT|DT_SINGLELINE|DT_END_ELLIPSIS);

			//�������
			//TCHAR szEnterScore[16]=TEXT("");
			//CRect rcEnterScore(m_rcItem.left+94,m_rcItem.top+288,m_rcItem.left+186,m_rcItem.top+303);
			//_sntprintf(szEnterScore,CountArray(szEnterScore),TEXT("%I64d"),GameServer.lEnterScore);
			//DrawText(hDC,szEnterScore,lstrlen(szEnterScore),rcEnterScore,DT_LEFT|DT_SINGLELINE|DT_END_ELLIPSIS);
		}
	}

	//������ͼ
	if( m_bHoverServer && (m_ImageHoverServer.IsEmpty()==false) )
	{
		pImageInfo = m_pManager->GetImageEx(m_ImageHoverServer);
		if(pImageInfo!=NULL)
		{
			//������
			m_ImageModify.SmallFormat(TEXT("dest='%d,%d,%d,%d'"), rct.left, rct.top, rct.left+nWidthBar, rct.bottom);
			DrawImage(hDC,(LPCTSTR)m_ImageBarLeft_Frame, m_ImageModify);

			m_ImageModify.SmallFormat(TEXT("dest='%d,%d,%d,%d'"), rct.left+nWidthBar,rct.top,rct.right-nWidthBar-m_rcPaint.left, rct.bottom);
			DrawImage(hDC,(LPCTSTR)m_ImageBarMid_Frame, m_ImageModify);

			m_ImageModify.SmallFormat(TEXT("dest='%d,%d,%d,%d'"), rct.right-nWidthBar-m_rcPaint.left,rct.top,rct.right-m_rcPaint.left, rct.bottom);
			DrawImage(hDC,(LPCTSTR)m_ImageBarRight_Frame, m_ImageModify);
		}
	}
}

//״̬����
WORD CGameViewServerItem::GetPayloadStatusIndex()
{
	if(m_pGameServerInfo==NULL) return 0;

	//��������
	WORD wStatusIndex=0;
	DWORD dwFullCount = m_pGameServerInfo->pGameServerItem->m_GameServer.dwFullCount;
	DWORD dwOnLineCount = m_pGameServerInfo->pGameServerItem->m_GameServer.dwOnLineCount;

	//��������
    if(dwOnLineCount>=0) wStatusIndex = 0;
	if(dwOnLineCount>=dwFullCount*10/100) wStatusIndex = 1;
	if(dwOnLineCount>=dwFullCount*50/100) wStatusIndex = 2;
	if(dwOnLineCount>=dwFullCount*70/100) wStatusIndex = 3;
	if(dwOnLineCount>=dwFullCount*100/100) wStatusIndex = 4;

	return wStatusIndex;
}

//��������
void CGameViewServerItem::GetProcessName(TCHAR szProcessName[LEN_PROCESS])
{
	//ָ��У��
	if(m_pGameServerInfo==NULL) return;

	//��������
	CGameKindItem * pGameKindItem = m_pGameServerInfo->pGameServerItem->m_pGameKindItem;

	//��������
	lstrcpyn(szProcessName,pGameKindItem->m_GameKind.szProcessName,sizeof(TCHAR)*LEN_PROCESS);

	//��������
	LPTSTR pszProcess = (_tcsrchr(szProcessName,TEXT('.'))); 

	//�����ַ�
	pszProcess[0]=TEXT('\0');
}

//������Դ
VOID CGameViewServerItem::UpdateResource()
{
	//�Ƴ���Դ
	m_pManager->RemoveImage(m_ImageServerBack);
	m_pManager->RemoveImage(m_ImageServerKindLogo);
	m_pManager->RemoveImage(m_ImageServerKindView);

	//��������
	if(m_pGameServerInfo->pGameServerItem->IsMatchRoom()==true)
	{
		//��ȡ����
		tagGameMatch GameMatch = m_pGameServerInfo->pGameServerItem->m_GameMatch;
		m_ImageServerBack.Format(TEXT("file='SERVER_KIND_MATCH_%d' restype='PNG'"),GameMatch.cbMatchType);
	}
	else
	{
		m_ImageServerBack=TEXT("file='SERVER_KIND_NORMAL' restype='PNG'");
	}

	//��ȡ������
	TCHAR szProcessName[LEN_PROCESS]={0};
	GetProcessName(szProcessName);

	//���ñ���
	m_ImageServerKindLogo.Format(TEXT("..\\%s\\SERVER_LOGO.png"),szProcessName);
	m_ImageServerKindView.Format(TEXT("..\\%s\\SERVER_VIEW_NORMAL.png"),szProcessName);	

	//��������
	tagGameServer GameServer = m_pGameServerInfo->pGameServerItem->m_GameServer;
		
	//�����׷���
	if(CServerRule::IsAllowAvertCheatMode(GameServer.dwServerRule))
	{
		m_ImageServerKindLogo=TEXT("file='SERVER_LOGO_DISTRIBUTE' restype='PNG'");
		m_ImageServerKindView.Format(TEXT("..\\%s\\SERVER_VIEW_DISTRIBUTE.png"),szProcessName);
	}

	//��������
	if(m_pGameServerInfo->pGameServerItem->IsMatchRoom()==true)
	{
		m_ImageServerKindLogo=TEXT("file='SERVER_LOGO_MATCH' restype='PNG'");
		m_ImageServerKindView.Format(TEXT("..\\%s\\SERVER_VIEW_MATCH.png"),szProcessName);
	}

	m_ImageBarLeft	= TEXT("file='SERVER_ITEM_BAR_LEFT' restype='PNG'");
	m_ImageBarMid	= TEXT("file='SERVER_ITEM_BAR_MID' restype='PNG'");
	m_ImageBarRight	= TEXT("file='SERVER_ITEM_BAR_RIGHT' restype='PNG'");

	m_ImageBarLeft_Frame	= TEXT("file='SERVER_ITEM_BAR_LEFT_FRAME' restype='PNG'");
	m_ImageBarMid_Frame		= TEXT("file='SERVER_ITEM_BAR_MID_FRAME' restype='PNG'");
	m_ImageBarRight_Frame	= TEXT("file='SERVER_ITEM_BAR_RIGHT_FRAME' restype='PNG'");

	//���½���
	Invalidate();
}

//��������
VOID CGameViewServerItem::ActiveSubItem(INT nWidth,INT hHeight,VOID * pData)
{
	//ת������
	tagGameServerInfo * pGameServerInfo = (tagGameServerInfo *)pData;
	if(pGameServerInfo==NULL) return;

	//���ñ���
	m_bHoverServer = false;
	m_pGameServerInfo = pGameServerInfo;

	//������Դ
	UpdateResource();

	//����λ��
	SetFixedWidth(nWidth);
	SetFixedHeight(hHeight);
}




//-----------------------------------------------
//���캯��
CGameViewMatchItem::CGameViewMatchItem()
{
	//���ñ���
	m_pGameMatchInfo=NULL;

	//�������
	m_pBtSignup=NULL;
	m_pBtUnSignup=NULL;

	//�������
	m_pEnterMatch=NULL;
	m_pCheckScore=NULL;
	m_pMatchIntroduce=NULL;
}

//��������
CGameViewMatchItem::~CGameViewMatchItem()
{
}

//�滭����
void CGameViewMatchItem::DoPaint(HDC hDC, const RECT& rcPaint)
{
	if( !::IntersectRect(&m_rcPaint, &rcPaint, &m_rcItem) ) return;

	//��������
	const TImageInfo * pImageInfo=NULL;

	//���Ʊ���
	if( m_ImageServerBack.IsEmpty()==false )
	{
		if( !DrawImage(hDC,(LPCTSTR)m_ImageServerBack)) m_ImageServerBack.Empty();
		
		//���û���
		::SetBkMode(hDC,TRANSPARENT);

		//��ȡ����
		tagGameMatch GameMatch = m_pGameMatchInfo->pGameServerItem->m_GameMatch;

		//��������
		if(GameMatch.szMatchName[0]!=0)
		{
			//��������		
			::SetTextColor(hDC,RGB(255,255,255));
			::SelectObject(hDC,m_pManager->GetFont(3));

			//�������
			CRect rcServerName(m_rcItem.left+ZoomResult(12),m_rcItem.top+ZoomResult(30),m_rcItem.left+ZoomResult(136),m_rcItem.top+ZoomResult(44));
			DrawText(hDC,GameMatch.szMatchName,lstrlen(GameMatch.szMatchName),rcServerName,DT_CENTER|DT_SINGLELINE|DT_END_ELLIPSIS);
		}

		//��������		
		::SetTextColor(hDC,RGB(0,0,0));
		::SelectObject(hDC,m_pManager->GetFont(0));

		//��������
		CTime CurrTime=CTime::GetCurrentTime();
		DWORD dwCurrInterval = CurrTime.GetHour()*3600+CurrTime.GetMinute()*60+CurrTime.GetSecond();
		DWORD dwEndInterval = GameMatch.MatchEndTime.wHour*3600+GameMatch.MatchEndTime.wMinute*60+GameMatch.MatchEndTime.wSecond;

		//��������
		LPCTSTR pszMatchCondition[]={TEXT("�������"),TEXT("�����Ա"),TEXT("�����Ա"),TEXT("�����Ա"),TEXT("�����Ա"),TEXT("VIP��Ա"),TEXT("������Ա")};	
		//��������
		TCHAR szMatchFee[32]=TEXT("");
		_sntprintf(szMatchFee,CountArray(szMatchFee),SCORE_STRING TEXT("%s"),GameMatch.lMatchFee,GameMatch.cbMatchFeeType==MATCH_FEE_TYPE_GOLD?TEXT("��Ϸ��"):TEXT("Ԫ��"));

		//������		
		CRect rcMatchFee(m_rcItem.left+ZoomResult(80),m_rcItem.top+ZoomResult(60+22),m_rcItem.left+ZoomResult(176),m_rcItem.top+ZoomResult(73+22));
		CRect rcMatchCondition(m_rcItem.left+ZoomResult(80),m_rcItem.top+ZoomResult(60),m_rcItem.left+ZoomResult(176),m_rcItem.top+ZoomResult(73));	
			
		//��������		
		if(GameMatch.cbMemberOrder<CountArray(pszMatchCondition))
		{
			DrawText(hDC,pszMatchCondition[GameMatch.cbMemberOrder],lstrlen(pszMatchCondition[GameMatch.cbMemberOrder]),rcMatchCondition,DT_SINGLELINE|DT_VCENTER|DT_LEFT|DT_END_ELLIPSIS);
		}

		//��������		
		DrawText(hDC,szMatchFee,lstrlen(szMatchFee),rcMatchFee,DT_SINGLELINE|DT_VCENTER|DT_LEFT|DT_END_ELLIPSIS);
		
		//��ʱ����
		if(GameMatch.cbMatchType==MATCH_TYPE_LOCKTIME)
		{
			//����ʱ��
			TCHAR szStartTime[32]=TEXT("");
			_sntprintf(szStartTime,CountArray(szStartTime),TEXT("%02d:%02d:%02d"),GameMatch.MatchStartTime.wHour,GameMatch.MatchStartTime.wMinute,GameMatch.MatchStartTime.wSecond);

			//����ʱ��
			TCHAR szEndTime[32]=TEXT("");
			_sntprintf(szEndTime,CountArray(szEndTime),TEXT("%02d:%02d:%02d"),GameMatch.MatchEndTime.wHour,GameMatch.MatchEndTime.wMinute,GameMatch.MatchEndTime.wSecond);
			
			//��������				
			CRect rcStartTime(m_rcItem.left+ZoomResult(80),m_rcItem.top+ZoomResult(60+43),m_rcItem.left+ZoomResult(176),m_rcItem.top+ZoomResult(73+43));
			CRect rcEndTime(m_rcItem.left+ZoomResult(80),m_rcItem.top+ZoomResult(60+64),m_rcItem.left+ZoomResult(176),m_rcItem.top+ZoomResult(73+64));		

			//����ʱ��
			DrawText(hDC,szStartTime,lstrlen(szStartTime),rcStartTime,DT_SINGLELINE|DT_VCENTER|DT_LEFT|DT_END_ELLIPSIS);

			//����ʱ��		
			DrawText(hDC,szEndTime,lstrlen(szEndTime),rcEndTime,DT_SINGLELINE|DT_VCENTER|DT_LEFT|DT_END_ELLIPSIS);		
		}

		//��ʱ����
		if(GameMatch.cbMatchType==MATCH_TYPE_IMMEDIATE)
		{
			//����ʱ��
			TCHAR szStartUserCount[32]=TEXT("");
			_sntprintf(szStartUserCount,CountArray(szStartUserCount),TEXT("��%d�˿���"),GameMatch.wStartUserCount);

			//����ʱ��
			TCHAR szRewardUserCount[32]=TEXT("");
			_sntprintf(szRewardUserCount,CountArray(szRewardUserCount),TEXT("ǰ %d ��"),GameMatch.wRewardCount);

			//������
			CRect rcStartUserCount(m_rcItem.left+ZoomResult(80),m_rcItem.top+ZoomResult(60+43),m_rcItem.left+ZoomResult(176),m_rcItem.top+ZoomResult(73+43));
			CRect rcRewardUserCount(m_rcItem.left+ZoomResult(80),m_rcItem.top+ZoomResult(60+64),m_rcItem.left+ZoomResult(176),m_rcItem.top+ZoomResult(73+64));	
			//��������
			DrawText(hDC,szStartUserCount,lstrlen(szStartUserCount),rcStartUserCount,DT_SINGLELINE|DT_VCENTER|DT_LEFT|DT_END_ELLIPSIS);

			//��������		
			DrawText(hDC,szRewardUserCount,lstrlen(szRewardUserCount),rcRewardUserCount,DT_SINGLELINE|DT_VCENTER|DT_LEFT|DT_END_ELLIPSIS);	
		}
	}

	__super::DoPaint(hDC,rcPaint);
}

//��ť�¼�
bool CGameViewMatchItem::OnButtonEvent(void* event) 
{
    if( ((TEventUI*)event)->Type == UIEVENT_BUTTONDOWN ) 
	{
		//��������
		IViewPageSubItemSink * pIViewPageSubItemSink=NULL;

		//��ȡ����
        CControlUI* pControlUI = ((TEventUI*)event)->pSender;
		CGameViewMatchItem * pGameViewMatchItem = static_cast<CGameViewMatchItem *>(pControlUI->GetParent());

		//��ȡ����		
		CGameViewPage * pPlazaViewPage = static_cast<CGameViewPage *>(pGameViewMatchItem->GetParent());
		if(pPlazaViewPage!=NULL) pIViewPageSubItemSink = pPlazaViewPage->m_pIViewPageSubItemSink;

		//��������
		WORD wComandID=(WORD)pControlUI->GetTag();

		//����¼�
		if(pIViewPageSubItemSink!=NULL)
		{
			pIViewPageSubItemSink->OnViewPageMatchItemClicked(pGameViewMatchItem->m_pGameMatchInfo,wComandID);
		}
    }
    return true;
}

//������Դ
VOID CGameViewMatchItem::UpdateResource()
{
	//�Ƴ���Դ
	m_pManager->RemoveImage(m_ImageServerBack);

	//��������
	tagGameMatch GameMatch = m_pGameMatchInfo->pGameServerItem->m_GameMatch;

	//���ÿؼ�
	if(m_pGameMatchInfo->pGameServerItem->m_bSignuped==true && 
	   GameMatch.cbMatchType==MATCH_TYPE_LOCKTIME)
	{
		m_pBtSignup->SetVisible(false);
		m_pBtUnSignup->SetVisible(true);
		m_ImageServerBack.Format(TEXT("file='MATCH_TYPE_%d_SIGNUP' restype='PNG'"),GameMatch.cbMatchType);
	}
	else
	{
		m_pBtSignup->SetVisible(true);
		m_pBtUnSignup->SetVisible(false);
		m_ImageServerBack.Format(TEXT("file='MATCH_TYPE_%d_NORMAL' restype='PNG'"),GameMatch.cbMatchType);
	}	

	//���½���
	Invalidate();
}

//��������
VOID CGameViewMatchItem::ActiveSubItem(INT nWidth,INT hHeight,VOID * pData)
{
	//ת������
	tagGameMatchInfo * pGameMatchInfo = (tagGameMatchInfo *)pData;
	if(pGameMatchInfo==NULL) return;

	//���ñ���
	m_pGameMatchInfo = pGameMatchInfo;
	m_pGameMatchInfo->pGameViewMatchItem = this;

	//��������
	tagGameMatch GameMatch = m_pGameMatchInfo->pGameServerItem->m_GameMatch;

	//������ť
	if(m_pBtSignup==NULL)
	{
		m_pBtSignup = CButtonUI::Create(m_pManager,this,TEXT(""));
		m_pBtSignup->SetStatusImage(TEXT("file='BT_SIGNUP' restype='PNG'"));
		m_pBtSignup->SetPos((nWidth-m_pBtSignup->GetFixedWidth())/2,184);
		m_pBtSignup->OnEvent += MakeDelegate(&OnButtonEvent);		
		m_pBtSignup->SetFadeOut(false);
	}

	//ȡ������
	if(m_pBtUnSignup==NULL)
	{
		m_pBtUnSignup = CButtonUI::Create(m_pManager,this,TEXT(""));
		m_pBtUnSignup->SetStatusImage(TEXT("file='BT_UNSIGNUP' restype='PNG'"));
		m_pBtUnSignup->SetPos((nWidth-m_pBtSignup->GetFixedWidth())/2,184);
		m_pBtUnSignup->OnEvent += MakeDelegate(&OnButtonEvent);
		m_pBtUnSignup->SetFadeOut(false);
		m_pBtUnSignup->SetVisible(false);
	}

	//�������
	if(m_pEnterMatch==NULL)
	{
		m_pEnterMatch = CTextUI::Create(m_pManager,this,TEXT(""));
		m_pEnterMatch->SetText(TEXT("{a}{f 0}<u><c #00FF0000>�������</c></u>{/f}{/a}"));
		m_pEnterMatch->OnEvent += MakeDelegate(&OnButtonEvent);
		m_pEnterMatch->SetFixedWidth(80);
		m_pEnterMatch->SetFixedHeight(14);
		m_pEnterMatch->SetPos(18,165);
		m_pEnterMatch->SetShowHtml(true);
	}
	
	//�鿴�ɼ�
	if(m_pCheckScore==NULL)
	{
		m_pCheckScore = CTextUI::Create(m_pManager,this,TEXT(""));
		m_pCheckScore->SetText(TEXT("{a}{f 0}<u><c #00FF0000>�鿴�ɼ�</c></u>{/f}{/a}"));
		m_pCheckScore->OnEvent += MakeDelegate(&OnButtonEvent);
		m_pCheckScore->SetFixedWidth(80);
		m_pCheckScore->SetFixedHeight(14);
		m_pCheckScore->SetPos(115,165);
		m_pCheckScore->SetShowHtml(true);
	}

	//��������
	if(m_pMatchIntroduce==NULL)
	{
		m_pMatchIntroduce = CTextUI::Create(m_pManager,this,TEXT(""));
		m_pMatchIntroduce->SetText(TEXT("{a}{f 0}<u><c #000000FF>��˲鿴</c></u>{/f}{/a}"));
		m_pMatchIntroduce->OnEvent += MakeDelegate(&OnButtonEvent);
		m_pMatchIntroduce->SetFixedWidth(80);
		m_pMatchIntroduce->SetFixedHeight(14);
		m_pMatchIntroduce->SetPos(78,145);
		m_pMatchIntroduce->SetShowHtml(true);
	}

	//���ñ�ʶ	
	m_pBtUnSignup->SetTag(MATCH_COMMAND_UNSIGNUP);
	m_pEnterMatch->SetTag(MATCH_COMMAND_ENTER);
	m_pCheckScore->SetTag(MATCH_COMMAND_CHECKSCORE);
	m_pMatchIntroduce->SetTag(MATCH_COMMAND_INTRODUCE);	
	m_pBtSignup->SetTag(GameMatch.cbMatchType==MATCH_TYPE_LOCKTIME?MATCH_COMMAND_SIGNUP:MATCH_COMMAND_ENTER);

	//������Դ
	UpdateResource();

	//���ô�С
	SetFixedWidth(nWidth);
	SetFixedHeight(hHeight);
}

//////////////////////////////////////////////////////////////////////////////////

//���캯��
CGameViewPage::CGameViewPage()
{
	//���ñ���
	m_bExpanding=false;
	m_fExpandTime=0.f;	
	m_dwStartTime=0;
	m_fZoomScall=KIND_ITEM_ZOOM_MIN;

	//ҳ����Ϣ
	m_PageType=PAGE_TYPE_NULL;
	m_wPageIndex=INVALID_WORD;	
	m_pViewLayoutAttribute=NULL;

	//�ӿڱ���
	m_pIViewPageSubItemSink=NULL;
}

//��������
CGameViewPage::~CGameViewPage()
{
}

//�¼�����
void CGameViewPage::DoEvent(TEventUI& event)
{
	if( event.Type == UIEVENT_TIMER )
	{
		//չ������
		if (event.wParam==IDI_ZOOM_SUB_ITEM)
		{
			DWORD dwDiffTime = GetTickCount()-m_dwStartTime;
            m_fZoomScall = KIND_ITEM_ZOOM_MAX-(KIND_ITEM_ZOOM_MAX-KIND_ITEM_ZOOM_MIN)*(dwDiffTime/(m_fExpandTime*1000.f));			 
			if(m_fZoomScall<=KIND_ITEM_ZOOM_MIN)
			{
				//ʹ������
				SetEnabled(true);

				//���ñ���
				m_bExpanding=false;
				m_fZoomScall=KIND_ITEM_ZOOM_MIN;
				m_pManager->KillTimer(this,IDI_ZOOM_SUB_ITEM);
			}

			//��������
			RectifySubItem();

			return;
		}
	}

	if( m_pParent != NULL ) m_pParent->DoEvent(event);
}

//����ҳ��
VOID CGameViewPage::ActivePage(WORD wPageIndex,
							   emPageType PageType,
							   IViewPageSubItemSink * pIViewPageSubItemSink,
							   tagViewLayoutAttribute* pViewLayoutAttribute)
{
	//���ñ���
	m_PageType=PageType;
	m_wPageIndex=wPageIndex;
	m_pViewLayoutAttribute=pViewLayoutAttribute;
	m_pIViewPageSubItemSink=pIViewPageSubItemSink;
}

//��������
VOID CGameViewPage::AddPageSubItem(WORD wIndex,
								   INT nItemWidth,
								   INT nItemHeight,
								   VOID * pSubItemData)
{
	CString strLog;


		

	//�ж�����
	if(m_PageType==PAGE_TYPE_NULL) return;

	//��������
	if(m_PageType==PAGE_TYPE_APP)
	{
		CGameViewAppItem * pViewKindItem = static_cast<CGameViewAppItem *>(GetItemAt(wIndex));
		if(pViewKindItem==NULL)
		{
			try
			{
				pViewKindItem=new CGameViewAppItem();
				if(pViewKindItem!=NULL) AddAt(pViewKindItem,wIndex);
			}
			catch(...)
			{
				ASSERT(FALSE);
				pViewKindItem=NULL;
			}
		}
		if(pViewKindItem!=NULL)
		{
			pViewKindItem->SetManager(m_pManager,this);
			pViewKindItem->SetInternVisible(true);
			pViewKindItem->ActiveSubItem(nItemWidth,nItemHeight,pSubItemData);
		}
	}

	//��������
	if(m_PageType==PAGE_TYPE_KIND)
	{
			//��־
		strLog.Format(_T("�����ӷ��䷿������%s,%s,%d,wIndex:%d,nItemWidth:%d,nItemHeight:%d,"), 
					PREFIX_LOG,__FUNCTIONW__, __LINE__,
					wIndex,
					nItemWidth,
					nItemHeight);
	//	g_FileLog.Write(strLog);


		CGameViewKindItem * pViewKindItem = static_cast<CGameViewKindItem *>(GetItemAt(wIndex));
		if(pViewKindItem==NULL)
		{
				
			try
			{
				//g_FileLog.Write(_T("CGameViewPage::AddPageSubItem2"));
				pViewKindItem=new CGameViewKindItem();
				if(pViewKindItem!=NULL) AddAt(pViewKindItem,wIndex);
			}
			catch(...)
			{
				ASSERT(FALSE);
				pViewKindItem=NULL;
			}
		}
		if(pViewKindItem!=NULL)
		{
				
			pViewKindItem->SetManager(m_pManager,this);
			pViewKindItem->SetInternVisible(true);
			pViewKindItem->ActiveSubItem(nItemWidth,nItemHeight,pSubItemData);
		}
	}

	//��������
	if(m_PageType==PAGE_TYPE_MATCH)
	{
		CGameViewMatchItem * pViewMatchItem = static_cast<CGameViewMatchItem *>(GetItemAt(wIndex));
		if(pViewMatchItem==NULL)
		{
			try
			{
				pViewMatchItem=new CGameViewMatchItem();
				if(pViewMatchItem!=NULL) AddAt(pViewMatchItem,wIndex);
			}
			catch(...)
			{
				ASSERT(FALSE);
				pViewMatchItem=NULL;
			}
		}
		if(pViewMatchItem!=NULL)
		{
			pViewMatchItem->SetManager(m_pManager,this);
			pViewMatchItem->SetInternVisible(true);
			pViewMatchItem->ActiveSubItem(nItemWidth,nItemHeight,pSubItemData);			
		}
	}

	//��������
	if(m_PageType==PAGE_TYPE_SERVER)
	{

	

		CGameViewServerItem * pViewServerItem = static_cast<CGameViewServerItem *>(GetItemAt(wIndex));
		if(pViewServerItem==NULL)
		{
			try
			{
				pViewServerItem = new CGameViewServerItem();
				if(pViewServerItem!=NULL) AddAt(pViewServerItem,wIndex);
			}
			catch(...)
			{
				ASSERT(FALSE);
				pViewServerItem=NULL;
			}
		}
		if(pViewServerItem!=NULL)
		{
			pViewServerItem->SetManager(m_pManager,this);
			pViewServerItem->SetInternVisible(true);
			pViewServerItem->ActiveSubItem(nItemWidth,nItemHeight,pSubItemData);
		}
	}

	return;
}

//��������
VOID CGameViewPage::RectifySubItem()
{
	//��������
	if(m_pViewLayoutAttribute==NULL) return;

	//����У��
	ASSERT(m_pViewLayoutAttribute->wItemXCount*m_pViewLayoutAttribute->wItemYCount>0);
	if(m_pViewLayoutAttribute->wItemXCount*m_pViewLayoutAttribute->wItemYCount==0) return;

	//��������
	CRect rcItemPos;
	CPoint ptCenter,ptItemCenter;
	CSize SizeViewPage(GetFixedWidth(),GetFixedHeight());

	//������
	INT nItemXSpace = 0;
	INT nItemYSpace = 0;
	if(m_pViewLayoutAttribute->wItemXCount==1)
	{
		m_pViewLayoutAttribute->rcItemMargin.left=(SizeViewPage.cx-m_pViewLayoutAttribute->SizeItem.cx*m_pViewLayoutAttribute->wItemXCount)/2;
		m_pViewLayoutAttribute->rcItemMargin.right = m_pViewLayoutAttribute->rcItemMargin.left;
	}
	else
	{
		nItemXSpace=(SizeViewPage.cx-m_pViewLayoutAttribute->rcItemMargin.left-m_pViewLayoutAttribute->rcItemMargin.right-m_pViewLayoutAttribute->SizeItem.cx*m_pViewLayoutAttribute->wItemXCount)/(m_pViewLayoutAttribute->wItemXCount-1);
	}

	if(m_pViewLayoutAttribute->wItemYCount==1)
	{
		 m_pViewLayoutAttribute->rcItemMargin.top=(SizeViewPage.cy-m_pViewLayoutAttribute->SizeItem.cy*m_pViewLayoutAttribute->wItemYCount)/2;
		 m_pViewLayoutAttribute->rcItemMargin.bottom=m_pViewLayoutAttribute->rcItemMargin.top;
	}
	else
	{
		 nItemYSpace = (SizeViewPage.cy-m_pViewLayoutAttribute->rcItemMargin.top-m_pViewLayoutAttribute->rcItemMargin.bottom-m_pViewLayoutAttribute->SizeItem.cy*m_pViewLayoutAttribute->wItemYCount)/(m_pViewLayoutAttribute->wItemYCount-1);
	}

	//����λ��
	ptCenter.x = (m_pViewLayoutAttribute->rcItemMargin.left+(SizeViewPage.cx-m_pViewLayoutAttribute->rcItemMargin.left-m_pViewLayoutAttribute->rcItemMargin.right)/2);
	ptCenter.y = (m_pViewLayoutAttribute->rcItemMargin.top+(SizeViewPage.cy-m_pViewLayoutAttribute->rcItemMargin.top-m_pViewLayoutAttribute->rcItemMargin.bottom)/2);

	ptCenter.x = 0;//(m_pViewLayoutAttribute->rcItemMargin.left+(SizeViewPage.cx-m_pViewLayoutAttribute->rcItemMargin.left-m_pViewLayoutAttribute->rcItemMargin.right)/2);
	ptCenter.y = 0;//(m_pViewLayoutAttribute->rcItemMargin.top+(SizeViewPage.cy-m_pViewLayoutAttribute->rcItemMargin.top-m_pViewLayoutAttribute->rcItemMargin.bottom)/2);

	//��������
	CControlUI * pControlUI=NULL;
	INT nDestXPos;
	INT nDestYPos;

	const int nXSpace = 18;
	const int nYSpace = 30;

	//����λ��
	for(INT nIndex=0;nIndex<GetCount();nIndex++)
	{
		m_pViewLayoutAttribute->SizeItem.cx = SizeViewPage.cx - 20;

		////����Ŀ��λ��
		//nDestXPos = m_pViewLayoutAttribute->rcItemMargin.left+(nIndex%m_pViewLayoutAttribute->wItemXCount)*(m_pViewLayoutAttribute->SizeItem.cx+nItemXSpace);
		//nDestYPos = m_pViewLayoutAttribute->rcItemMargin.top+(nIndex/m_pViewLayoutAttribute->wItemXCount)*(m_pViewLayoutAttribute->SizeItem.cy+nItemYSpace);

		////��������
		//ptItemCenter.x = ptCenter.x+LONG((nDestXPos+m_pViewLayoutAttribute->SizeItem.cx/2-ptCenter.x)*m_fZoomScall);
		//ptItemCenter.y = ptCenter.y+LONG((nDestYPos+m_pViewLayoutAttribute->SizeItem.cy/2-ptCenter.y)*m_fZoomScall);

		////��������
		//rcItemPos.left = ptItemCenter.x-LONG(m_pViewLayoutAttribute->SizeItem.cx/2*m_fZoomScall);
		//rcItemPos.top =  ptItemCenter.y-LONG(m_pViewLayoutAttribute->SizeItem.cy/2*m_fZoomScall);
		//rcItemPos.right = rcItemPos.left + LONG(m_pViewLayoutAttribute->SizeItem.cx*m_fZoomScall);
		//rcItemPos.bottom = rcItemPos.top + LONG(m_pViewLayoutAttribute->SizeItem.cy*m_fZoomScall);

		//��������
		rcItemPos.left	= nXSpace;//ptItemCenter.x-LONG(m_pViewLayoutAttribute->SizeItem.cx/2*m_fZoomScall);
		rcItemPos.top	= nYSpace + nIndex*50;//-LONG(m_pViewLayoutAttribute->SizeItem.cy/2*m_fZoomScall);
		rcItemPos.right = rcItemPos.left + LONG(m_pViewLayoutAttribute->SizeItem.cx*m_fZoomScall);
		rcItemPos.bottom= rcItemPos.top + LONG(m_pViewLayoutAttribute->SizeItem.cy*m_fZoomScall);

		//���ÿؼ�
		pControlUI = GetItemAt(nIndex);
		pControlUI->SetPos(rcItemPos);
		pControlUI->SetFixedWidth(rcItemPos.Width());
		pControlUI->SetFixedHeight(rcItemPos.Height());
		pControlUI->SetFixedXY(CPoint(rcItemPos.left,rcItemPos.top));
	}
}

//չ������
VOID CGameViewPage::ExpandSubItem(float fExpandTime)
{
	//У�����
	ASSERT(fExpandTime>0.f);
	if(fExpandTime<=0.f) return;

	//���ñ�ʶ
	m_bExpanding=true;
	m_fExpandTime=fExpandTime;	
	m_dwStartTime=GetTickCount();
	m_fZoomScall=KIND_ITEM_ZOOM_MAX;

	//ʹ������
	SetEnabled(false);

	//��������
	RectifySubItem();

	//����ʱ��
	m_pManager->SetTimer(this,IDI_ZOOM_SUB_ITEM,TIME_ZOOM_SUB_ITEM);
}

//////////////////////////////////////////////////////////////////////////////////

//���캯��
CPlazaViewGame::CPlazaViewGame()
{
	//���ñ���
	m_bCreateFlag=false;
	m_cbShowItemMode=VIEW_MODE_NONE;
	m_wFocusServerID=INVALID_WORD;
	m_wSwitchPageCurrent=INVALID_WORD;

	//λ�ñ���
	m_wKindTypeCurrentID=0;

	//���ñ���
	m_nViewPageXOffset=0;
	m_pCurrViewControl=NULL;

	//�ؼ�����
	m_pUpdateStatusView=NULL;

	//��ͼ����	
	ZeroMemory(&m_KindViewControl,sizeof(m_KindViewControl));
	ZeroMemory(&m_MatchViewControl,sizeof(m_MatchViewControl));
	ZeroMemory(&m_ServerViewControl,sizeof(m_ServerViewControl));
	ZeroMemory(&m_AppViewControl,sizeof(m_AppViewControl));

	//��������
	ZeroMemory(&m_KindLayoutAttribute,sizeof(m_KindLayoutAttribute));
	ZeroMemory(&m_MatchLayoutAttribute,sizeof(m_MatchLayoutAttribute));	
	ZeroMemory(&m_ServerLayoutAttribute,sizeof(m_ServerLayoutAttribute));
	ZeroMemory(&m_AppLayoutAttribute,sizeof(m_AppLayoutAttribute));
	
	//��������
	m_KindLayoutAttribute.wItemXCount=5;
	m_KindLayoutAttribute.wItemYCount=3;
	m_KindLayoutAttribute.SizeItem.SetSize(116,151);
	m_KindLayoutAttribute.rcItemMargin.SetRect(40,35,40,45);

	//��������
	m_MatchLayoutAttribute.wItemXCount=4;
	m_MatchLayoutAttribute.wItemYCount=2;
	m_MatchLayoutAttribute.SizeItem.SetSize(184,240);
	m_MatchLayoutAttribute.rcItemMargin.SetRect(30,15,30,15);

	//��������
	m_ServerLayoutAttribute.wItemXCount=4;
	m_ServerLayoutAttribute.wItemYCount=1;
	m_ServerLayoutAttribute.SizeItem.SetSize(116,151);
	m_ServerLayoutAttribute.rcItemMargin.SetRect(40,35,40,45);


	//�ֻ���Ϸ����
	m_AppLayoutAttribute.wItemXCount=5;
	m_AppLayoutAttribute.wItemYCount=3;
	m_AppLayoutAttribute.SizeItem.SetSize(116,151);
	m_AppLayoutAttribute.rcItemMargin.SetRect(40,35,40,45);

	//��ܻ���
	tagEncircleResource	EncircleRes;
	EncircleRes.pszImageTL	= MAKEINTRESOURCE(IDB_PLAZA_VIEW_GAME_TL);
	EncircleRes.pszImageTM	= MAKEINTRESOURCE(IDB_PLAZA_VIEW_GAME_TM);
	EncircleRes.pszImageTR	= MAKEINTRESOURCE(IDB_PLAZA_VIEW_GAME_TR);
	EncircleRes.pszImageML	= MAKEINTRESOURCE(IDB_PLAZA_VIEW_GAME_ML);
	EncircleRes.pszImageMR	= MAKEINTRESOURCE(IDB_PLAZA_VIEW_GAME_MR);
	EncircleRes.pszImageBL	= MAKEINTRESOURCE(IDB_PLAZA_VIEW_GAME_BL);
	EncircleRes.pszImageBM	= MAKEINTRESOURCE(IDB_PLAZA_VIEW_GAME_BM);
	EncircleRes.pszImageBR	= MAKEINTRESOURCE(IDB_PLAZA_VIEW_GAME_BR);
	m_EncircleRes.InitEncircleResource(EncircleRes,AfxGetInstanceHandle());

	return;
}

//��������
CPlazaViewGame::~CPlazaViewGame()
{
	//�ͷŶ���
	if(m_pUpdateStatusView != NULL) SafeDelete(m_pUpdateStatusView);

	//�Ƴ�����
	CContainerUI * pSuperParent = (CContainerUI *)GetControlByName(szContainerPageLayerControlName);
	if(pSuperParent!=NULL)
	{
		pSuperParent->Remove(m_KindViewControl.pPageContainer,false);
		pSuperParent->Remove(m_MatchViewControl.pPageContainer,false);
		pSuperParent->Remove(m_ServerViewControl.pPageContainer,false);
		pSuperParent->Remove(m_AppViewControl.pPageContainer,false);

	}

	//�ͷŶ���
	if(m_KindViewControl.pPageContainer) SafeDelete(m_KindViewControl.pPageContainer);
	if(m_MatchViewControl.pPageContainer) SafeDelete(m_MatchViewControl.pPageContainer);
	if(m_ServerViewControl.pPageContainer) SafeDelete(m_ServerViewControl.pPageContainer);	
	if(m_AppViewControl.pPageContainer) SafeDelete(m_AppViewControl.pPageContainer);	

	//ɾ������
	m_GameKindInfoBuffer.Append(m_GameKindInfoActive);
	for (INT i=0;i<m_GameKindInfoBuffer.GetCount();i++)
	{
		SafeDelete(m_GameKindInfoBuffer[i]);
	}

	//ɾ������
	m_GameMatchInfoBuffer.Append(m_GameMatchInfoActive);
	for (INT i=0;i<m_GameMatchInfoBuffer.GetCount();i++)
	{
		SafeDelete(m_GameMatchInfoBuffer[i]);
	}

	//ɾ������
	m_GameServerInfoBuffer.Append(m_GameServerInfoActive);
	for (INT i=0;i<m_GameServerInfoBuffer.GetCount();i++)
	{
		SafeDelete(m_GameServerInfoBuffer[i]);
	}	

	return;
}

//���͵��
void CPlazaViewGame::OnViewPageKindItemClicked(tagGameKindInfo * pGameKindInfo)
{
	//����У��
	if(pGameKindInfo==NULL) return;

	//��������
	WORD wKindID = pGameKindInfo->pGameKindItem->m_GameKind.wKindID;

	//���Ҷ���
	CServerListData * pServerListData=CServerListData::GetInstance();
	CGameKindItem * pGameKindItem=pServerListData->SearchGameKind(wKindID);

	//�����ж�
	if(pGameKindItem->m_GameKind.wGameID==0)
	{
		//��ʾ��Ϣ
		CInformation Information(this);
		Information.ShowMessageBox(TEXT("�������ߣ������ڴ���"),MB_ICONINFORMATION);

		return;
	}

	//�¼�����
	if (pGameKindItem!=NULL)
	{
		//��װ�ж�
		if (pGameKindItem->m_dwProcessVersion==0L)
		{
			//��װ��Ϸ
		//	CGlobalUnits * pGlobalUnits=CGlobalUnits::GetInstance();
		//	pGlobalUnits->DownLoadClient(pGameKindItem->m_GameKind.szKindName,wKindID,0);

				//��������
				CMissionList * pMissionList=CMissionList::GetInstance();
				if (pMissionList!=NULL) pMissionList->UpdateServerInfo(pGameKindItem->m_GameKind.wKindID);


			return;
		}
		else
		{
			//��������
			DWORD dwNowTime=(DWORD)time(NULL);
			bool bTimeOut=(dwNowTime>=(pGameKindItem->m_dwUpdateTime+1L));

			//�����ж�
			if (bTimeOut==true)
			{
				//�����б�
				pGameKindItem->m_dwUpdateTime=(DWORD)time(NULL);

				//��������
				CMissionList * pMissionList=CMissionList::GetInstance();
				if (pMissionList!=NULL) pMissionList->UpdateServerInfo(pGameKindItem->m_GameKind.wKindID);
			}
		}		
	}
}

//������
void CPlazaViewGame::OnViewPageServerItemClicked(tagGameServerInfo * pGameServerInfo)
{
	//��ȡ����
	CPlatformFrame * pPlatformFrame=CPlatformFrame::GetInstance();
	CServerListData * pServerListData=CServerListData::GetInstance();

	//���뷿��
	CGameServerItem * pGameServerItem=pServerListData->SearchGameServer(pGameServerInfo->wServerID);
	
	if (pGameServerItem!=NULL) pPlatformFrame->EntranceServerItem(pGameServerItem);

	return;
}
//�������
void CPlazaViewGame::OnViewPageMatchItemClicked(tagGameMatchInfo * pGameMatchInfo,WORD wCommandID)
{
	switch(wCommandID)
	{
	case MATCH_COMMAND_SIGNUP:		//��������
		{
			//��ȡ����
			m_MissionMatch.PerformSignupMatch(pGameMatchInfo);

			break;
		}
	case MATCH_COMMAND_UNSIGNUP:	//ȡ������
		{
			//��ȡ����
			m_MissionMatch.PerformUnSignupMatch(pGameMatchInfo);

			break;
		}
	case MATCH_COMMAND_CHECKSCORE:	//�鿴�ɼ�
		{
			//��ȡ����
			tagGameMatch * pGameMatch = &pGameMatchInfo->pGameServerItem->m_GameMatch;

			//��ȡ����
			ASSERT(CGlobalWebLink::GetInstance()!=NULL);
			CGlobalWebLink * pGlobalWebLink=CGlobalWebLink::GetInstance();			

			//�����ַ
			TCHAR szNavigation[256]=TEXT("");
			_sntprintf(szNavigation,CountArray(szNavigation),TEXT("%s/Match/MatchOrder.aspx?param=%d&num=%d&type=%d"),pGlobalWebLink->GetPlatformLink(),pGameMatch->dwMatchID,pGameMatch->dwMatchNO,pGameMatch->cbMatchType);

			//��ҳ��
			ShellExecute(NULL,TEXT("OPEN"),szNavigation,NULL,NULL,SW_NORMAL);

			break;
		}
	case MATCH_COMMAND_INTRODUCE:	//��������
		{			
			//��ȡ����
			tagGameMatch * pGameMatch = &pGameMatchInfo->pGameServerItem->m_GameMatch;

			//��ȡ����
			ASSERT(CGlobalWebLink::GetInstance()!=NULL);
			CGlobalWebLink * pGlobalWebLink=CGlobalWebLink::GetInstance();			

			//�����ַ
			TCHAR szNavigation[256]=TEXT("");
			_sntprintf(szNavigation,CountArray(szNavigation),TEXT("%s/Match/MatchView.aspx?param=%d&num=%d&type=%d"),pGlobalWebLink->GetPlatformLink(),pGameMatch->dwMatchID,pGameMatch->dwMatchNO,pGameMatch->cbMatchType);

			//��ҳ��
			ShellExecute(NULL,TEXT("OPEN"),szNavigation,NULL,NULL,SW_NORMAL);

			break;
		}
	case MATCH_COMMAND_ENTER:		//�������
		{
			//�������
			tagGameKindInfo GameKindInfo;			
			GameKindInfo.pGameKindItem=pGameMatchInfo->pGameServerItem->m_pGameKindItem;
			GameKindInfo.wSortID=pGameMatchInfo->pGameServerItem->m_pGameKindItem->GetSortID();

			//���ñ���
			m_wFocusServerID=pGameMatchInfo->pGameServerItem->m_GameServer.wServerID;

			//ģ����
			OnViewPageKindItemClicked(&GameKindInfo);

			break;
		}
	}
}

//�������
VOID CPlazaViewGame::OnEventDownLoadTaskFinish()
{
	//������Դ
	UpdateServerViewItem();

	//��ȡ��ʶ
	ASSERT(CGlobalUnits::GetInstance()!=NULL);
	WORD wServerID = CGlobalUnits::GetInstance()->GetTrackServerID();
	if(wServerID != 0)
	{
		//��������
		tagGameServerInfo GameServerInfo;
		ZeroMemory(&GameServerInfo,sizeof(GameServerInfo));

		//����ṹ
		GameServerInfo.wServerID=wServerID;
		OnViewPageServerItemClicked(&GameServerInfo);
	}
}

//������
VOID CPlazaViewGame::OnEventUpdateCheckFinish(bool bNeedUpdate)
{	
	if(bNeedUpdate == false)
	{
		//��ȡ��ʶ
		ASSERT(CGlobalUnits::GetInstance()!=NULL);
		WORD wServerID = CGlobalUnits::GetInstance()->GetTrackServerID();
		if(wServerID != 0)
		{
			//��������
			tagGameServerInfo GameServerInfo;
			ZeroMemory(&GameServerInfo,sizeof(GameServerInfo));

			//����ṹ
			GameServerInfo.wServerID=wServerID;
			OnViewPageServerItemClicked(&GameServerInfo);
		}
	}
}

//��ʼ�滭
void CPlazaViewGame::OnBeginPaintWindow(HDC hDC)
{
	//��������
	CDC * pDC = CDC::FromHandle(hDC);

	//��ȡλ��
	CRect rctClient;
	GetClientRect(&rctClient);

	//��䱳��
	pDC->FillSolidRect(&rctClient,RGB(12,63,115));
	//pDC->FillSolidRect(&rctClient,CLR_RED);

	//�滭���
	m_EncircleRes.DrawEncircleFrame(pDC,rctClient);

	//title
	//���λ��
	tagEncircleInfo EncircleResInfo;
	m_EncircleRes.GetEncircleInfo(EncircleResInfo);

	CPngImage pngImgTitle;
	pngImgTitle.LoadImage(AfxGetInstanceHandle(),TEXT("PNG_PLAZA_VIEW_GAME_TITILE"));
	pngImgTitle.DrawImage(pDC,8,9);

	return;
}

//�����滭
void CPlazaViewGame::OnEndPaintWindow(HDC hDC)
{
	//��������
	CDC * pDC = CDC::FromHandle(hDC);

	//����λ��
	CRect rctWindow;
	GetWindowRect(&rctWindow);

	//��ȡλ��
	CRect rctClient;
	GetClientRect(&rctClient);

	//���λ��
	tagEncircleInfo FrameEncircleInfo;
	m_EncircleRes.GetEncircleInfo(FrameEncircleInfo);

	//��ȡ����
	CPlatformFrame * pPlatformFrame = CPlatformFrame::GetInstance();
	CRect rcTypeArrow = pPlatformFrame->MapSelectedTypeRect();	

	////����ͼƬ
	//CPngImage ImageArrow;
	//ImageArrow.LoadImage(AfxGetInstanceHandle(),TEXT("GAME_TYPE_ARROW"));
	//ImageArrow.DrawImage(pDC,rcTypeArrow.left+(rcTypeArrow.Width()-ImageArrow.GetWidth())/2,0);

	if(m_cbShowItemMode == VIEW_MODE_APP)
	{
		//�ֻ�������׿��
		CPngImage ImageArrow_android;
		ImageArrow_android.LoadImage(AfxGetInstanceHandle(),TEXT("android_index"));
		ImageArrow_android.DrawImage(pDC,rctWindow.Width()/2-210,rctWindow.Height()-250);

		CPngImage ImageArrow_android_text;
		ImageArrow_android_text.LoadImage(AfxGetInstanceHandle(),TEXT("android_index_text"));
		ImageArrow_android_text.DrawImage(pDC,rctWindow.Width()/2-210+50,rctWindow.Height()-40);


		//�ֻ�����ƻ����
		CPngImage ImageArrow_ios;
		ImageArrow_ios.LoadImage(AfxGetInstanceHandle(),TEXT("ios_index"));
		ImageArrow_ios.DrawImage(pDC,rctWindow.Width()/2+10,rctWindow.Height()-250);

		CPngImage ImageArrow_ios_text;
		ImageArrow_ios_text.LoadImage(AfxGetInstanceHandle(),TEXT("ios_index_text"));
		ImageArrow_ios_text.DrawImage(pDC,rctWindow.Width()/2+10+50,rctWindow.Height()-40);
	}
}

//��Ϣ����
void CPlazaViewGame::Notify(TNotifyUI &  msg)
{
	//��ȡ����
	CControlUI * pControlUI = msg.pSender;

	//����¼�
	if (lstrcmp(msg.sType, TEXT("click")) == 0)
	{
		if(lstrcmp(pControlUI->GetName(), szButtonKindLeftControlName)==0) 
		{
			return OnClickedLeftPageView();			
		}
		else if(lstrcmp(pControlUI->GetName(), szButtonKindRightControlName)==0)
		{
			return OnClickedRightPageView();
		}
	}
}

//��ʼ�ؼ�
void CPlazaViewGame::InitControlUI()
{
	//��ȡ����
	CContainerUI * pPageLayer = (CContainerUI *)GetControlByName(TEXT("PageLayer"));
	if(pPageLayer==NULL) return;

	//��������
	m_KindViewControl.pPageContainer = new CContainerUI;
	m_KindViewControl.pPageContainer->SetManager(&m_PaintManager,pPageLayer);
	m_KindViewControl.pPageContainer->SetFloat(false);

	//��������
	m_MatchViewControl.pPageContainer = new CContainerUI;
	m_MatchViewControl.pPageContainer->SetManager(&m_PaintManager,pPageLayer);
	m_MatchViewControl.pPageContainer->SetFloat(false);	

	//��������
	m_ServerViewControl.pPageContainer = new CContainerUI;
	m_ServerViewControl.pPageContainer->SetManager(&m_PaintManager,pPageLayer);
	m_ServerViewControl.pPageContainer->SetFloat(false);

	//�ֻ���Ϸ����
	m_AppViewControl.pPageContainer = new CContainerUI;
	m_AppViewControl.pPageContainer->SetManager(&m_PaintManager,pPageLayer);
	m_AppViewControl.pPageContainer->SetFloat(false);
}

//��������
void CPlazaViewGame::SetCustomAttribute(LPCTSTR pszName,LPCTSTR pszValue)
{
	//��������
	LPTSTR pstr = NULL;
	if( lstrcmp(pszName,TEXT("kindxcount")) ==0 )
	{
		m_KindLayoutAttribute.wItemXCount = _ttoi(pszValue);
	}
	else if(lstrcmp(pszName,TEXT("kindycount")) ==0 )
	{
		m_KindLayoutAttribute.wItemYCount = _ttoi(pszValue);
	}
	else if( lstrcmp(pszName,TEXT("serverxcount")) ==0 )
	{
		m_ServerLayoutAttribute.wItemXCount = __max(_ttoi(pszValue),1);		
	}
	else if(lstrcmp(pszName,TEXT("serverycount")) ==0 )
	{
		m_ServerLayoutAttribute.wItemYCount = __max(_ttoi(pszValue),1);
	}
	else if(lstrcmp(pszName,TEXT("kindsize")) ==0 )
	{
		m_KindLayoutAttribute.SizeItem.cx = _tcstol(pszValue, &pstr, 10);
		m_KindLayoutAttribute.SizeItem.cy = _tcstol(pstr + 1, &pstr, 10);
	}
	else if(lstrcmp(pszName,TEXT("serversize")) ==0 )
	{
		m_ServerLayoutAttribute.SizeItem.cx = _tcstol(pszValue, &pstr, 10);
		m_ServerLayoutAttribute.SizeItem.cy = _tcstol(pstr + 1, &pstr, 10);
	}
	else if(lstrcmp(pszName,TEXT("kindpadding")) ==0 )
	{		
		m_KindLayoutAttribute.rcItemMargin.left = _tcstol(pszValue, &pstr, 10);
        m_KindLayoutAttribute.rcItemMargin.top = _tcstol(pstr + 1, &pstr, 10);
        m_KindLayoutAttribute.rcItemMargin.right = _tcstol(pstr + 1, &pstr, 10);
        m_KindLayoutAttribute.rcItemMargin.bottom = _tcstol(pstr + 1, &pstr, 10);
	}	
	else if(lstrcmp(pszName,TEXT("serverpadding")) ==0 )
	{		
		m_ServerLayoutAttribute.rcItemMargin.left = _tcstol(pszValue, &pstr, 10);
        m_ServerLayoutAttribute.rcItemMargin.top = _tcstol(pstr + 1, &pstr, 10);
        m_ServerLayoutAttribute.rcItemMargin.right = _tcstol(pstr + 1, &pstr, 10);
        m_ServerLayoutAttribute.rcItemMargin.bottom = _tcstol(pstr + 1, &pstr, 10);
	}
}

//��ʾ����
VOID CPlazaViewGame::ShowKindItemView(WORD wTypeID,BOOL bResetPageIndex)
{
	//��������
	if(m_pUpdateStatusView !=NULL ) m_pUpdateStatusView->EndUpdateStatus();

/*
	//��ʾ��Ϣ
		TCHAR szBuffer[256]=TEXT("");
		_sntprintf(szBuffer,CountArray(szBuffer),TEXT("ShowKindItemView [ %d ] "),wTypeID);




	CInformation Information;
		Information.ShowMessageBox(szBuffer,MB_ICONINFORMATION,30L);

		*/
	//��������
	if(wTypeID ==MATCH_TYPE_ID )//
	{
		//���±���
		CMissionList * pMissionList=CMissionList::GetInstance();
		if (pMissionList!=NULL) pMissionList->UpdateMatchInfo();

		return ShowMatchItemView(bResetPageIndex);
	}

	//�����زƸ���Ϸ
	//Ϊ�ƹ��ã��Ż������ֻ���Ϸ
	//��������
	if(wTypeID == 5)
	{
		return ShowMobileAppItemView(bResetPageIndex);
	}

	//��ȡ����
	ASSERT(CServerListData::GetInstance()!=NULL);
	CServerListData * pServerListData=CServerListData::GetInstance();

	//����Ŀ¼
	TCHAR szDirectory[MAX_PATH]=TEXT("");
	CWHService::GetWorkDirectory(szDirectory,CountArray(szDirectory));

	//��������
	POSITION Position=NULL;
	CGameKindItem * pGameKindItem=NULL;
	tagGameKindInfo * pGameKindInfo=NULL;

	//ɾ������
	for (INT i=0;i<m_GameKindInfoActive.GetCount();i++)
	{
		//��ȡ����
		ASSERT(m_GameKindInfoActive[i]!=NULL);
		pGameKindInfo=m_GameKindInfoActive[i];

		//���ñ���
		pGameKindInfo->wSortID=0;
		pGameKindInfo->pGameKindItem=NULL;
	}

	//ɾ������
	m_GameKindInfoBuffer.Append(m_GameKindInfoActive);
	m_GameKindInfoActive.RemoveAll();

	//�������
	while (true)
	{
	
		//��ȡ����
		pGameKindItem=pServerListData->EmunGameKindItem(Position);

		//�����ж�
		if (pGameKindItem==NULL) break;

	
		//�����ж�
		if ((pGameKindItem->m_GameKind.wTypeID!=wTypeID) && pGameKindItem->m_GameKind.wJoinID!=wTypeID)
		{
			if (Position==NULL) break;
			if (Position!=NULL) continue;//ethj���������ע�ͣ��ڸս�����ʱ�򣬻���������������Ϊû�����ͣ�ֱ������
		}

	

		//��ȡ����
		if (m_GameKindInfoBuffer.GetCount()>0L)
		{
			//��ȡ����
			INT_PTR nCount=m_GameKindInfoBuffer.GetCount();
			pGameKindInfo=m_GameKindInfoBuffer[nCount-1L];

			//ɾ������
			ASSERT(pGameKindInfo!=NULL);
			m_GameKindInfoBuffer.RemoveAt(nCount-1L);
		}
		else
		{
			try
			{
				pGameKindInfo=new tagGameKindInfo;
				if (pGameKindInfo==NULL) throw TEXT("��������ʧ��");
			}
			catch (...)
			{
				ASSERT(FALSE);
				break;
			}
		}

		//���ö���
		pGameKindInfo->pGameKindItem=pGameKindItem;
		pGameKindInfo->wSortID=pGameKindItem->m_GameKind.wSortID;

		//�������
		for (INT nItem=0;nItem<m_GameKindInfoActive.GetCount();nItem++)
		{
			//��ȡ����
			ASSERT(m_GameKindInfoActive[nItem]!=NULL);
			tagGameKindInfo * pGameKindTemp=m_GameKindInfoActive[nItem];

			//�����ж�
			if (pGameKindInfo->wSortID<pGameKindTemp->wSortID)
			{
				m_GameKindInfoActive.InsertAt(nItem,pGameKindInfo);
				break;
			}
		}

		//Ĭ�ϲ���
		if (nItem==m_GameKindInfoActive.GetCount())
		{
			m_GameKindInfoActive.Add(pGameKindInfo);
		}

		//�����ж�
		if (Position==NULL)
		{
			break;
		}
		
	}

	//�رն�ʱ��
	KillTimer(IDI_SWITCH_VIEW_PAGE);

	//��������
	CContainerUI * pSuperParent=NULL;
	CContainerUI * pPageContainer=m_KindViewControl.pPageContainer;	

	//���ø�����
	pSuperParent = (CContainerUI *)GetControlByName(szContainerPageLayerControlName);	
	if(pSuperParent!=NULL)
	{
		if(pSuperParent->GetItemAt(0)!=NULL) pSuperParent->RemoveAt(0,false);
		pSuperParent->AddAt(pPageContainer,0);		
	}

	//��������
	pPageContainer->SetInternVisible(false);	
	pPageContainer->CControlUI::SetInternVisible(true);

	//������Ŀ
	WORD wItemCount = m_KindLayoutAttribute.wItemXCount*m_KindLayoutAttribute.wItemYCount;	
	m_KindViewControl.wPageCount = (WORD)ceil(m_GameKindInfoActive.GetCount()/(double)wItemCount);

	//��������
	CGameViewPage * pPlazaViewPage=NULL;

	//����ҳ��
	for(WORD wIndex=0;wIndex<m_KindViewControl.wPageCount;wIndex++)
	{
		//����ҳ��
		pPlazaViewPage = GetPlazaViewPage(pPageContainer,wIndex);
		if(pPlazaViewPage!=NULL)
		{
			pPlazaViewPage->SetFloat(true);
			pPlazaViewPage->SetManager(&m_PaintManager,pPageContainer);			
			pPlazaViewPage->ActivePage(wIndex,PAGE_TYPE_KIND,this,&m_KindLayoutAttribute);			
		}
	}

    //��������(��ʾ����),


		CString strLog;
		//��־
		strLog.Format(_T("��������(��ʾ����)%s,%s,%d,wIndex:%d"), 
					PREFIX_LOG,__FUNCTIONW__, __LINE__,
					m_GameKindInfoActive.GetCount());
		//g_FileLog.Write(strLog);

	/*
	for(INT_PTR nIndex=0;nIndex<m_GameKindInfoActive.GetCount();nIndex++)
	{
		pPlazaViewPage = static_cast<CGameViewPage *>(pPageContainer->GetItemAt(WORD(nIndex/wItemCount)));
		if(pPlazaViewPage!=NULL)
		{
			pPlazaViewPage->AddPageSubItem(WORD(nIndex%wItemCount),m_KindLayoutAttribute.SizeItem.cx,m_KindLayoutAttribute.SizeItem.cy,m_GameKindInfoActive[nIndex]);
		}

		
	}
	*/
		//ethj �ĳɷ����б������ƹ�����һ��ini,Ҫ��ʾ��roomid�����ӽ�ȥ���ĳ�������û�и��µ�״̬�ˣ�,���ڸĳ�10��ֻ�жϵ���
	//��������

			ASSERT(CPlatformFrame::GetInstance()!=NULL);
			CPlazaViewGame * pPlazaViewItem = CPlatformFrame::GetInstance()->GetPlazaViewGame();

			//��ʾ��ͼ
			pPlazaViewItem->ShowServerItemView(40,false,false);
			/*	pPlazaViewItem->ShowServerItemView(20,false,true);
					pPlazaViewItem->ShowServerItemView(30,false,true);
						pPlazaViewItem->ShowServerItemView(40,false,true);
						pPlazaViewItem->ShowServerItemView(100,false,true);
						pPlazaViewItem->ShowServerItemView(306,false,true);
*/


	//���ñ���
	m_nViewPageXOffset=0;
	m_wKindTypeCurrentID=wTypeID;
	m_cbShowItemMode=VIEW_MODE_KIND;
	m_wSwitchPageCurrent=INVALID_WORD;
	m_pCurrViewControl=&m_KindViewControl;

	//��������
	if(bResetPageIndex==TRUE) m_pCurrViewControl->wPageCurrent=0;

	//����ҳ��
	pPlazaViewPage = GetPlazaViewPage(m_pCurrViewControl->wPageCurrent);
	if(pPlazaViewPage!=NULL) 
	{
		if(bResetPageIndex) pPlazaViewPage->ExpandSubItem(0.3f);
		pPlazaViewPage->CControlUI::SetInternVisible(true);
	}	

	//��������
	RectifyControl();	

	return;
}

//��ʾ�ֻ���Ϸ
VOID CPlazaViewGame::ShowMobileAppItemView(BOOL bResetPageIndex)
{
	int wTypeID = 5;
	//��ȡ����
	ASSERT(CServerListData::GetInstance()!=NULL);
	CServerListData * pServerListData=CServerListData::GetInstance();

	//����Ŀ¼
	TCHAR szDirectory[MAX_PATH]=TEXT("");
	CWHService::GetWorkDirectory(szDirectory,CountArray(szDirectory));

	//��������
	POSITION Position=NULL;
	CGameKindItem * pGameKindItem=NULL;
	tagGameAppInfo * pGameAppInfo=NULL;


	//ɾ������
	//m_GameAppInfoBuffer.Append(m_GameAppInfoActive);
	m_GameAppInfoActive.RemoveAll();

	//�������
	try
	{
		//�������������ֻ���Ϸ��Ŀ
		pGameAppInfo=new tagGameAppInfo;
		if (pGameAppInfo!=NULL)
		{
			pGameAppInfo->wSortID =0;
			pGameAppInfo->wUIID =0;

			m_GameAppInfoActive.Add(pGameAppInfo);
		}

		pGameAppInfo=new tagGameAppInfo;
		if (pGameAppInfo!=NULL)
		{
			pGameAppInfo->wSortID =1;
			pGameAppInfo->wUIID =1;

			m_GameAppInfoActive.Add(pGameAppInfo);
		}

		pGameAppInfo=new tagGameAppInfo;
		if (pGameAppInfo!=NULL)
		{
			pGameAppInfo->wSortID =2;
			pGameAppInfo->wUIID =2;

			m_GameAppInfoActive.Add(pGameAppInfo);
		}

		pGameAppInfo=new tagGameAppInfo;
		if (pGameAppInfo!=NULL)
		{
			pGameAppInfo->wSortID =3;
			pGameAppInfo->wUIID =3;

			m_GameAppInfoActive.Add(pGameAppInfo);
		}
	}
	catch (...)
	{
		
		
	}



	//�رն�ʱ��
	KillTimer(IDI_SWITCH_VIEW_PAGE);

	//��������
	CContainerUI * pSuperParent=NULL;
	CContainerUI * pPageContainer=m_AppViewControl.pPageContainer;	

	//���ø�����
	pSuperParent = (CContainerUI *)GetControlByName(szContainerPageLayerControlName);	
	if(pSuperParent!=NULL)
	{
		if(pSuperParent->GetItemAt(0)!=NULL) pSuperParent->RemoveAt(0,false);
		pSuperParent->AddAt(pPageContainer,0);		
	}

	//��������
	pPageContainer->SetInternVisible(false);	
	pPageContainer->CControlUI::SetInternVisible(true);

	//������Ŀ
	WORD wItemCount = m_AppLayoutAttribute.wItemXCount*m_AppLayoutAttribute.wItemYCount;	
	m_AppViewControl.wPageCount = (WORD)ceil(m_GameAppInfoActive.GetCount()/(double)wItemCount);

	//��������
	CGameViewPage * pPlazaViewPage=NULL;

	//����ҳ��
	for(WORD wIndex=0;wIndex<m_AppViewControl.wPageCount;wIndex++)
	{
		//����ҳ��
		pPlazaViewPage = GetPlazaViewPage(pPageContainer,wIndex);
		if(pPlazaViewPage!=NULL)
		{
			pPlazaViewPage->SetFloat(true);
			pPlazaViewPage->SetManager(&m_PaintManager,pPageContainer);			
			pPlazaViewPage->ActivePage(wIndex,PAGE_TYPE_APP,this,&m_AppLayoutAttribute);			
		}
	}

    //��������(��ʾ�ֻ���Ϸ
	for(INT_PTR nIndex=0;nIndex<m_GameAppInfoActive.GetCount();nIndex++)
	{
		pPlazaViewPage = static_cast<CGameViewPage *>(pPageContainer->GetItemAt(WORD(nIndex/wItemCount)));
		if(pPlazaViewPage!=NULL)
		{
			pPlazaViewPage->AddPageSubItem(WORD(nIndex%wItemCount),m_AppLayoutAttribute.SizeItem.cx,m_AppLayoutAttribute.SizeItem.cy,m_GameAppInfoActive[nIndex]);
		}
	}

	//���ñ���
	m_nViewPageXOffset=0;
	m_wKindTypeCurrentID=wTypeID;
	m_cbShowItemMode=VIEW_MODE_APP;
	m_wSwitchPageCurrent=INVALID_WORD;
	m_pCurrViewControl=&m_AppViewControl;

	//��������
	if(bResetPageIndex==TRUE) m_pCurrViewControl->wPageCurrent=0;

	//����ҳ��
	pPlazaViewPage = GetPlazaViewPage(m_pCurrViewControl->wPageCurrent);
	if(pPlazaViewPage!=NULL) 
	{
		if(bResetPageIndex) pPlazaViewPage->ExpandSubItem(0.3f);
		pPlazaViewPage->CControlUI::SetInternVisible(true);
	}	

	//��������
	RectifyControl();	

	return;
}


//��ʾ����
VOID CPlazaViewGame::ShowMatchItemView(BOOL bResetPageIndex)
{
	//��ȡ����
	ASSERT(CServerListData::GetInstance()!=NULL);
	CServerListData * pServerListData=CServerListData::GetInstance();

	//��������
	POSITION Position=NULL;
	CGameServerItem * pGameServerItem=NULL;
	tagGameMatchInfo * pGameMatchInfo=NULL;

	//ɾ������
	for (INT i=0;i<m_GameMatchInfoActive.GetCount();i++)
	{
		//��ȡ����
		ASSERT(m_GameMatchInfoActive[i]!=NULL);
		pGameMatchInfo=m_GameMatchInfoActive[i];

		//���ñ���
		pGameMatchInfo->wSortID=0;
		pGameMatchInfo->pGameServerItem=NULL;
	}

	//ɾ������
	m_GameMatchInfoBuffer.Append(m_GameMatchInfoActive);
	m_GameMatchInfoActive.RemoveAll();

	//�������
	while (true)
	{
		//��ȡ����
		pGameServerItem=pServerListData->EmunGameServerItem(Position);

		//�����ж�
		if (pGameServerItem==NULL) break;

		//�����ж�
		if (pGameServerItem->IsMatchRoom()==false)
		{
			if (Position==NULL) break;
			if (Position!=NULL) continue;
		}

		//��ȡ����
		if (m_GameMatchInfoBuffer.GetCount()>0L)
		{
			//��ȡ����
			INT_PTR nCount=m_GameMatchInfoBuffer.GetCount();
			pGameMatchInfo=m_GameMatchInfoBuffer[nCount-1L];

			//ɾ������
			ASSERT(pGameMatchInfo!=NULL);
			m_GameMatchInfoBuffer.RemoveAt(nCount-1L);
		}
		else
		{
			try
			{
				pGameMatchInfo=new tagGameMatchInfo;
				if (pGameMatchInfo==NULL) throw TEXT("��������ʧ��");
			}
			catch (...)
			{
				ASSERT(FALSE);
				break;
			}
		}

		//���ö���
		pGameMatchInfo->pGameServerItem=pGameServerItem;
		pGameMatchInfo->wSortID=pGameServerItem->m_GameServer.wSortID;

		//�������
		for (INT nItem=0;nItem<m_GameMatchInfoActive.GetCount();nItem++)
		{
			//��ȡ����
			ASSERT(m_GameMatchInfoActive[nItem]!=NULL);
			tagGameMatchInfo * pGameMatchTemp=m_GameMatchInfoActive[nItem];

			//�����ж�
			if (pGameMatchInfo->wSortID<pGameMatchTemp->wSortID)
			{
				m_GameMatchInfoActive.InsertAt(nItem,pGameMatchInfo);
				break;
			}
		}

		//Ĭ�ϲ���
		if (nItem==m_GameMatchInfoActive.GetCount())
		{
			m_GameMatchInfoActive.Add(pGameMatchInfo);
		}

		//�����ж�
		if (Position==NULL)
		{
			break;
		}
	}

	//�رն�ʱ��
	KillTimer(IDI_SWITCH_VIEW_PAGE);

	//��������
	CContainerUI * pSuperParent=NULL;
	CContainerUI * pPageContainer=m_MatchViewControl.pPageContainer;	

	//���ø�����
	pSuperParent = (CContainerUI *)GetControlByName(szContainerPageLayerControlName);	
	if(pSuperParent!=NULL)
	{
		if(pSuperParent->GetItemAt(0)!=NULL) pSuperParent->RemoveAt(0,false);
		pSuperParent->AddAt(pPageContainer,0);		
	}

	//��������
	pPageContainer->SetInternVisible(false);	
	pPageContainer->CControlUI::SetInternVisible(true);

	//������Ŀ	
	WORD wItemCount = m_MatchLayoutAttribute.wItemXCount*m_MatchLayoutAttribute.wItemYCount;	
	m_MatchViewControl.wPageCount = (WORD)ceil(m_GameMatchInfoActive.GetCount()/(double)wItemCount);

	//��������
	CGameViewPage * pPlazaViewPage=NULL;

	//����ҳ��
	for(WORD wIndex=0;wIndex<m_MatchViewControl.wPageCount;wIndex++)
	{
		//����ҳ��
		pPlazaViewPage = GetPlazaViewPage(pPageContainer,wIndex);
		if(pPlazaViewPage!=NULL)
		{
			pPlazaViewPage->SetFloat(true);
			pPlazaViewPage->SetManager(&m_PaintManager,pPageContainer);	
			pPlazaViewPage->ActivePage(wIndex,PAGE_TYPE_MATCH,this,&m_MatchLayoutAttribute);					
		}
	}

    //���ӱ�������
	for(INT_PTR nIndex=0;nIndex<m_GameMatchInfoActive.GetCount();nIndex++)
	{
		pPlazaViewPage = static_cast<CGameViewPage *>(pPageContainer->GetItemAt(WORD(nIndex/wItemCount)));
		if(pPlazaViewPage!=NULL)
		{
			pPlazaViewPage->AddPageSubItem(WORD(nIndex%wItemCount),m_MatchLayoutAttribute.SizeItem.cx,m_MatchLayoutAttribute.SizeItem.cy,m_GameMatchInfoActive[nIndex]);
		}
	}

	//���ñ���
	m_nViewPageXOffset=0;
	m_cbShowItemMode=VIEW_MODE_MATCH;	
	m_wSwitchPageCurrent=INVALID_WORD;
	m_pCurrViewControl=&m_MatchViewControl;

	//��������
	if(bResetPageIndex==TRUE) m_pCurrViewControl->wPageCurrent=0;

	//����ҳ��
	pPlazaViewPage = GetPlazaViewPage(m_pCurrViewControl->wPageCurrent);
	if(pPlazaViewPage!=NULL) pPlazaViewPage->CControlUI::SetInternVisible(true);		

	//��������
	RectifyControl();	

	return;
}

//��ʾ����
VOID CPlazaViewGame::ShowServerItemView(WORD wKindID,BOOL bResetPageIndex,BOOL showone)
{
	
	//��ȡ����
	ASSERT(CServerListData::GetInstance()!=NULL);
	CServerListData * pServerListData=CServerListData::GetInstance();

	//��������
	ASSERT(pServerListData->SearchGameKind(wKindID)!=NULL);
	CGameKindItem * pGameKindItem=pServerListData->SearchGameKind(wKindID);

	//��������
	POSITION Position=NULL;
	CGameServerItem * pGameServerItem=NULL;
	tagGameServerInfo * pGameServerInfo=NULL;


		//��ȡĿ¼
	TCHAR szPath[MAX_PATH]=TEXT("");
	CWHService::GetWorkDirectory(szPath, sizeof(szPath));

	//��ȡ����
	TCHAR szFileName[MAX_PATH]=TEXT("");
	_sntprintf(szFileName,CountArray(szFileName),TEXT("%s\\commend.ini"),szPath);
 int commend1,commend2,commend3,commend4,commend5;


	if (!showone)
	{

	//ɾ������
	for (INT i=0;i<m_GameServerInfoActive.GetCount();i++)
	{
		//��ȡ����
		ASSERT(m_GameServerInfoActive[i]!=NULL);
		pGameServerInfo=m_GameServerInfoActive[i];

		//���ñ���
		pGameServerInfo->wSortID=0;
		pGameServerInfo->wServerID=0;
		pGameServerInfo->pGameServerItem=NULL;
	}

	//ɾ������
	m_GameServerInfoBuffer.Append(m_GameServerInfoActive);
	m_GameServerInfoActive.RemoveAll();

	}//���ǵ�һ����ʾ
	else
	{


	//��ȡҪ��ʾ����ҳ�ķ����б�
	  commend1 = GetPrivateProfileInt(TEXT("commend"),TEXT("commend1"),0,szFileName);
	 commend2 = GetPrivateProfileInt(TEXT("commend"),TEXT("commend2"),0,szFileName);
	  commend3 = GetPrivateProfileInt(TEXT("commend"),TEXT("commend3"),0,szFileName);
	  commend4 = GetPrivateProfileInt(TEXT("commend"),TEXT("commend4"),0,szFileName);
	 commend5 = GetPrivateProfileInt(TEXT("commend"),TEXT("commend5"),0,szFileName);
	}//�ǵ�һ����ʾ



	//�������
	while (true)
	{
		//��ȡ����
		pGameServerItem=pServerListData->EmunGameServerItem(Position);

		//�����ж�
		if (pGameServerItem==NULL) break;

		//�����ж�
		if (pGameServerItem->m_GameServer.wKindID!=wKindID && (!showone))//ethj�����������жϷ����Ƿ�Ҫȫ��ʾ
		{
			if (Position==NULL) break;
			if (Position!=NULL) continue;
		}

		//��ȡ����
		if (m_GameServerInfoBuffer.GetCount()>0L)
		{
			//��ȡ����
			INT_PTR nCount=m_GameServerInfoBuffer.GetCount();
			pGameServerInfo=m_GameServerInfoBuffer[nCount-1L];

			//ɾ������
			ASSERT(pGameServerInfo!=NULL);
			m_GameServerInfoBuffer.RemoveAt(nCount-1L);
		}
		else
		{
			try
			{
				pGameServerInfo=new tagGameServerInfo;
				if (pGameServerInfo==NULL) throw TEXT("��������ʧ��");
			}
			catch (...)
			{
				ASSERT(FALSE);
				break;
			}
		}

		//���ö���
		pGameServerInfo->pGameServerItem=pGameServerItem;
		pGameServerInfo->wSortID=pGameServerItem->m_GameServer.wSortID;
		pGameServerInfo->wServerID=pGameServerItem->m_GameServer.wServerID;



 if (showone && pGameServerInfo->wServerID!=0&&pGameServerInfo->wServerID!=commend1&& pGameServerInfo->wServerID!=commend2 && pGameServerInfo->wServerID!=commend3 && pGameServerInfo->wServerID!=commend4 && pGameServerInfo->wServerID!=commend5)
 {

//�����ж�
		if (Position==NULL)
		{
			break;
		}
continue;
 }

		//ethj ���Ӱ�ini�ļ����ж���������Ƿ�Ҫ��ʾ

		//�������
		for (INT nItem=0;nItem<m_GameServerInfoActive.GetCount();nItem++)
		{
			//��ȡ����
			ASSERT(m_GameServerInfoActive[nItem]!=NULL);
			tagGameServerInfo * pGameServerTemp=m_GameServerInfoActive[nItem];

			//�����ж�
			if (pGameServerInfo->wSortID<pGameServerTemp->wSortID)
			{
				m_GameServerInfoActive.InsertAt(nItem,pGameServerInfo);
				break;
			}
		}

		//Ĭ�ϲ���
		if (nItem==m_GameServerInfoActive.GetCount())
		{
			m_GameServerInfoActive.Add(pGameServerInfo);
		}

		//�����ж�
		if (Position==NULL)
		{
			break;
		}
	}

	//{{��������
	//
	//�رն�ʱ��
	KillTimer(IDI_SWITCH_VIEW_PAGE);

	//��������			
	CContainerUI * pSuperParent=NULL;
	CContainerUI * pPageContainer=m_ServerViewControl.pPageContainer;

	//��ȡ������
	pSuperParent = (CContainerUI *)GetControlByName(szContainerPageLayerControlName);	
	if(pSuperParent!=NULL)
	{
		if(pSuperParent->GetItemAt(0)!=NULL) pSuperParent->RemoveAt(0,false);
		pSuperParent->AddAt(pPageContainer,0);		
	}

	//��������
	pPageContainer->SetInternVisible(false);	
	pPageContainer->CControlUI::SetInternVisible(true);
	//
	//}}

	//��Ч�ж�
	if (m_GameServerInfoActive.GetCount()==0 )
	{
		if(!showone) //��ʾ��Ϣ
		{
		CInformation Information;
		Information.ShowMessageBox(TEXT("����Ϸ��ʱû�п��Խ������Ϸ���䣬��ѡ��������Ϸ��"),MB_ICONINFORMATION,30L);


		return;
		}
	}

	//������Ŀ
	WORD wItemCount = m_ServerLayoutAttribute.wItemXCount*m_ServerLayoutAttribute.wItemYCount;	
	m_ServerViewControl.wPageCount=(WORD)ceil(m_GameServerInfoActive.GetCount()/(double)wItemCount);

	//��������
	CGameViewPage * pPlazaViewPage=NULL;

	//����ҳ��
	for(WORD wIndex=0;wIndex<m_ServerViewControl.wPageCount;wIndex++)
	{
		//��ȡҳ��
		pPlazaViewPage = GetPlazaViewPage(pPageContainer,wIndex);
		if(pPlazaViewPage!=NULL)
		{
			//����ҳ��
			pPlazaViewPage->SetFloat(true);
			pPlazaViewPage->SetManager(&m_PaintManager,pPageContainer);	
			pPlazaViewPage->ActivePage(wIndex,PAGE_TYPE_SERVER,this,&m_ServerLayoutAttribute);					
		}
	}

    //��������(��ʾ����)
	for(INT_PTR nIndex=0;nIndex<m_GameServerInfoActive.GetCount();nIndex++)
	{
		pPlazaViewPage = static_cast<CGameViewPage *>(pPageContainer->GetItemAt(WORD(nIndex/wItemCount)));
		if(pPlazaViewPage!=NULL)
		{	
			CRect rctClient;
			this->GetClientRect(rctClient);

			pPlazaViewPage->AddPageSubItem(WORD(nIndex%wItemCount),rctClient.Width(),38,m_GameServerInfoActive[nIndex]);

			//��������
			if(m_wFocusServerID==m_GameServerInfoActive[nIndex]->wServerID)
			{
				bResetPageIndex=FALSE;
				m_ServerViewControl.wPageCurrent=pPlazaViewPage->GetPageIndex();
			}
		}
	}

	//���ñ���	
	m_nViewPageXOffset=0;
	m_wFocusServerID=INVALID_WORD;
	m_wSwitchPageCurrent=INVALID_WORD;
	m_cbShowItemMode=VIEW_MODE_SERVER;	
	m_pCurrViewControl=&m_ServerViewControl;

	//��������
	if(bResetPageIndex==TRUE) m_pCurrViewControl->wPageCurrent=0;

	//����ҳ��
	pPlazaViewPage = GetPlazaViewPage(m_pCurrViewControl->wPageCurrent);
	if(pPlazaViewPage!=NULL) pPlazaViewPage->CControlUI::SetInternVisible(true);		
	
	//��������
	RectifyControl();	

//#ifndef _DEBUG
#ifndef RELEASE_MANAGER
//ethj�����Ǹ��� 
	//��������
	TCHAR szGameDirectory[LEN_PROCESS]=TEXT("");
	lstrcpyn(szGameDirectory,pGameKindItem->m_GameKind.szProcessName,CountArray(szGameDirectory));
	GetGameResDirectory(szGameDirectory,CountArray(szGameDirectory));

	if(m_pUpdateStatusView == NULL)
	{
		m_pUpdateStatusView = new CUpdateStatusView();
		if(m_pUpdateStatusView==NULL) throw TEXT("�ڴ治��,���󴴽�ʧ��!");			
	}

	//���ÿؼ�
	m_pUpdateStatusView->SetFloat(false);
	pPageContainer->Add(m_pUpdateStatusView);

	//��ʼ����
	m_pUpdateStatusView->InitUpdateStatus(this,szGameDirectory);		

#endif
//#endif
}

//���·���
VOID CPlazaViewGame::UpdateServerViewItem()
{
	//ģʽ�ж�
	if(m_cbShowItemMode != VIEW_MODE_SERVER) return;

	//��������
	CGameViewServerItem * pGameViewServerItem=NULL;

	//��������ҳ
	for(WORD wPageIndex = 0; wPageIndex < m_pCurrViewControl->wPageCount; wPageIndex++)
	{
		//��ȡҳ��
		CGameViewPage * pPlazaViewPage = GetPlazaViewPage(wPageIndex);
		if(pPlazaViewPage == NULL) break;	

		//��������
		for(int i = 0; i < pPlazaViewPage->GetCount(); i++)
		{
			pGameViewServerItem = static_cast<CGameViewServerItem *>(pPlazaViewPage->GetItemAt(i));
			if(pGameViewServerItem != NULL)
			{
				pGameViewServerItem->UpdateResource();
			}
		}
	}
}

//��������
VOID CPlazaViewGame::UpdateKindViewItem(WORD wKindID)
{
	//ģʽ�ж�
	if(m_cbShowItemMode != VIEW_MODE_KIND) return;

	//��ȡҳ��
	CGameViewPage * pPlazaViewPage = GetPlazaViewPage(m_pCurrViewControl->wPageCurrent);
	if(pPlazaViewPage == NULL) return;

	//��������
	CGameViewKindItem * pGameViewKindItem=NULL;

	//��������
	for(int i = 0; i < pPlazaViewPage->GetCount(); i++)
	{
		pGameViewKindItem = static_cast<CGameViewKindItem *>(pPlazaViewPage->GetItemAt(i));
		if(pGameViewKindItem != NULL)
		{
			if(pGameViewKindItem->m_pGameKindInfo->pGameKindItem==NULL) continue;
			if(pGameViewKindItem->m_pGameKindInfo->pGameKindItem->m_GameKind.wKindID==wKindID)
			{
				pGameViewKindItem->UpdateResource();
				break;
			}
		}
	}
}

//�������
VOID CPlazaViewGame::InValidateWndView(BYTE cbViewType)
{
	//ģʽ�ж�
	if(m_cbShowItemMode==cbViewType) InvalidateRect(NULL);

	return;
}

//������Ϣ
INT CPlazaViewGame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (__super::OnCreate(lpCreateStruct) == -1)
		return -1;

	//���ñ���
	m_bCreateFlag=true;

	return 0;
}

//λ����Ϣ
VOID CPlazaViewGame::OnSize(UINT nType, INT cx, INT cy)
{
	__super::OnSize(nType, cx, cy);

	//�����ؼ�
	RectifyControl(cx,cy);

	return;
}

//�����ؼ�
VOID CPlazaViewGame::RectifyControl()
{
	//��ȡ����
	CRect rctClient;
	GetClientRect(&rctClient);
	RectifyControl(rctClient.Width(),rctClient.Height());
}

//�����ؼ�
VOID CPlazaViewGame::RectifyControl(INT nWidth, INT nHeight)
{
	//״̬�ж�
	if (m_bCreateFlag==false) return;	
	if ((nWidth==0)||(nHeight==0)) return;
	if (m_cbShowItemMode==VIEW_MODE_NONE) return;

	//���λ��
	tagEncircleInfo EncircleResInfo;
	m_EncircleRes.GetEncircleInfo(EncircleResInfo);

	//���ư�ť
	CControlUI * pControlUI = GetControlByName(szButtonKindLeftControlName);
	if(pControlUI!=NULL)
	{
		CRect rcPos(pControlUI->GetPos());
		pControlUI->SetVisible(m_pCurrViewControl->wPageCount>1);
		pControlUI->SetPos(rcPos.left,(nHeight-rcPos.Height())/2);
		pControlUI->SetEnabled((m_pCurrViewControl->wPageCurrent>0)?true:false);						
	}

	//���ư�ť
	pControlUI = GetControlByName(szButtonKindRightControlName);
	if(pControlUI!=NULL)
	{
		CRect rcPos(pControlUI->GetPos());
		pControlUI->SetVisible(m_pCurrViewControl->wPageCount>1);
		pControlUI->SetPos(nWidth-rcPos.Width(),(nHeight-rcPos.Height())/2);
		pControlUI->SetEnabled(m_pCurrViewControl->wPageCurrent<(m_pCurrViewControl->wPageCount-1)?true:false);					
	}	

	//��ǰҳ��
	CGameViewPage * pPlazaViewPage = GetPlazaViewPage(m_pCurrViewControl->wPageCurrent);
	if(pPlazaViewPage!=NULL)
	{
		pPlazaViewPage->SetFixedWidth(nWidth);
		pPlazaViewPage->SetFixedHeight(nHeight);		
		pPlazaViewPage->RectifySubItem();
		pPlazaViewPage->SetPos(CRect(m_nViewPageXOffset,EncircleResInfo.nTBorder,nWidth+m_nViewPageXOffset,nHeight));		
	}

	//����ҳ��
	if(m_wSwitchPageCurrent!=INVALID_WORD)
	{
		pPlazaViewPage = GetPlazaViewPage(m_wSwitchPageCurrent);
		if(pPlazaViewPage!=NULL)
		{
			pPlazaViewPage->SetFixedWidth(nWidth);
			pPlazaViewPage->SetFixedHeight(nHeight);
			pPlazaViewPage->RectifySubItem();	
			if(m_wSwitchPageCurrent<m_pCurrViewControl->wPageCurrent)
			{
				pPlazaViewPage->SetPos(CRect(m_nViewPageXOffset-nWidth,EncircleResInfo.nTBorder,0,nHeight));
			}
			else
			{
				pPlazaViewPage->SetPos(CRect(nWidth+m_nViewPageXOffset,EncircleResInfo.nTBorder,2*nWidth+m_nViewPageXOffset,nHeight));
			}
		}
	}


	if (m_cbShowItemMode==VIEW_MODE_APP)
	{

	}

	return;
}

//��ȡҳ��
CGameViewPage * CPlazaViewGame::GetPlazaViewPage(WORD wIndex)
{
	CContainerUI * pSuperParent = (CContainerUI *)GetControlByName(szContainerPageLayerControlName);	
	if(pSuperParent!=NULL)
	{
		CContainerUI * pPageContainerUI = static_cast<CContainerUI *>(pSuperParent->GetItemAt(0));
		if(pPageContainerUI!=NULL) 
		{
			return static_cast<CGameViewPage *>(pPageContainerUI->GetItemAt(wIndex));
		}
	}

	return NULL;
}

//��ȡҳ��
CGameViewPage * CPlazaViewGame::GetPlazaViewPage(CContainerUI * pPageContainer,WORD wIndex)
{
	//����У��
	ASSERT(pPageContainer!=NULL);
	if(pPageContainer==NULL) return NULL;

	//��ȡ����
	CGameViewPage * pPlazaViewPage = (CGameViewPage *)pPageContainer->GetItemAt(wIndex);
	if(pPlazaViewPage!=NULL) return pPlazaViewPage;

	//����ҳ��
	try
	{
		pPlazaViewPage = new CGameViewPage();
		if(pPlazaViewPage==NULL) throw TEXT("�ڴ治�㣬���󴴽�ʧ�ܣ�");

		//����ҳ��
		pPageContainer->AddAt(pPlazaViewPage,wIndex);
	}
	catch(...)
	{
		ASSERT(FALSE);
		pPlazaViewPage=NULL;	
	}

	return pPlazaViewPage;
}

//��ԴĿ¼
VOID CPlazaViewGame::GetGameResDirectory(TCHAR szResDirectory[], WORD wBufferCount)
{
	//��������
	WORD wStringIndex=0;

	//����Ŀ¼
	while ((szResDirectory[wStringIndex]!=0)&&(szResDirectory[wStringIndex]!=TEXT('.'))) wStringIndex++;

	//�ַ���ֹ
	szResDirectory[wStringIndex]=0;

	return;
}

//��ҳ���
VOID CPlazaViewGame::OnClickedLeftPageView()
{
	//״̬У��
	if(m_pCurrViewControl!=NULL)
	if(m_wSwitchPageCurrent!=INVALID_WORD) return;

	//��������
	if(m_pCurrViewControl->wPageCurrent==0) return;
	m_wSwitchPageCurrent = m_pCurrViewControl->wPageCurrent-1;
	
	//����ҳ��
	CGameViewPage * pPlazaViewPage = GetPlazaViewPage(m_wSwitchPageCurrent);
	if(pPlazaViewPage!=NULL) pPlazaViewPage->CControlUI::SetInternVisible(true);
    
	//���ñ���
	m_nViewPageXOffset=0;			

	//�����ؼ�
	RectifyControl();

	//���ö�ʱ��
	SetTimer(IDI_SWITCH_VIEW_PAGE,TIME_SWITCH_PAGE,NULL);	

	return;
}

//��ҳ���
VOID CPlazaViewGame::OnClickedRightPageView()
{
	//״̬У��
	if(m_pCurrViewControl==NULL) return;
	if(m_wSwitchPageCurrent!=INVALID_WORD) return;

	//��������
	if(m_pCurrViewControl->wPageCurrent>=m_pCurrViewControl->wPageCount-1) return;
	m_wSwitchPageCurrent = m_pCurrViewControl->wPageCurrent+1;

	//����ҳ��
	CGameViewPage * pPlazaViewPage = GetPlazaViewPage(m_wSwitchPageCurrent);
	if(pPlazaViewPage!=NULL) pPlazaViewPage->CControlUI::SetInternVisible(true);

	//���ñ���
	m_nViewPageXOffset=0;

	//�����ؼ�
	RectifyControl();

	//���ö�ʱ��
	SetTimer(IDI_SWITCH_VIEW_PAGE,TIME_SWITCH_PAGE,NULL);	
	
	return;
}

VOID CPlazaViewGame::OnTimer(UINT nIDEvent)
{
	__super::OnTimer(nIDEvent);

	//����ҳ��
	if(IDI_SWITCH_VIEW_PAGE==nIDEvent)
	{
		//��������
		bool bSwitchFinish=false;
		INT nLastPageXOffset = m_nViewPageXOffset;
		
		//����ҳ��
		CGameViewPage * pSwitchViewPage = GetPlazaViewPage(m_wSwitchPageCurrent);
		CGameViewPage * pCurrentViewPage = GetPlazaViewPage(m_pCurrViewControl->wPageCurrent);		

		//�����ж�
		if(pCurrentViewPage!=NULL)
		{
			if(m_wSwitchPageCurrent>m_pCurrViewControl->wPageCurrent)
			{
				m_nViewPageXOffset -= 50;
				if(m_nViewPageXOffset<-pCurrentViewPage->GetFixedWidth()) 
				{
					bSwitchFinish=true;		
					m_nViewPageXOffset=-pCurrentViewPage->GetFixedWidth();
				}
			}
			else
			{
				m_nViewPageXOffset += 50;
				if(m_nViewPageXOffset>pCurrentViewPage->GetFixedWidth()) 
				{
					bSwitchFinish=true;		
					m_nViewPageXOffset=pCurrentViewPage->GetFixedWidth();
				}
			}
		}

		//��ǰҳ��
		if(pCurrentViewPage!=NULL)
		{
			//����λ��
			CRect rcControlPos(pCurrentViewPage->GetPos());
			rcControlPos.left=m_nViewPageXOffset;
			rcControlPos.right=rcControlPos.left+pCurrentViewPage->GetFixedWidth();
			pCurrentViewPage->SetPos(rcControlPos);	
		}

		//����ҳ��
		if(pSwitchViewPage!=NULL)
		{
			CRect rcControlPos(pSwitchViewPage->GetPos());
			rcControlPos.left+=m_nViewPageXOffset-nLastPageXOffset;
			rcControlPos.right=rcControlPos.left+pSwitchViewPage->GetFixedWidth();
			pSwitchViewPage->SetPos(rcControlPos);
		}

		//��������
		if(bSwitchFinish==true)
		{			
			//��������
			m_pCurrViewControl->wPageCurrent=m_wSwitchPageCurrent;

			//���ñ���
			m_nViewPageXOffset=0;
			m_wSwitchPageCurrent=INVALID_WORD;

			//����ҳ��
			pCurrentViewPage->CControlUI::SetInternVisible(false);

			//�ر�ʱ��
			KillTimer(nIDEvent);

			//�����ؼ�
			RectifyControl();
		}
	}
}

//���ֹ���
BOOL CPlazaViewGame::OnMouseWheel(UINT nFlags, short zDelta, CPoint pt)
{
	//��ҳ����
	if(zDelta>0) OnClickedLeftPageView();
	if(zDelta<0) OnClickedRightPageView();

	return __super::OnMouseWheel(nFlags, zDelta, pt);
}


//////////////////////////////////////////////////////////////////////////////////