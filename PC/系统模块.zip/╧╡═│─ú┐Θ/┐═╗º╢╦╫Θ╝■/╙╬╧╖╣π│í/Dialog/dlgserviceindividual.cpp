#include "StdAfx.h"
#include "Resource.h"
#include "..\PlatformEvent.h"
#include "..\Plaza\PlatformFrame.h"
#include "..\Plaza\DlgCustomFace.h"
#include "DlgServiceIndividual.h"

//////////////////////////////////////////////////////////////////////////////////
//�༭�ؼ�
const TCHAR* const szEditGameIDControlName = TEXT("EditGameID");
const TCHAR* const szEditAccountsControlName = TEXT("EditAccounts");
const TCHAR* const szEditNickNameControlName = TEXT("EditNickName");
const TCHAR* const szEditUnderWriteControlName = TEXT("EditUnderWrite");
const TCHAR* const szEditCompellationControlName = TEXT("EditCompellation");
const TCHAR* const szEditSeatPhoneControlName = TEXT("EditSeatPhone");
const TCHAR* const szEditMobilePhoneControlName = TEXT("EditMobilePhone");
const TCHAR* const szEditQQControlName = TEXT("EditQQ");
const TCHAR* const szEditEMailControlName = TEXT("EditEMail");
const TCHAR* const szEditDwellingPlaceControlName = TEXT("EditDwellingPlace");
const TCHAR* const szEditUserNoteControlName = TEXT("EditUserNote");
const TCHAR* const szEditPasswordControlName = TEXT("EditPassword");

//��ť�ؼ�
const TCHAR* const szButtonOKControlName = TEXT("ButtonOK");
const TCHAR* const szButtonSelectFaceControlName = TEXT("ButtonSelectFace");

//��ѡ�ؼ�
const TCHAR* const szRadioMankindControlName = TEXT("RadioMankind");
const TCHAR* const szRadioFemaleControlName = TEXT("RadioFemale");

//////////////////////////////////////////////////////////////////////////////////

//��Ϣӳ��
BEGIN_MESSAGE_MAP(CDlgServiceIndividual, CDlgServiceItem)
	ON_WM_CREATE()
END_MESSAGE_MAP()

//////////////////////////////////////////////////////////////////////////////////

//���캯��
CDlgServiceIndividual::CDlgServiceIndividual()
{
	//�������
	m_bQueryMission=false;
	m_bModifyMission=false;

	//��������
	m_MissionManager.InsertMissionItem(this);

	//�ʺ�����
	m_cbGender=0;
	ZeroMemory(m_szNickName,sizeof(m_szNickName));
	ZeroMemory(m_szPassword,sizeof(m_szPassword));
	ZeroMemory(m_szUnderWrite,sizeof(m_szUnderWrite));

	//��ϸ����
	ZeroMemory(m_szQQ,sizeof(m_szQQ));
	ZeroMemory(m_szEMail,sizeof(m_szEMail));
	//ZeroMemory(m_szUserNote,sizeof(m_szUserNote));
	ZeroMemory(m_szSeatPhone,sizeof(m_szSeatPhone));
	ZeroMemory(m_szMobilePhone,sizeof(m_szMobilePhone));
	ZeroMemory(m_szCompellation,sizeof(m_szCompellation));
	ZeroMemory(m_szDwellingPlace,sizeof(m_szDwellingPlace));

	return;
}

//��������
CDlgServiceIndividual::~CDlgServiceIndividual()
{
}


//��Ϣ����
BOOL CDlgServiceIndividual::PreTranslateMessage(MSG * pMsg)
{
	//��������
	if (pMsg->message==WM_CHAR)
	{
		//��ʵ����
		CEditUI * pEditCompellationUI = (CEditUI *)GetControlByName(szEditCompellationControlName);
		if(pEditCompellationUI!=NULL && pEditCompellationUI->GetEditWindow()==pMsg->hwnd)
		{
			//��������
			CUserItemElement * pUserItemElement=CUserItemElement::GetInstance();
			TCHAR chr=static_cast<TCHAR>(pMsg->wParam);

			//�ַ��ж�
			if (pUserItemElement->EfficacyChineseCharacter(chr)==false)
			{
				return TRUE;
			}		
		}
	}

	return __super::PreTranslateMessage(pMsg);
}

//��ʼ�ؼ�
void CDlgServiceIndividual::InitControlUI()
{
	__super::InitControlUI();

	//����ʺ�
	CEditUI * pEditControlUI = NULL;

	//��ȡ����
	CContainerUI * pParent = static_cast<CContainerUI *>(m_PaintManager.GetRoot());
	if(pParent) pParent->SetBkColor(GetItemBackColor());

	//��������
	pEditControlUI = (CEditUI *)GetControlByName(szEditGameIDControlName);
	if(pEditControlUI) 
	{
		pEditControlUI->SetReadOnly(true);
		pEditControlUI->SetMaxChar(16);
		pEditControlUI->SetTextColor(RGB(125,125,125));
	}	

	

	
	//��������
	pEditControlUI = (CEditUI *)GetControlByName(szEditAccountsControlName);
	if(pEditControlUI) 
	{
		pEditControlUI->SetReadOnly(true);
		pEditControlUI->SetMaxChar(LEN_ACCOUNTS-1);
		pEditControlUI->SetTextColor(RGB(125,125,125));
	}

		//��������
	pEditControlUI = (CEditUI *)GetControlByName(szEditNickNameControlName);
	if(pEditControlUI) 
	{
		pEditControlUI->SetReadOnly(true);
		pEditControlUI->SetMaxChar(LEN_NICKNAME-1);
		pEditControlUI->SetTextColor(RGB(125,125,125));
	}


	//��������
	pEditControlUI = (CEditUI *)GetControlByName(szEditPasswordControlName);
	if(pEditControlUI) 
	{
		pEditControlUI->SetPasswordMode(true);
		pEditControlUI->SetMaxChar(LEN_PASSWORD-1);
	}


	//��������
	pEditControlUI = (CEditUI *)GetControlByName(szEditUnderWriteControlName);
	if(pEditControlUI) pEditControlUI->SetMaxChar(LEN_UNDER_WRITE-1);

	//��������
	pEditControlUI = (CEditUI *)GetControlByName(szEditQQControlName);
	if(pEditControlUI)
	{
		pEditControlUI->SetOnlyNumber();
		pEditControlUI->SetMaxChar(LEN_QQ-1);		
	}

	//��������
	pEditControlUI = (CEditUI *)GetControlByName(szEditEMailControlName);
	if(pEditControlUI) pEditControlUI->SetMaxChar(LEN_EMAIL-1);

	//��������
	pEditControlUI = (CEditUI *)GetControlByName(szEditSeatPhoneControlName);
	if(pEditControlUI)
	{
		pEditControlUI->SetOnlyNumber();
		pEditControlUI->SetMaxChar(LEN_SEAT_PHONE-1);
	}

	//��������
	pEditControlUI = (CEditUI *)GetControlByName(szEditMobilePhoneControlName);
	if(pEditControlUI) 
	{
		pEditControlUI->SetOnlyNumber();
		pEditControlUI->SetMaxChar(LEN_MOBILE_PHONE-1);
	}

	//��������
	pEditControlUI = (CEditUI *)GetControlByName(szEditCompellationControlName);
	if(pEditControlUI) pEditControlUI->SetMaxChar(LEN_COMPELLATION-1);

	//��������
	pEditControlUI = (CEditUI *)GetControlByName(szEditDwellingPlaceControlName);
	if(pEditControlUI) pEditControlUI->SetMaxChar(LEN_DWELLING_PLACE-1);

	//������Ϣ
	LoadAccountsInfo();
}

//�¼�֪ͨ
void CDlgServiceIndividual::Notify(TNotifyUI &  msg)
{
	__super::Notify(msg);

	//��ȡ����
	CControlUI * pControlUI = msg.pSender;

	//����¼�
	if (lstrcmp(msg.sType, TEXT("click")) == 0)
	{
		//ȷ����ť
		if(lstrcmp(pControlUI->GetName(),szButtonOKControlName)==0) 
		{
			return OnBnClickedConfirmChange(); 
		}
		else if(lstrcmp(pControlUI->GetName(),szButtonSelectFaceControlName)==0)
		{
			//return OnBnClickedSelectFace();
		}
	}
}

//�����¼�
bool CDlgServiceIndividual::OnEventMissionLink(INT nErrorCode)
{
	//���ӽ��
	if (nErrorCode!=0)
	{
		//��������
		if (m_MissionManager.AvtiveMissionItem(this,true)==true)
		{
			return true;
		}

		//�¼�����
		OnMissionConclude();

		//������ʾ
		if (m_bQueryMission==true)
		{
			//��ʾ��Ϣ
			CInformation Information(this);
			Information.ShowMessageBox(TEXT("���ӷ�������ʱ���û����ϻ�ȡʧ�ܣ�"),MB_OK|MB_ICONSTOP,30);
		}

		//������ʾ
		if (m_bModifyMission==true)
		{
			//��ʾ��Ϣ
			CInformation Information(this);
			Information.ShowMessageBox(TEXT("���ӷ�������ʱ���û������޸�ʧ�ܣ�"),MB_OK|MB_ICONSTOP,30);
		}

		return true;
	}

	//�޸�����
	if (m_bModifyMission==true)
	{
		//��������
		BYTE cbBuffer[SOCKET_TCP_BUFFER];
		ZeroMemory(cbBuffer,sizeof(cbBuffer));

		//��������
		CGlobalUserInfo * pGlobalUserInfo=CGlobalUserInfo::GetInstance();
		tagGlobalUserData * pGlobalUserData=pGlobalUserInfo->GetGlobalUserData();

		//��������
		CMD_GP_ModifyIndividual * pModifyIndividual=(CMD_GP_ModifyIndividual *)cbBuffer;
		CSendPacketHelper SendPacket(cbBuffer+sizeof(CMD_GP_ModifyIndividual),sizeof(cbBuffer)-sizeof(CMD_GP_ModifyIndividual));

		//���ñ���
		pModifyIndividual->cbGender=m_cbGender;
		pModifyIndividual->dwUserID=pGlobalUserData->dwUserID;
		lstrcpyn(pModifyIndividual->szPassword,m_szPassword,CountArray(pModifyIndividual->szPassword));

		//�û��ǳ�
		if (m_szNickName[0]!=0)
		{
			SendPacket.AddPacket(m_szNickName,DTP_GP_UI_NICKNAME);
		}

		//����ǩ��
		if (m_szUnderWrite[0]!=0)
		{
			SendPacket.AddPacket(m_szUnderWrite,DTP_GP_UI_UNDER_WRITE);
		}

		//�û���ע
		/*if (m_szUserNote[0]!=0)
		{
			SendPacket.AddPacket(m_szUserNote,DTP_GP_UI_USER_NOTE);
		}*/

		//��ʵ����
		if (m_szCompellation[0]!=0) 
		{
			SendPacket.AddPacket(m_szCompellation,DTP_GP_UI_COMPELLATION);
		}

		//�̶�����
		if (m_szSeatPhone[0]!=0) 
		{
			SendPacket.AddPacket(m_szSeatPhone,DTP_GP_UI_SEAT_PHONE);
		}

		//�ֻ�����
		if (m_szMobilePhone[0]!=0)
		{
			SendPacket.AddPacket(m_szMobilePhone,DTP_GP_UI_MOBILE_PHONE);
		}

		//Q Q ����
		if (m_szQQ[0]!=0) 
		{
			SendPacket.AddPacket(m_szQQ,DTP_GP_UI_QQ);
		}

		//�����ʼ�
		if (m_szEMail[0]!=0) 
		{
			SendPacket.AddPacket(m_szEMail,DTP_GP_UI_EMAIL);
		}

		//��ϸ��ַ
		if (m_szDwellingPlace[0]!=0) 
		{
			SendPacket.AddPacket(m_szDwellingPlace,DTP_GP_UI_DWELLING_PLACE);
		}

		//��������
		WORD wSendSize=sizeof(CMD_GP_ModifyIndividual)+SendPacket.GetDataSize();
		m_MissionManager.SendData(MDM_GP_USER_SERVICE,SUB_GP_MODIFY_INDIVIDUAL,cbBuffer,wSendSize);
	}

	//��ѯ����
	if (m_bQueryMission==true)
	{
		//��������
		CMD_GP_QueryIndividual QueryIndividual;
		ZeroMemory(&QueryIndividual,sizeof(QueryIndividual));

		//��������
		CGlobalUserInfo * pGlobalUserInfo=CGlobalUserInfo::GetInstance();
		tagGlobalUserData * pGlobalUserData=pGlobalUserInfo->GetGlobalUserData();

		//���ñ���
		QueryIndividual.dwUserID=pGlobalUserData->dwUserID;
		lstrcpyn(QueryIndividual.szPassword,pGlobalUserData->szPassword,CountArray(QueryIndividual.szPassword));

		//��������
		m_MissionManager.SendData(MDM_GP_USER_SERVICE,SUB_GP_QUERY_INDIVIDUAL,&QueryIndividual,sizeof(QueryIndividual));
	}

	return true;
}

//�ر��¼�
bool CDlgServiceIndividual::OnEventMissionShut(BYTE cbShutReason)
{
	//��ʾ��Ϣ
	if (cbShutReason!=SHUT_REASON_NORMAL)
	{
		//��������
		if (m_MissionManager.AvtiveMissionItem(this,true)==true)
		{
			return true;
		}

		//��ѯ����
		if (m_bQueryMission==true)
		{
			//��ʾ��Ϣ
			CInformation Information(this);
			Information.ShowMessageBox(TEXT("��������������쳣�Ͽ��ˣ��û����ϻ�ȡʧ�ܣ�"),MB_ICONERROR,30);
		}

		//�޸�����
		if (m_bModifyMission==true)
		{
			//��ʾ��Ϣ
			CInformation Information(this);
			Information.ShowMessageBox(TEXT("��������������쳣�Ͽ��ˣ��û������޸�ʧ�ܣ�"),MB_ICONERROR,30);
		}
	}

	//�¼�����
	OnMissionConclude();

	return true;
}

//��ȡ�¼�
bool CDlgServiceIndividual::OnEventMissionRead(TCP_Command Command, VOID * pData, WORD wDataSize)
{
	//�����
	if (Command.wMainCmdID==MDM_GP_USER_SERVICE)
	{
		switch (Command.wSubCmdID)
		{
		case SUB_GP_OPERATE_FAILURE:		//����ʧ��
			{
				//Ч�����
				CMD_GP_OperateFailure * pOperateFailure=(CMD_GP_OperateFailure *)pData;
				ASSERT(wDataSize>=(sizeof(CMD_GP_OperateFailure)-sizeof(pOperateFailure->szDescribeString)));
				if (wDataSize<(sizeof(CMD_GP_OperateFailure)-sizeof(pOperateFailure->szDescribeString))) return false;

				//ʧ�ܴ���
				OnMissionConclude();

				//�ر�����
				m_MissionManager.ConcludeMissionItem(this,false);

				//��ʾ��Ϣ
				if (pOperateFailure->szDescribeString[0]!=0)
				{
					CInformation Information(this);
					Information.ShowMessageBox(pOperateFailure->szDescribeString,MB_ICONERROR,60);
				}

				return true;
			}
		case SUB_GP_OPERATE_SUCCESS:	//�����ɹ�
			{
				//��������
				CMD_GP_OperateSuccess * pOperateSuccess=(CMD_GP_OperateSuccess *)pData;

				//Ч������
				ASSERT(wDataSize>=(sizeof(CMD_GP_OperateSuccess)-sizeof(pOperateSuccess->szDescribeString)));
				if (wDataSize<(sizeof(CMD_GP_OperateSuccess)-sizeof(pOperateSuccess->szDescribeString))) return false;

				//�ر�����
				m_MissionManager.ConcludeMissionItem(this,false);

				//��������
				CGlobalUserInfo * pGlobalUserInfo=CGlobalUserInfo::GetInstance();
				tagGlobalUserData * pGlobalUserData=pGlobalUserInfo->GetGlobalUserData();
				tagIndividualUserData * pIndividualUserData=pGlobalUserInfo->GetIndividualUserData();

				//�ʺ�����
				pGlobalUserData->cbGender=m_cbGender;
				lstrcpyn(pGlobalUserData->szNickName,m_szNickName,CountArray(pGlobalUserData->szNickName));
				lstrcpyn(pGlobalUserData->szUnderWrite,m_szUnderWrite,CountArray(pGlobalUserData->szUnderWrite));

				//��ϸ����
				lstrcpyn(pIndividualUserData->szQQ,m_szQQ,CountArray(pIndividualUserData->szQQ));
				lstrcpyn(pIndividualUserData->szEMail,m_szEMail,CountArray(pIndividualUserData->szEMail));
				//lstrcpyn(pIndividualUserData->szUserNote,m_szUserNote,CountArray(pIndividualUserData->szUserNote));
				lstrcpyn(pIndividualUserData->szSeatPhone,m_szSeatPhone,CountArray(pIndividualUserData->szSeatPhone));
				lstrcpyn(pIndividualUserData->szMobilePhone,m_szMobilePhone,CountArray(pIndividualUserData->szMobilePhone));
				lstrcpyn(pIndividualUserData->szCompellation,m_szCompellation,CountArray(pIndividualUserData->szCompellation));
				lstrcpyn(pIndividualUserData->szDwellingPlace,m_szDwellingPlace,CountArray(pIndividualUserData->szDwellingPlace));

				//�����¼�
				CPlatformEvent * pPlatformEvent=CPlatformEvent::GetInstance();
				if (pPlatformEvent!=NULL) pPlatformEvent->SendPlatformEvent(EVENT_USER_INFO_UPDATE,0L);

				//��ʾ��Ϣ
				if (pOperateSuccess->szDescribeString[0]!=0)
				{
					CInformation Information(this);
					Information.ShowMessageBox(pOperateSuccess->szDescribeString,MB_ICONINFORMATION,60);
				}

				//�ɹ�����
				OnMissionConclude();

				return true;
			}
		case SUB_GP_USER_INDIVIDUAL:	//������Ϣ
			{
				//Ч�����
				ASSERT(wDataSize>=sizeof(CMD_GP_UserIndividual));
				if (wDataSize<sizeof(CMD_GP_UserIndividual)) return false;

				//��������
				CMD_GP_UserIndividual * pUserIndividual=(CMD_GP_UserIndividual *)pData;

				//��������
				CGlobalUserInfo * pGlobalUserInfo=CGlobalUserInfo::GetInstance();
				tagIndividualUserData * pIndividualUserData=pGlobalUserInfo->GetIndividualUserData();

				//���ñ���
				pIndividualUserData->dwUserID=pUserIndividual->dwUserID;
				
				//��������
				VOID * pDataBuffer=NULL;
				tagDataDescribe DataDescribe;
				CRecvPacketHelper RecvPacket(pUserIndividual+1,wDataSize-sizeof(CMD_GP_UserIndividual));

				//��չ��Ϣ
				while (true)
				{
					pDataBuffer=RecvPacket.GetData(DataDescribe);
					if (DataDescribe.wDataDescribe==DTP_NULL) break;
					switch (DataDescribe.wDataDescribe)
					{
					case DTP_GP_UI_USER_NOTE:		//�û���ע
						{
							lstrcpyn(pIndividualUserData->szUserNote,(LPCTSTR)pDataBuffer,CountArray(pIndividualUserData->szUserNote));
							break;
						}
					case DTP_GP_UI_COMPELLATION:	//��ʵ����
						{
							lstrcpyn(pIndividualUserData->szCompellation,(LPCTSTR)pDataBuffer,CountArray(pIndividualUserData->szCompellation));
							break;
						}
					case DTP_GP_UI_SEAT_PHONE:		//�̶��绰
						{
							lstrcpyn(pIndividualUserData->szSeatPhone,(LPCTSTR)pDataBuffer,CountArray(pIndividualUserData->szSeatPhone));
							break;
						}
					case DTP_GP_UI_MOBILE_PHONE:	//�ƶ��绰
						{
							lstrcpyn(pIndividualUserData->szMobilePhone,(LPCTSTR)pDataBuffer,CountArray(pIndividualUserData->szMobilePhone));
							break;
						}
					case DTP_GP_UI_QQ:				//Q Q ����
						{
							lstrcpyn(pIndividualUserData->szQQ,(LPCTSTR)pDataBuffer,CountArray(pIndividualUserData->szQQ));
							break;
						}
					case DTP_GP_UI_EMAIL:			//�����ʼ�
						{
							lstrcpyn(pIndividualUserData->szEMail,(LPCTSTR)pDataBuffer,CountArray(pIndividualUserData->szEMail));
							break;
						}
					case DTP_GP_UI_DWELLING_PLACE:	//��ϵ��ַ
						{
							lstrcpyn(pIndividualUserData->szDwellingPlace,(LPCTSTR)pDataBuffer,CountArray(pIndividualUserData->szDwellingPlace));
							break;
						}
					}
				}

				//�ɹ�����
				OnMissionConclude();

				//��������
				UpdateIndividualInfo();

				//�ر�����
				m_MissionManager.ConcludeMissionItem(this,false);

				return true;
			}
		}
	}

	return true;
}

//��ʼ����
VOID CDlgServiceIndividual::OnMissionStart()
{
	//��ȡ����
	CContainerUI * pParent = static_cast<CContainerUI *>(m_PaintManager.GetRoot());
	if(pParent!=NULL) pParent->SetEnabled(false);

	return;
}

//��ֹ����
VOID CDlgServiceIndividual::OnMissionConclude()
{
	//��ȡ����
	CContainerUI * pParent = static_cast<CContainerUI *>(m_PaintManager.GetRoot());
	if(pParent!=NULL) pParent->SetEnabled(true);

	//���ÿؼ�
	SetControlItemText(szEditPasswordControlName,TEXT(""));

	return;
}

//�ʺ���Ϣ
VOID CDlgServiceIndividual::LoadAccountsInfo()
{
	//��������
	CGlobalUserInfo * pGlobalUserInfo=CGlobalUserInfo::GetInstance();
	tagGlobalUserData * pGlobalUserData=pGlobalUserInfo->GetGlobalUserData();
	tagIndividualUserData * pIndividualUserData=pGlobalUserInfo->GetIndividualUserData();

	/*//�û�ͷ��
	if ((pGlobalUserData->dwCustomID!=0L)&&(pGlobalUserData->CustomFaceInfo.dwDataSize!=0))
	{
		tagCustomFaceInfo * pCustomFaceInfo=&pGlobalUserData->CustomFaceInfo;
		m_FaceItemView.SetCustomFace(pGlobalUserData->dwCustomID,pCustomFaceInfo->dwCustomFace);
	}
	else
	{
		m_FaceItemView.SetSystemFace(pGlobalUserData->wFaceID);
	}*/

	//���ÿؼ�
	CEditUI * pEditControl=NULL;

	//��������
	TCHAR szGameID[32]=TEXT("");
	_sntprintf(szGameID,CountArray(szGameID),TEXT("%d"),pGlobalUserData->dwGameID);
	SetControlItemText(szEditGameIDControlName,szGameID);

	//��������
	SetControlItemText(szEditAccountsControlName,pGlobalUserData->szAccounts);
	SetControlItemText(szEditNickNameControlName,pGlobalUserData->szNickName);
	SetControlItemText(szEditUnderWriteControlName,pGlobalUserData->szUnderWrite);

	//�û��Ա�
	if (pGlobalUserData->cbGender==GENDER_FEMALE)
	{
		CRadioButtonUI * pRadioButtonUI = (CRadioButtonUI *)GetControlByName(szRadioFemaleControlName);
		pRadioButtonUI->SetCheck(true);
	}
	if (pGlobalUserData->cbGender==GENDER_MANKIND)
	{
		CRadioButtonUI * pRadioButtonUI = (CRadioButtonUI *)GetControlByName(szRadioMankindControlName);
		pRadioButtonUI->SetCheck(true);
	}

	//��ϸ����
	if (pIndividualUserData->dwUserID==0L)
	{
		QueryIndividualInfo();
	}
	else
	{
		UpdateIndividualInfo();
	}

	return;
}

//��ѯ����
VOID CDlgServiceIndividual::QueryIndividualInfo()
{
	//���ñ���
	m_bQueryMission=true;
	m_bModifyMission=false;

	//�¼�����
	OnMissionStart();

	//��������
	if (m_MissionManager.AvtiveMissionItem(this,false)==false)  
	{
		OnMissionConclude();
		return;
	}

	return;
}

//��������
VOID CDlgServiceIndividual::UpdateIndividualInfo()
{
	//��ȡ����
	CUserItemElement * pUserItemElement = CUserItemElement::GetInstance();

	//��������
	CGlobalUserInfo * pGlobalUserInfo=CGlobalUserInfo::GetInstance();
	tagIndividualUserData * pIndividualUserData=pGlobalUserInfo->GetIndividualUserData();

	//�û�����
	SetControlItemText(szEditCompellationControlName,pIndividualUserData->szCompellation);

	//��������
	TCHAR szSeatPhone[LEN_SEAT_PHONE]=TEXT("");
	pUserItemElement->ProtectSeatPhone(pIndividualUserData->szSeatPhone,szSeatPhone,CountArray(szSeatPhone),'*');
	SetControlItemText(szEditSeatPhoneControlName,szSeatPhone);

	//�ƶ�����
	TCHAR szMobilePhone[LEN_MOBILE_PHONE]=TEXT("");
	pUserItemElement->ProtectMobilePhone(pIndividualUserData->szMobilePhone,szMobilePhone,CountArray(szMobilePhone),'*');
	SetControlItemText(szEditMobilePhoneControlName,szMobilePhone);

	//��ϵ����
	SetControlItemText(szEditQQControlName,pIndividualUserData->szQQ);
	SetControlItemText(szEditEMailControlName,pIndividualUserData->szEMail);
	SetControlItemText(szEditDwellingPlaceControlName,pIndividualUserData->szDwellingPlace);

	return;
}

//ͷ��ѡ��
VOID CDlgServiceIndividual::OnBnClickedSelectFace()
{

	return;

	//��������
	CDlgCustomFace DlgCustomFace;
	DlgCustomFace.SetCustomFaceEvent(QUERY_OBJECT_PTR_INTERFACE(CPlatformFrame::GetInstance(),IUnknownEx));

	//��ʾ����
	if (DlgCustomFace.DoModal()==IDCANCEL)
	{
		return;
	}

	//��������
	CGlobalUserInfo * pGlobalUserInfo=CGlobalUserInfo::GetInstance();
	tagGlobalUserData * pGlobalUserData=pGlobalUserInfo->GetGlobalUserData();
	tagIndividualUserData * pIndividualUserData=pGlobalUserInfo->GetIndividualUserData();

	//�û�ͷ��
	if ((pGlobalUserData->dwCustomID!=0L)&&(pGlobalUserData->CustomFaceInfo.dwDataSize!=0))
	{
		tagCustomFaceInfo * pCustomFaceInfo=&pGlobalUserData->CustomFaceInfo;
		m_FaceItemView.SetCustomFace(pGlobalUserData->dwCustomID,pCustomFaceInfo->dwCustomFace);
	}
	else
	{
		m_FaceItemView.SetSystemFace(pGlobalUserData->wFaceID);
	}

	return;
}

//ȷ���޸�
VOID CDlgServiceIndividual::OnBnClickedConfirmChange()
{
	//��ȡ����
	TCHAR szDescribe[128]=TEXT("");
	CUserItemElement * pUserItemElement=CUserItemElement::GetInstance();

	//��������
	CGlobalUserInfo * pGlobalUserInfo=CGlobalUserInfo::GetInstance();
	tagGlobalUserData * pGlobalUserData=pGlobalUserInfo->GetGlobalUserData();
	tagIndividualUserData * pIndividualUserData=pGlobalUserInfo->GetIndividualUserData();

	//��ȡ����
	TCHAR szPassword[LEN_PASSWORD]=TEXT("");
	GetControlItemText(szEditPasswordControlName,szPassword,CountArray(szPassword));

	//�ʺ���Ϣ
	GetControlItemText(szEditNickNameControlName,m_szNickName,CountArray(m_szNickName));
	GetControlItemText(szEditUnderWriteControlName,m_szUnderWrite,CountArray(m_szUnderWrite));

	//�û�����
	//GetControlItemText(szEditUserNoteControlName,m_szUserNote,CountArray(m_szUserNote));
	GetControlItemText(szEditCompellationControlName,m_szCompellation,CountArray(m_szCompellation));

	//��������
	TCHAR szSeatPhone[LEN_SEAT_PHONE]=TEXT("");	
	pUserItemElement->ProtectSeatPhone(pIndividualUserData->szSeatPhone,szSeatPhone,CountArray(szSeatPhone),'*');
	GetControlItemText(szEditSeatPhoneControlName,m_szSeatPhone,CountArray(m_szSeatPhone));
	if(lstrcmp(m_szSeatPhone,szSeatPhone)==0) 
	{
		lstrcpyn(m_szSeatPhone,pIndividualUserData->szSeatPhone,CountArray(m_szSeatPhone));
	}

	//�ֻ�����
	TCHAR szMobilePhone[LEN_MOBILE_PHONE]=TEXT("");	
	pUserItemElement->ProtectMobilePhone(pIndividualUserData->szMobilePhone,szMobilePhone,CountArray(szMobilePhone),'*');
	GetControlItemText(szEditMobilePhoneControlName,m_szMobilePhone,CountArray(m_szMobilePhone));
	if(lstrcmp(m_szMobilePhone,szMobilePhone)==0) 
	{
		lstrcpyn(m_szMobilePhone,pIndividualUserData->szMobilePhone,CountArray(m_szMobilePhone));
	}

	//��ϵ����
	GetControlItemText(szEditQQControlName,m_szQQ,CountArray(m_szQQ));
	GetControlItemText(szEditEMailControlName,m_szEMail,CountArray(m_szEMail));
	GetControlItemText(szEditDwellingPlaceControlName,m_szDwellingPlace,CountArray(m_szDwellingPlace));

	//ѡ��Ů��
	CRadioButtonUI * pRadioButtonUI = (CRadioButtonUI *)GetControlByName(szRadioFemaleControlName);
	if(pRadioButtonUI->GetCheck()) m_cbGender=GENDER_FEMALE;

	//ѡ������
	pRadioButtonUI = (CRadioButtonUI *)GetControlByName(szRadioMankindControlName);
	if(pRadioButtonUI->GetCheck()) m_cbGender=GENDER_MANKIND;

	//�ǳ��ж�
	if (lstrcmp(m_szNickName,pGlobalUserData->szNickName)!=0)
	{
		//��������
		TCHAR szDescribe[128]=TEXT("");		

		//�ǳ��ж�
		if (pUserItemElement->EfficacyNickName(m_szNickName,szDescribe,CountArray(szDescribe))==false)
		{
			//��ʾ��Ϣ
			CInformation Information(this);
			Information.ShowMessageBox(szDescribe,MB_ICONERROR,0);

			//���ý���
			CEditUI * pEditControl = (CEditUI *)GetControlByName(szEditNickNameControlName);
			if(pEditControl!=NULL) pEditControl->SetFocus();

			return;
		}
	}

	//��������
	CWHEncrypt::MD5Encrypt(szPassword,m_szPassword);

	//�����ж�
	if (lstrcmp(m_szPassword,pGlobalUserData->szPassword)!=0)
	{
		//��ʾ��Ϣ
		CInformation Information(this);
		Information.ShowMessageBox(TEXT("�û��ʺ�����������������룡"),MB_ICONERROR,0);

		//���ý���
		CEditUI * pEditControl = (CEditUI *)GetControlByName(szEditPasswordControlName);
		if(pEditControl!=NULL) pEditControl->SetFocus();

		return;
	}

	//�ֻ���У��
	if (m_szMobilePhone[0]!=0 && pUserItemElement->EfficacyMobilePhone(m_szMobilePhone,szDescribe,CountArray(szDescribe))==false)
	{
		//��ʾ��Ϣ
		CInformation Information(this);
		Information.ShowMessageBox(szDescribe,MB_ICONERROR,0);

		//���ý���
		CEditUI * pEditControl = (CEditUI *)GetControlByName(szEditMobilePhoneControlName);
		if(pEditControl!=NULL) pEditControl->SetFocus();

		return;
	}

	//����У��
	if (m_szEMail[0]!=0 && pUserItemElement->EfficacyEmail(m_szEMail,szDescribe,CountArray(szDescribe))==false)
	{
		//��ʾ��Ϣ
		CInformation Information(this);
		Information.ShowMessageBox(szDescribe,MB_ICONERROR,0);

		//���ý���
		CEditUI * pEditControl = (CEditUI *)GetControlByName(szEditEMailControlName);
		if(pEditControl!=NULL) pEditControl->SetFocus();

		return;
	}	

	//���ñ���
	m_bQueryMission=false;
	m_bModifyMission=true;

	//�¼�����
	OnMissionStart();

	//��������
	if (m_MissionManager.AvtiveMissionItem(this,false)==false) 
	{
		OnMissionConclude();
		return;
	}

	return;
}

//������Ϣ
int CDlgServiceIndividual::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	__super::OnCreate(lpCreateStruct);

	//��������
	CRect rctCreate(0,0,0,0);
	m_FaceItemView.Create(NULL,WS_VISIBLE|WS_CHILD,rctCreate,this,30);

	//����λ��
	//m_FaceItemView.SetWindowPos(NULL,300,15,54,54,SWP_NOZORDER);

	return TRUE;
}

//////////////////////////////////////////////////////////////////////////////////
