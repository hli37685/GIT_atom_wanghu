#include "StdAfx.h"
#include "Resource.h"
#include "DlgServiceItem.h"

//////////////////////////////////////////////////////////////////////////////////

//���캯��
CDlgServiceItem::CDlgServiceItem()
{
	return;
}

//��������
CDlgServiceItem::~CDlgServiceItem()
{
}

//��ʼ�滭
void CDlgServiceItem::OnBeginPaintWindow(HDC hDC)
{
	//��ȡ�豸
	CDC * pDC = CDC::FromHandle(hDC);

	//��ȡλ��
	CRect rctClient;
	GetClientRect(&rctClient);

	//��䱳��
	pDC->FillSolidRect(&rctClient,CSkinDialog::m_SkinAttribute.m_crBackGround);
}

//�滭����
VOID CDlgServiceItem::DrawItemView(CDC * pDC, INT nWidth, INT nHeight)
{
	return;
}

//�����ַ�
VOID CDlgServiceItem::SetControlItemText(LPCTSTR pszControlName,LPCTSTR pszText)
{
	//����ʺ�
	CControlUI * pControlUI = GetControlByName(pszControlName);
	if(pControlUI) pControlUI->SetText(pszText);
}

//��ȡ�ַ�
VOID CDlgServiceItem::GetControlItemText(LPCTSTR pszControlName, TCHAR szString[], WORD wMaxCount)
{
	//����ʺ�
	CControlUI * pControlUI = GetControlByName(pszControlName);
	if(pControlUI==NULL) return;

	//��ȡ�ַ�
	CString strString(pControlUI->GetText());	

	//�����ַ�
	strString.TrimLeft();
	strString.TrimRight();

	//���ý��
	lstrcpyn(szString,strString,wMaxCount);

	return;
}

//////////////////////////////////////////////////////////////////////////////////
