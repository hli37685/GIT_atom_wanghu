#include "StdAfx.h"
#include "..\GlobalUnits.h"
#include "DlgServiceWealth.h"

//////////////////////////////////////////////////////////////////////////////////
//�ؼ�����

//��ǩ�ؼ�
const TCHAR* const szLabelGameScoreControlName = TEXT("LabelGameScore");
const TCHAR* const szLabelGameInsureControlName = TEXT("LabelGameInsure");
const TCHAR* const szLabelGameBeanControlName = TEXT("LabelGameBean");
const TCHAR* const szLabelGameIngotControlName = TEXT("LabelGameIngot");
const TCHAR* const szLabelLoveLinessControlName = TEXT("LabelLoveLiness");

//���ӿؼ�
const TCHAR* const szButtonGetScoreControlName = TEXT("ButtonGetScore");
const TCHAR* const szButtonOperateInsureControlName = TEXT("ButtonOperateInsure");
const TCHAR* const szButtonRechargeBeansControlName = TEXT("ButtonRechargeBeans");
const TCHAR* const szButtonExchangeIngotControlName = TEXT("ButtonExchangeIngot");
const TCHAR* const szButtonExchangeLoveLinessControlName = TEXT("ButtonExchangeLoveLiness");

//////////////////////////////////////////////////////////////////////////////////

//���캯��
CDlgServiceWealth::CDlgServiceWealth()
{
}

//��������
CDlgServiceWealth::~CDlgServiceWealth()
{
}

//��Ϣ����
BOOL CDlgServiceWealth::PreTranslateMessage(MSG * pMsg)
{
	return __super::PreTranslateMessage(pMsg);
}

//��ʼ�ؼ�
void CDlgServiceWealth::InitControlUI()
{
	__super::InitControlUI();

	//���²Ƹ�
	UpdateWealthInfo();
}

//��Ϣ����
void CDlgServiceWealth::Notify(TNotifyUI &  msg)
{
	__super::Notify(msg);

	//��ȡ����
	CControlUI * pControlUI = msg.pSender;

	//�����¼�
	if(lstrcmp(msg.sType,TEXT("click")) ==0 )
	{
		if(lstrcmp(pControlUI->GetName(),szButtonGetScoreControlName)==0)
		{
			ASSERT(CGlobalUnits::GetInstance());
			CGlobalUnits::GetInstance()->PerformShowExchange();

			return;
		}		
		else if(lstrcmp(pControlUI->GetName(),szButtonOperateInsureControlName)==0)
		{
			ASSERT(CGlobalUnits::GetInstance());
			CGlobalUnits::GetInstance()->PerformShowInsure();

			return;
		}
		else if(lstrcmp(pControlUI->GetName(),szButtonExchangeIngotControlName)==0)
		{
			ASSERT(CGlobalUnits::GetInstance());
			CGlobalUnits::GetInstance()->PerformShowTaskView();

			return;
		}
		else if(lstrcmp(pControlUI->GetName(),szButtonExchangeLoveLinessControlName)==0)
		{
			//��ȡ����
			ASSERT(CGlobalWebLink::GetInstance()!=NULL);
			CGlobalWebLink * pGlobalWebLink=CGlobalWebLink::GetInstance();

			//�����ַ
			TCHAR szLoveLiness[256]=TEXT("");
			_sntprintf(szLoveLiness,CountArray(szLoveLiness),TEXT("%s/Member/ConvertPresent.aspx"),pGlobalWebLink->GetPlatformLink());

			//��ҳ��
			ShellExecute(NULL,TEXT("OPEN"),szLoveLiness,NULL,NULL,SW_NORMAL);

			return;
		}
		else if(lstrcmp(pControlUI->GetName(),szButtonRechargeBeansControlName)==0)
		{
			//��ȡ����
			ASSERT(CGlobalWebLink::GetInstance()!=NULL);
			CGlobalWebLink * pGlobalWebLink=CGlobalWebLink::GetInstance();

			//�����ַ
			TCHAR szRechargeBean[256]=TEXT("");
			_sntprintf(szRechargeBean,CountArray(szRechargeBean),TEXT("%s/Pay/PayIndex.aspx"),pGlobalWebLink->GetPlatformLink());

			//��ҳ��
			ShellExecute(NULL,TEXT("OPEN"),szRechargeBean,NULL,NULL,SW_NORMAL);

			return;
		}			
	}

	return;
}

//�����滭
void CDlgServiceWealth::OnEndPaintWindow(HDC hDC)
{
	//��ȡ�豸
	CDC * pDC = CDC::FromHandle(hDC);
}

//���²Ƹ�
VOID CDlgServiceWealth::UpdateWealthInfo()
{
	//��������
	TCHAR szWealthValue[32]=TEXT("");

	//�ؼ�����
	CLabelUI * pLabelControl=NULL;

	//��ȡ����
	CGlobalUserInfo * pGlobalUserInfo=CGlobalUserInfo::GetInstance();
	tagGlobalUserData * pGlobalUserData=pGlobalUserInfo->GetGlobalUserData();

	//������Ϸ��
	pLabelControl = (CLabelUI *)GetControlByName(szLabelGameScoreControlName);
	if(pLabelControl) 
	{		
		SwitchScoreFormat(pGlobalUserData->lUserScore,3,TEXT("%I64d"),szWealthValue,CountArray(szWealthValue));
		pLabelControl->SetText(szWealthValue);
	}

	//������Ϸ��
	pLabelControl = (CLabelUI *)GetControlByName(szLabelGameInsureControlName);
	if(pLabelControl) 
	{		
		SwitchScoreFormat(pGlobalUserData->lUserInsure,3,TEXT("%I64d"),szWealthValue,CountArray(szWealthValue));
		pLabelControl->SetText(szWealthValue);
	}

	//��Ϸ��
	pLabelControl = (CLabelUI *)GetControlByName(szLabelGameBeanControlName);
	if(pLabelControl) 
	{			
		SwitchScoreFormat(pGlobalUserData->dUserBeans,3,TEXT("%0.2f"),szWealthValue,CountArray(szWealthValue));
		pLabelControl->SetText(szWealthValue);
	}

	//Ԫ��
	pLabelControl = (CLabelUI *)GetControlByName(szLabelGameIngotControlName);
	if(pLabelControl) 
	{		
		SwitchScoreFormat(pGlobalUserData->lUserIngot,3,TEXT("%I64d"),szWealthValue,CountArray(szWealthValue));
		pLabelControl->SetText(szWealthValue);
	}

	//����ֵ
	pLabelControl = (CLabelUI *)GetControlByName(szLabelLoveLinessControlName);
	if(pLabelControl) 
	{		
		SwitchScoreFormat((LONGLONG)pGlobalUserData->dwLoveLiness,3,TEXT("%ld"),szWealthValue,CountArray(szWealthValue));
		pLabelControl->SetText(szWealthValue);
	}
	
}

//////////////////////////////////////////////////////////////////////////////////
