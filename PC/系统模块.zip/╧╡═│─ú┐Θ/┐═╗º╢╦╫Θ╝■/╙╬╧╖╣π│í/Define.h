#pragma once



#define	CLR_DEBUG			RGB(255,0,255)
#define	CLR_RED				RGB(255,0,0)

#define	CLR_GREEN			RGB(0,255,0)

#define	PREFIX_LOG			_T("16YiGame.Frame.��Ϸ�㳡")