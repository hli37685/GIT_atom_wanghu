/************************************************
File	: MyFileLog.h
Author	: luwenguang[ulovesoft@gmail.com]
Contact	:  
Time	: 2009-03-05
Location: Room 3-1-5-16, JiangDuGong Circlet, JiangHan South Road, Jingzhou 
Comment	: 
History	:
************************************************/

#pragma once


#include "..\..\..\���ӿ�\Lib\Common\i_Common.h"
#include "..\..\..\���ӿ�\Lib\FileIO\i_FileIO.h"



class CMyFileLog:public CFileLog
{
public:
	CMyFileLog(void);
	~CMyFileLog(void);

	void	Write(LPCTSTR lpLog);

protected:
	bool	Init(void);
	void	Uninit(void);

private:

};

extern CMyFileLog g_FileLog;



//-----------------------------------------------
//					the end
//-----------------------------------------------
