/************************************************
File	: MyFileLog.cpp
Author	: luwenguang[ulovesoft@gmail.com]
Contact	:  
Time	: 2009-03-05
Location: Room 3-1-5-16, JiangDuGong Circlet, JiangHan South Road, Jingzhou 
Comment	: 
History	:
************************************************/

#include "StdAfx.h"
#include "..\Define.h"
#include "MyFileLog.h"


#pragma comment(lib, "..\\..\\���ӿ�\\Lib\\unicode\\Common.lib")
#pragma comment(lib, "..\\..\\���ӿ�\\Lib\\unicode\\FileIO.lib")


CMyFileLog g_FileLog;


CMyFileLog::CMyFileLog(void)
{
	this->Init();
}

CMyFileLog::~CMyFileLog(void)
{
	this->Uninit();
}

//��ʼ��,�����ļ�
bool	CMyFileLog::Init(void)
{
	//������־Ŀ¼
	::CreateDirectory(FILE_LOG_FOLDER, NULL);

	this->SetEnable(TRUE);
	
	//��ʽ���ļ�·��
	SYSTEMTIME st;
	::GetLocalTime(&st);

	CString strFilePath;

#ifdef _DEBUG
	strFilePath.Format(_T("%s\\Plaza_%04d%02d%02d_%02d%02d%02d.log"),
						FILE_LOG_FOLDER,
						st.wYear,st.wMonth,st.wDay,
						st.wHour,st.wMinute,st.wSecond);
#else
	strFilePath.Format(_T("%s\\Plaza.log"),
						FILE_LOG_FOLDER);
#endif

	return this->_Init(strFilePath);
}

//д
void	CMyFileLog::Write(LPCTSTR lpLog)
{
	if((lpLog==NULL) || (lstrlen(lpLog)<=0))
	{
		return ;
	}

	if(!this->IsEnable())
	{
		return ;
	}

	this->_Write(lpLog);
}

//����
void	CMyFileLog::Uninit(void)
{
	CString Log;
	Log.Format(_T("%s,%d"), __FUNCTIONW__,__LINE__);
	this->Write(Log);
}




//-----------------------------------------------
//					the end
//-----------------------------------------------