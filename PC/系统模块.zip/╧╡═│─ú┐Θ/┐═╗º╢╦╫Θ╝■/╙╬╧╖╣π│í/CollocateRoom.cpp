#include "stdafx.h"
#include "Resource.h"
#include "CollocateRoom.h"

//////////////////////////////////////////////////////////////////////////////////
//�ؼ�����

//��ť�ؼ�
const TCHAR * szButtonOKControlName=TEXT("ButtonOK");
const TCHAR * szButtonCancelControlName=TEXT("ButtonCancel");

//�༭�ؼ�
const TCHAR * szEditWinRateControlName=TEXT("EditWinRate");
const TCHAR * szEditFleeRateControlName=TEXT("EditFleeRate");
const TCHAR * szEditScoreMinControlName=TEXT("EditScoreMin");
const TCHAR * szEditScoreMaxControlName=TEXT("EditScoreMax");

//��ѡ�ؼ�
const TCHAR * szCheckOptionWinRateControlName=TEXT("CheckOptionWinRate");
const TCHAR * szCheckOptionFleeRateControlName=TEXT("CheckOptionFleeRate");
const TCHAR * szCheckOptionScoreRangeControlName=TEXT("CheckOptionScoreRange");
const TCHAR * szCheckOptionLimitDetestControlName=TEXT("CheckOptionLimitDetest");
const TCHAR * szCheckOptionLimitSameIPControlName=TEXT("CheckOptionLimitSameIP");
const TCHAR * szCheckOptionInviteModeControlName=TEXT("CheckOptionInviteMode");

const TCHAR * szTextUI6ControlName=TEXT("TextUI6");




//////////////////////////////////////////////////////////////////////////////////

//��������
CCollocateRoom::CCollocateRoom() : CSkinDialog(IDD_DLG_POPUP)
{
	//���ñ���
	m_pParameterGame=NULL;
	m_pParameterServer=NULL;
}

CCollocateRoom::~CCollocateRoom()
{
}

//���ò���
bool CCollocateRoom::InitCollocate(CParameterGame * pParameterGame, CParameterServer * pParameterServer)
{
	//���ñ���
	m_pParameterGame=pParameterGame;
	m_pParameterServer=pParameterServer;

	//Ĭ�ϲ���
	DefaultParameter();

	return true;
}

//��ʼ�ؼ�
VOID CCollocateRoom::InitControlUI()
{
	__super::InitControlUI();

	//��������
	CEditUI * pEditUIControl=NULL;

	//��������
	pEditUIControl = static_cast<CEditUI *>(GetControlByName(szEditWinRateControlName));
	if(pEditUIControl!=NULL) 
	{
		pEditUIControl->SetMaxChar(5);
		pEditUIControl->SetOnlyNumber();
	}

	//��������
	pEditUIControl = static_cast<CEditUI *>(GetControlByName(szEditFleeRateControlName));
	if(pEditUIControl!=NULL) 
	{
		pEditUIControl->SetMaxChar(5);
		pEditUIControl->SetOnlyNumber();
	}

	//��������
	pEditUIControl = static_cast<CEditUI *>(GetControlByName(szEditScoreMinControlName));
	if(pEditUIControl!=NULL) 
	{
		pEditUIControl->SetMaxChar(11);
		pEditUIControl->SetOnlyNumber();
	}

	//��������
	pEditUIControl = static_cast<CEditUI *>(GetControlByName(szEditScoreMaxControlName));
	if(pEditUIControl!=NULL) 
	{
		pEditUIControl->SetMaxChar(10);
		pEditUIControl->SetOnlyNumber();
	}
}

//��Ϣ����
VOID CCollocateRoom::Notify(TNotifyUI &  msg)
{
	__super::Notify(msg);

	//��ȡ����
	CControlUI * pControlUI = msg.pSender;

	//����¼�
	if (lstrcmp(msg.sType, TEXT("click")) == 0)
	{
		if(lstrcmp(pControlUI->GetName(), szButtonOKControlName)==0)
		{
			return OnOK();
		}
		else if(lstrcmp(pControlUI->GetName(), szButtonCancelControlName)==0)
		{
			return OnCancel();
		}
	}
}

//��ʼ������
BOOL CCollocateRoom::OnInitDialog()
{
	__super::OnInitDialog();

	//��ȡλ��
	CRect rctClient;
	GetClientRect(&rctClient);

	//���ñ���
	SetWindowText(TEXT("��������"));

	//���ô���
	CSize SizeWindow(m_PaintManager.GetInitSize());
	SetWindowPos(NULL, 0, 0, SizeWindow.cx, SizeWindow.cy, SWP_NOZORDER|SWP_NOMOVE);	

	//��������
	ASSERT(CParameterGlobal::GetInstance()!=NULL);
	CParameterGlobal * pParameterGlobal=CParameterGlobal::GetInstance();

	pParameterGlobal->DefaultParameter();
	pParameterGlobal->LoadParameter();

	if ((m_pParameterServer!=NULL)&&(m_pParameterGame!=NULL))
	{
		//��Ϸ����
		m_wMinWinRate=m_pParameterGame->m_wMinWinRate;
		m_wMaxFleeRate=m_pParameterGame->m_wMaxFleeRate;
		m_bLimitWinRate=m_pParameterGame->m_bLimitWinRate;
		m_lMaxGameScore=m_pParameterGame->m_lMaxGameScore;
		m_lMinGameScore=m_pParameterGame->m_lMinGameScore;
		m_bLimitFleeRate=m_pParameterGame->m_bLimitFleeRate;
		m_bLimitGameScore=m_pParameterGame->m_bLimitGameScore;

		//��������
		m_bLimitDetest=pParameterGlobal->m_bLimitDetest;
		m_bLimitSameIP=pParameterGlobal->m_bLimitSameIP;
		if(pParameterGlobal->m_cbInviteMode==INVITE_MODE_NONE)
		{
			m_bInviteMode=true;
		}
		else
		{
			m_bInviteMode=false;
		}

	}

	/*CControlUI * pControlUI=NULL;
	pControlUI=GetControlByName(szCheckOptionScoreRangeControlName);
	pControlUI->SetVisible(false);

	pControlUI=GetControlByName(szEditScoreMaxControlName);
	pControlUI->SetVisible(false);

	pControlUI=GetControlByName(szEditScoreMinControlName);
	pControlUI->SetVisible(false);

	pControlUI=GetControlByName(szTextUI6ControlName);
	pControlUI->SetVisible(false);*/
	


	//���¿ؼ�
	UpdateControlStatus();

	return TRUE; 
}

//ȷ������
VOID CCollocateRoom::OnOK()
{
	//�������
	if(SaveParameter()==false)return;

	//��������
	ASSERT(CParameterGlobal::GetInstance()!=NULL);
	CParameterGlobal * pParameterGlobal=CParameterGlobal::GetInstance();

	//��������
	if ((m_pParameterServer!=NULL)&&(m_pParameterGame!=NULL))
	{
		//��������
		pParameterGlobal->m_bLimitDetest=m_bLimitDetest;
		pParameterGlobal->m_bLimitSameIP=m_bLimitSameIP;

		if(m_bInviteMode==true)
		{
			pParameterGlobal->m_cbInviteMode=INVITE_MODE_NONE;
		}
		else
		{
			pParameterGlobal->m_cbInviteMode=INVITE_MODE_ALL;
		}

		pParameterGlobal->SaveParameter();

		//��Ϸ����
		m_pParameterGame->m_wMinWinRate=m_wMinWinRate;
		m_pParameterGame->m_wMaxFleeRate=m_wMaxFleeRate;
		m_pParameterGame->m_lMaxGameScore=m_lMaxGameScore;
		m_pParameterGame->m_lMinGameScore=m_lMinGameScore;
		m_pParameterGame->m_bLimitWinRate=m_bLimitWinRate;
		m_pParameterGame->m_bLimitFleeRate=m_bLimitFleeRate;
		m_pParameterGame->m_bLimitGameScore=m_bLimitGameScore;
	}

	//���ٴ���
	__super::OnOK();
}

//��ȡ״̬
bool CCollocateRoom::GetButtonCheckStatus(LPCTSTR pszButtonName)
{
	//��ȡ�ؼ�
	CCheckButtonUI * pControlUI= static_cast<CCheckButtonUI *>(GetControlByName(pszButtonName));
	if(pControlUI==NULL) return false;

	return pControlUI->GetCheck();
}

//��ȡ�ַ�
VOID CCollocateRoom::GetControlText(LPCTSTR pszControlName,TCHAR szString[], WORD wMaxCount)
{
	//Ĭ�����
	szString[0]=0;

	//��ȡ�ؼ�
	CControlUI * pControlUI=GetControlByName(pszControlName);
	if(pControlUI==NULL) return;

	//��ȡ�ַ�
	CString strString(pControlUI->GetText());

	//ȥ���ո�
	strString.TrimLeft();
	strString.TrimRight();

	//�����ַ�
	lstrcpyn(szString,strString,wMaxCount);

	return;
}

//�������
bool CCollocateRoom::SaveParameter()
{
	//��ȡ����
	m_bLimitWinRate=GetButtonCheckStatus(szCheckOptionWinRateControlName);
	m_bLimitFleeRate=GetButtonCheckStatus(szCheckOptionFleeRateControlName);
	m_bLimitGameScore=GetButtonCheckStatus(szCheckOptionScoreRangeControlName);
	m_bLimitDetest=GetButtonCheckStatus(szCheckOptionLimitDetestControlName);
	m_bLimitSameIP=GetButtonCheckStatus(szCheckOptionLimitSameIPControlName);
	m_bInviteMode=GetButtonCheckStatus(szCheckOptionInviteModeControlName);

	//��������
	TCHAR szBuffer[128]=TEXT("");
	CControlUI * pControlUI=NULL;

	//���ʤ��	
	GetControlText(szEditWinRateControlName,szBuffer,CountArray(szBuffer));
	m_wMinWinRate=(WORD)(_tstof(szBuffer)*100.0)%10000;

	//�������
	GetControlText(szEditFleeRateControlName,szBuffer,CountArray(szBuffer));
	m_wMaxFleeRate=(WORD)(_tstof(szBuffer)*100.0)%10000;

	//��������
	GetControlText(szEditScoreMaxControlName,szBuffer,CountArray(szBuffer));
	m_lMaxGameScore=_tstoi64(szBuffer);

	//��������
	GetControlText(szEditScoreMinControlName,szBuffer,CountArray(szBuffer));
	m_lMinGameScore=_tstoi64(szBuffer);

	if ((m_bLimitGameScore)&&(m_lMinGameScore>=m_lMaxGameScore))
	{
		//��ʾ��Ϣ
		CInformation Information(this);
		Information.ShowMessageBox(TEXT("�������Ʒ�Χ��������ȷ������ȷ���û������Ʒ�Χ��"),MB_ICONINFORMATION);

		//���ý���
		pControlUI=GetControlByName(szEditScoreMinControlName);
		pControlUI->SetFocus();

		return false;
	}

	return true;
}

//Ĭ�ϲ���
bool CCollocateRoom::DefaultParameter()
{
	//ʤ������
	m_wMinWinRate=0;
	m_bLimitWinRate=false;

	//��������
	m_wMaxFleeRate=5000;
	m_bLimitFleeRate=false;

	//��������
	m_bLimitGameScore=false;
	m_lMaxGameScore=2147483647L;
	m_lMinGameScore=-2147483646L;

	//��������
	m_bLimitDetest=false;
	m_bLimitSameIP=false;
	m_bInviteMode=false;

	return true;
}

//���¿���
bool CCollocateRoom::UpdateControlStatus()
{
	//��������
	TCHAR szBuffer[128]=TEXT("");
	CControlUI * pControlUI=NULL;

	//���ÿؼ�
	CCheckButtonUI * pCheckOption = static_cast<CCheckButtonUI *>(GetControlByName(szCheckOptionWinRateControlName));
	if(pCheckOption) pCheckOption->SetCheck(m_bLimitWinRate);

	//���ÿؼ�
	pCheckOption = static_cast<CCheckButtonUI *>(GetControlByName(szCheckOptionFleeRateControlName));
	if(pCheckOption) pCheckOption->SetCheck(m_bLimitFleeRate);

	//���ÿؼ�
	pCheckOption = static_cast<CCheckButtonUI *>(GetControlByName(szCheckOptionScoreRangeControlName));
	if(pCheckOption) pCheckOption->SetCheck(m_bLimitGameScore);

	//���ÿؼ�
	pCheckOption = static_cast<CCheckButtonUI *>(GetControlByName(szCheckOptionLimitDetestControlName));
	if(pCheckOption) pCheckOption->SetCheck(m_bLimitDetest);

	//���ÿؼ�
	pCheckOption = static_cast<CCheckButtonUI *>(GetControlByName(szCheckOptionLimitSameIPControlName));
	if(pCheckOption) pCheckOption->SetCheck(m_bLimitSameIP);

	//���ÿؼ�
	pCheckOption = static_cast<CCheckButtonUI *>(GetControlByName(szCheckOptionInviteModeControlName));
	if(pCheckOption) pCheckOption->SetCheck(m_bInviteMode);

	
	//���ʤ��	
	_sntprintf(szBuffer,CountArray(szBuffer),TEXT("%.2f"),((DOUBLE)(m_wMinWinRate))/100.0);
	pControlUI = GetControlByName(szEditWinRateControlName);
	if(pControlUI) pControlUI->SetText(szBuffer);

	//�������
	_sntprintf(szBuffer,CountArray(szBuffer),TEXT("%.2f"),((DOUBLE)(m_wMaxFleeRate))/100.0);
	pControlUI = GetControlByName(szEditFleeRateControlName);
	if(pControlUI) pControlUI->SetText(szBuffer);

	//��������
	_sntprintf(szBuffer,CountArray(szBuffer),TEXT("%ld"),m_lMinGameScore);
	pControlUI = GetControlByName(szEditScoreMinControlName);
	if(pControlUI) pControlUI->SetText(szBuffer);

	//��������
	_sntprintf(szBuffer,CountArray(szBuffer),TEXT("%ld"),m_lMaxGameScore);
	pControlUI = GetControlByName(szEditScoreMaxControlName);
	if(pControlUI) pControlUI->SetText(szBuffer);

	return true;
}
