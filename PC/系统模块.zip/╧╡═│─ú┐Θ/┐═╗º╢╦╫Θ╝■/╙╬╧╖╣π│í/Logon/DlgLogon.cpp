#include "Stdafx.h"
#include "Resource.h"
#include "DlgLogon.h"
#include "..\GamePlaza.h"
#include "MissionLogon.h"
#include "DlgProxyConfig.h"

//////////////////////////////////////////////////////////////////////////////////
//��Ļλ��
#define LAYERED_SIZE				4									//�ֲ��С

//�ؼ���ʶ
#define IDC_WEB_PUBLICIZE			300									//����ؼ�
#define IDC_WEB_PUBLICIZE_LOGON		301									//����ؼ�

//////////////////////////////////////////////////////////////////////////////////
//��ť�ؼ�
const TCHAR* const szButtonCloseControlName			= TEXT("ButtonClose");
const TCHAR* const szButtonMinControlName			= TEXT("ButtonMin");
const TCHAR* const szButtonLogonControlName			= TEXT("ButtonLogon");
const TCHAR* const szButtonWebchatLogonControlName	= TEXT("ButtonWebchatLogon");
const TCHAR* const szButtonQQLogonControlName		= TEXT("ButtonQQLogon");
const TCHAR* const szButtonRegisterControlName		= TEXT("ButtonRegister");
const TCHAR* const szButtonCleanAccountsControlName = TEXT("ButtonCleanAccounts");
const TCHAR* const szButtonForgetPasswdControlName	= TEXT("ButtonForgetPasswd");
const TCHAR* const szButtonWebLink1ControlName = TEXT("ButtonWebLink1");
const TCHAR* const szButtonWebLink2ControlName = TEXT("ButtonWebLink2");
const TCHAR* const szButtonWebLink3ControlName = TEXT("ButtonWebLink3");
const TCHAR* const szButtonWebLink4ControlName = TEXT("ButtonWebLink4");

//��Ͽؼ�
const TCHAR* const szComboServerControlName		= TEXT("ComboServer");
const TCHAR* const szComboAccountsControlName	= TEXT("ComboAccounts");

//�༭�ؼ�
const TCHAR* const szEditServerControlName		= TEXT("EditServer");
const TCHAR* const szEditAccountsControlName	= TEXT("EditAccounts");
const TCHAR* const szEditPasswordControlName	= TEXT("EditPassword");

//��ǩ�ؼ�
const TCHAR* const szLabelTitleControlName		= TEXT("LabelTitle");
const TCHAR* const szLabelLogoControlName		= TEXT("LabelLogo");

//��ѡ��ť
const TCHAR* const szCheckButtonPasswdControlName	= TEXT("CheckButtonPasswd");
const TCHAR* const szCheckButtonAgreeControlName	= TEXT("CheckButtonAgree");

//�ؼ���ʶ
//////////////////////////////////////////////////////////////////////////////////
BEGIN_MESSAGE_MAP(CDlgLogon, CFGuiDialog)

	//ϵͳ��Ϣ
	ON_WM_SIZE()
	ON_WM_TIMER()

	//�ؼ���Ϣ
	ON_CBN_SELCHANGE(IDC_ACCOUNTS, OnSelchangeAccounts)
	ON_CBN_EDITCHANGE(IDC_ACCOUNTS, OnCbnEditchangeAccounts)
END_MESSAGE_MAP()

BEGIN_EVENTSINK_MAP(CDlgLogon, CFGuiDialog)
	ON_EVENT(CDlgLogon, IDC_WEB_PUBLICIZE_LOGON, 250, OnBeforeNavigate2Web, VTS_DISPATCH VTS_PVARIANT VTS_PVARIANT VTS_PVARIANT VTS_PVARIANT VTS_PVARIANT VTS_PBOOL)
END_EVENTSINK_MAP()

//////////////////////////////////////////////////////////////////////////////////

//���캯��
CDlgLogon::CDlgLogon() : CFGuiDialog(IDD_DLG_POPUP)
{
	//��¼��Ϣ
	m_dwGameID=0;
	m_szAccounts[0]=0;
	m_szPassword[0]=0;
	m_szLogonServer[0]=0;
	m_szPassPortID[0]=0;

	//���ñ���
	m_cbRemPassword=FALSE;
	m_cbLogonMode=LOGON_BY_ACCOUNTS;

	//�ؼ�����
	m_pDlgAccedit=NULL;

	return;
}

//��������
CDlgLogon::~CDlgLogon()
{
	//ɾ������
	for (INT_PTR i=0;i<m_AccountsInfoArray.GetCount();i++)
	{
		SafeDelete(m_AccountsInfoArray[i]);
	}

	if(m_pDlgAccedit) m_pDlgAccedit->EndDialog(IDOK);

	return;
}

//��������
BOOL CDlgLogon::OnInitDialog()
{
	__super::OnInitDialog();

	//���ô���
	ModifyStyle(0, WS_MINIMIZEBOX);
	ModifyStyle(0, WS_MAXIMIZEBOX);

	//���ñ���
	SetWindowText(TEXT("�û���¼.16����Ϸ"));

	//����ͼ��
	SetIcon(LoadIcon(AfxGetInstanceHandle(),MAKEINTRESOURCE(IDR_MAINFRAME)),TRUE);
	SetIcon(LoadIcon(AfxGetInstanceHandle(),MAKEINTRESOURCE(IDR_MAINFRAME)),FALSE);

	//��������
	CSkinDialog::SetWndFont(this,NULL);
	
	//������Դ
	CPngImage ImageBack;
	ImageBack.LoadImage(GetModuleHandle(PLATFORM_RESOURCE_DLL_NAME),TEXT("DLG_LOGON_BACK"));

	//���ô�С
	CSize SizeWindow(ImageBack.GetWidth(),ImageBack.GetHeight());
	SetWindowPos(NULL,0,0,SizeWindow.cx,SizeWindow.cy,SWP_NOZORDER|SWP_NOMOVE|SWP_NOREDRAW);

	//���ؼ�
	CRect rctCreate(0,0,0,0);
	m_PlatformPublicize.Create(NULL,NULL,WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN,rctCreate,this,IDC_WEB_PUBLICIZE);

	//��ȡ����
	CGlobalWebLink * pGlobalWebLink=CGlobalWebLink::GetInstance();

	//�����ַ
	TCHAR szBillUrl[256]=TEXT("");
	_sntprintf(szBillUrl,CountArray(szBillUrl),TEXT("%s/Ads/LogonLogo.aspx"),pGlobalWebLink->GetPlatformLink());


	//���ù��
	m_PlatformPublicize.Navigate(szBillUrl);
	m_PlatformPublicize.SetWindowPos(NULL,LAYERED_SIZE+2,73,SizeWindow.cx-2*LAYERED_SIZE-4,206,SWP_NOZORDER|SWP_NOCOPYBITS|SWP_NOACTIVATE);

	//΢��ɨ�� ��ѶQQ�����ӿ�
	m_cbIsShowedWebChatLogon=FALSE;
	m_cbIsShowedQQLogon=FALSE;

	CRect rcCreate_Logon(0,0,0,0);
	m_PlatformPublicize_Logon.Create(NULL,NULL,WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN,rcCreate_Logon,this,IDC_WEB_PUBLICIZE_LOGON);
	//m_PlatformPublicize_Logon.Navigate(szBillUrl);
	m_PlatformPublicize_Logon.SetWindowPos(NULL,LAYERED_SIZE,40,SizeWindow.cx-2*LAYERED_SIZE,SizeWindow.cy-40,SWP_NOZORDER|SWP_NOCOPYBITS|SWP_NOACTIVATE);
	m_PlatformPublicize_Logon.ShowWindow(false);
	//���д���
	CenterWindow(this);

	//������Ϣ
	LoadAccountsInfo();
	LoadLogonServerInfo();

	//���Ҷ���
	CComboUI * pComboAccounts= (CComboUI * )GetControlByName(szComboAccountsControlName);
	if(pComboAccounts!=NULL)
	{
		//���Ҷ���
		CEditUI * pEditPassword = (CEditUI * )GetControlByName(szEditPasswordControlName);
		if(pEditPassword==NULL) return FALSE;

		//���ý���
		if (pComboAccounts->GetCurSel()==LB_ERR) pEditPassword->SetFocus();
		else pComboAccounts->SetFocus();
	}
	
	//��ȡ����
	CRect rctWindow;
	GetWindowRect(&rctWindow);

	//����λ��
	CRect rcUnLayered;
	rcUnLayered.top=LAYERED_SIZE;
	rcUnLayered.left=LAYERED_SIZE;
	rcUnLayered.right=rctWindow.Width()-LAYERED_SIZE;
	rcUnLayered.bottom=rctWindow.Height()-LAYERED_SIZE;

	//��������
	CSize rcRoundCornor = GetRoundCornor();

	//��������
	CRgn RgnWindow;
	RgnWindow.CreateRoundRectRgn(LAYERED_SIZE,LAYERED_SIZE,SizeWindow.cx-LAYERED_SIZE+1,SizeWindow.cy-LAYERED_SIZE+1,rcRoundCornor.cx,rcRoundCornor.cy);

	//��������
	SetWindowRgn(RgnWindow,FALSE);

	//�ֲ㴰��
	m_SkinLayered.CreateLayered(m_hWnd);
	m_SkinLayered.InitLayeredArea(ImageBack,255,rcUnLayered,CPoint(rcRoundCornor.cx,rcRoundCornor.cy),false);

	return TRUE;
}

//��Ϣ����
BOOL CDlgLogon::PreTranslateMessage(MSG * pMsg)
{
	//��������
	if ((pMsg->message==WM_KEYDOWN)&&(pMsg->wParam==VK_ESCAPE))
	{
		return TRUE;
	}

	return __super::PreTranslateMessage(pMsg);
}

//ȷ������
VOID CDlgLogon::OnOK()
{
	//��ȡ��Ϣ
	if (this->GetInformation()==false) return;

	//���ش���
	ShowWindow(SW_HIDE);

	//ִ�е�¼
	CMissionLogon * pMissionLogon=CMissionLogon::GetInstance();
	if (pMissionLogon!=NULL) pMissionLogon->PerformLogonMission(m_cbRemPassword==TRUE);

	return;
}

//ȡ����Ϣ
VOID CDlgLogon::OnCancel()
{
	if(m_cbIsShowedWebChatLogon ==TRUE || m_cbIsShowedQQLogon == TRUE)
	{
		m_PlatformPublicize_Logon.ShowWindow(false);

		m_PlatformPublicize.ShowWindow(true);
		m_cbIsShowedWebChatLogon = FALSE;
		m_cbIsShowedQQLogon = FALSE;

		m_cbLogonMode = LOGON_BY_ACCOUNTS; //�ظ��˺ŵ�½ģʽ
	}
	else
	{
		//�رմ���
		DestroyWindow();
		AfxGetMainWnd()->PostMessage(WM_CLOSE,0,0);
	}

	return;
}

//��ʼ�ؼ�
void CDlgLogon::InitControlUI()
{
	//���Ҷ���
	CEditUI * pEditPassword = (CEditUI * )GetControlByName(szEditPasswordControlName);
	if(pEditPassword!=NULL)
	{		
		pEditPassword->SetPasswordMode(true);
		pEditPassword->SetMaxChar(LEN_PASSWORD-1);
	}

	//���Ҷ���
	CCheckButtonUI * pCheckButton = (CCheckButtonUI * )GetControlByName(szCheckButtonAgreeControlName);
	if(pCheckButton!=NULL)
	{		
		pCheckButton->SetCheck(true);
	}
}

//��Ϣ����
void CDlgLogon::Notify(TNotifyUI &  msg)
{
	//��ȡ����
	CControlUI * pControlUI = msg.pSender;

	//����¼�
	if (lstrcmp(msg.sType, TEXT("click")) == 0)
	{
		if(lstrcmp(pControlUI->GetName(), szButtonCloseControlName)==0) 
		{
			return OnCancel(); 
		}
		else if(lstrcmp(pControlUI->GetName(), szButtonMinControlName)==0)
		{
			ShowWindow(SW_MINIMIZE);
			return;
		}
		else if(lstrcmp(pControlUI->GetName(), szButtonLogonControlName)==0)
		{
			return OnOK();
		}
		else if(lstrcmp(pControlUI->GetName(), szButtonWebchatLogonControlName)==0)
		{
			return OnBnClickedWebChatLogon();
		}
		else if(lstrcmp(pControlUI->GetName(), szButtonQQLogonControlName)==0)
		{
			return OnBnClickedQQLogon();
		}
		else if(lstrcmp(pControlUI->GetName(), szButtonRegisterControlName)==0)
		{
			return OnBnClickedRegister();
		}
		else if(lstrcmp(pControlUI->GetName(), szButtonCleanAccountsControlName)==0)
		{
			return OnBnClickedDeleteRecord();
		}
		else if(lstrcmp(pControlUI->GetName(), szButtonForgetPasswdControlName)==0)
		{
			return OnBnForgetPassword();
		}
		else if(lstrcmp(pControlUI->GetName(), szButtonWebLink1ControlName)==0 ||
				lstrcmp(pControlUI->GetName(), szButtonWebLink4ControlName)==0  )
		{
			//��ȡ����
			CGlobalWebLink * pGlobalWebLink=CGlobalWebLink::GetInstance();

			//�����ַ
			TCHAR szLogonLink[256]=TEXT("");
			_sntprintf(szLogonLink,CountArray(szLogonLink),TEXT("%s/LogonLink%d.aspx"),pGlobalWebLink->GetPlatformLink(),pControlUI->GetTag());

			//��ҳ��
			ShellExecute(NULL,TEXT("OPEN"),szLogonLink,NULL,NULL,SW_NORMAL);

			return;
		}
		else if(lstrcmp(pControlUI->GetName(), szButtonWebLink2ControlName)==0)
		{
			//��ȡ����
			CGlobalWebLink * pGlobalWebLink=CGlobalWebLink::GetInstance();

			//�����ַ
			TCHAR szLogonLink[256]=TEXT("");
			_sntprintf(szLogonLink,CountArray(szLogonLink),TEXT("%s/Pay/PayIndex.aspx"),pGlobalWebLink->GetPlatformLink());

			//��ҳ��
			ShellExecute(NULL,TEXT("OPEN"),szLogonLink,NULL,NULL,SW_NORMAL);

			return;
		}
		else if(lstrcmp(pControlUI->GetName(), szButtonWebLink3ControlName)==0)
		{
			//��ȡ����
			CGlobalWebLink * pGlobalWebLink=CGlobalWebLink::GetInstance();

			//�����ַ
			TCHAR szLogonLink[256]=TEXT("");
			_sntprintf(szLogonLink,CountArray(szLogonLink),TEXT("%s/Shop/Index.aspx"),pGlobalWebLink->GetPlatformLink());

			//��ҳ��
			ShellExecute(NULL,TEXT("OPEN"),szLogonLink,NULL,NULL,SW_NORMAL);

			return;
		}
	}
	else if(lstrcmp(msg.sType,TEXT("itemselect")) ==0 )
	{
		if(lstrcmp(pControlUI->GetName(), szComboServerControlName)==0)
		{
			//���Ҷ���
			CEditUI * pEditServer = (CEditUI * )GetControlByName(szEditServerControlName);
			if(pEditServer!=NULL) pEditServer->SetText(pControlUI->GetText());

			return;
		}
		else if(lstrcmp(pControlUI->GetName(), szComboAccountsControlName)==0)
		{
			return OnSelchangeAccounts();
		}
	}
	else if(lstrcmp(msg.sType,TEXT("textchanged")) ==0 )
	{
		if(lstrcmp(pControlUI->GetName(),szEditAccountsControlName)==0)
		{
			return OnCbnEditchangeAccounts();
		}
	}

	return;
}

//��ʾ��֤
bool CDlgLogon::ShowAccreditWindow()
{
	//��������
	CDlgAccredit DlgAccredit;
	m_pDlgAccedit = &DlgAccredit;
	INT_PTR nEndCode = DlgAccredit.DoModal();
	m_pDlgAccedit=NULL;

	//��������
	if(nEndCode==IDOK)
	{		
		lstrcpyn(m_szPassPortID,DlgAccredit.GetPassPortNumber(),CountArray(m_szPassPortID));
	}

	return nEndCode==IDOK;
}

//��������
WORD CDlgLogon::ConstructLogonPacket(BYTE cbBuffer[], WORD wBufferSize, BYTE cbValidateFlags,BYTE cbValidateFlagsWX)
{
	//��������
	TCHAR szPassword[LEN_MD5];
	CWHEncrypt::MD5Encrypt(m_szPassword,szPassword);

	//��������
	switch (m_cbLogonMode)
	{
	case LOGON_BY_VISITOR:			//�ο͵�¼
		{
			//��������
			CMD_GP_LogonVisitor * pLogonVisitor=(CMD_GP_LogonVisitor *)cbBuffer;

			//ϵͳ��Ϣ
			pLogonVisitor->dwPlazaVersion=VERSION_PLAZA;
			pLogonVisitor->cbValidateFlags=cbValidateFlags;

			return sizeof(CMD_GP_LogonVisitor);
		}
	case LOGON_BY_GAME_ID:			//I D ��¼
		{
			//��������
			CMD_GP_LogonGameID * pLogonGameID=(CMD_GP_LogonGameID *)cbBuffer;

			//ϵͳ��Ϣ
			pLogonGameID->dwPlazaVersion=VERSION_PLAZA;

			//������ʶ
			CWHService::GetMachineIDEx(pLogonGameID->szMachineID);

			//��¼��Ϣ
			pLogonGameID->dwGameID=m_dwGameID;
			lstrcpyn(pLogonGameID->szPassword,szPassword,CountArray(pLogonGameID->szPassword));
			pLogonGameID->cbValidateFlags=cbValidateFlags;

			//��������
			CGlobalUserInfo * pGlobalUserInfo=CGlobalUserInfo::GetInstance();
			tagGlobalUserData * pGlobalUserData=pGlobalUserInfo->GetGlobalUserData();
			lstrcpyn(pGlobalUserData->szPassword,pLogonGameID->szPassword,CountArray(pGlobalUserData->szPassword));

			return sizeof(CMD_GP_LogonGameID);
		}
	case LOGON_BY_ACCOUNTS:			//�ʺŵ�¼
		{
			//��������
			CMD_GP_LogonAccounts * pLogonAccounts=(CMD_GP_LogonAccounts *)cbBuffer;

			//ϵͳ��Ϣ
			pLogonAccounts->dwPlazaVersion=VERSION_PLAZA;

			//������ʶ
			CWHService::GetMachineIDEx(pLogonAccounts->szMachineID);

			//��¼��Ϣ
			pLogonAccounts->cbValidateFlags=cbValidateFlags;
			pLogonAccounts->cbValidateFlagsWX =cbValidateFlagsWX;
			//pLogonAccounts->cbValidateFlagsWX =1;
			lstrcpyn(pLogonAccounts->szPassword,szPassword,CountArray(pLogonAccounts->szPassword));
			lstrcpyn(pLogonAccounts->szAccounts,m_szAccounts,CountArray(pLogonAccounts->szAccounts));
			lstrcpyn(pLogonAccounts->szPassPortID,m_szPassPortID,CountArray(pLogonAccounts->szPassPortID));	

			//��������
			CGlobalUserInfo * pGlobalUserInfo=CGlobalUserInfo::GetInstance();
			tagGlobalUserData * pGlobalUserData=pGlobalUserInfo->GetGlobalUserData();
			lstrcpyn(pGlobalUserData->szPassword,pLogonAccounts->szPassword,CountArray(pGlobalUserData->szPassword));

			//�����С
			WORD wDataSize = sizeof(CMD_GP_LogonAccounts)-sizeof(pLogonAccounts->szPassPortID);
			wDataSize += CountStringBuffer(pLogonAccounts->szPassPortID);

			return wDataSize;
		}
	case LOGON_BY_WebChat:
		{
			//-------------����������-------------------------------------------------------------------------
			//��������
			CMD_GP_LogonOtherPlatform * pLogonAccounts=(CMD_GP_LogonOtherPlatform *)cbBuffer;

			//ϵͳ��Ϣ
			pLogonAccounts->dwPlazaVersion=VERSION_PLAZA;

			//������ʶ
			CWHService::GetMachineIDEx(pLogonAccounts->szMachineID);

			//��¼��Ϣ
			pLogonAccounts->cbPlatformID=0;
			pLogonAccounts->cbGender=0;
			lstrcpyn(pLogonAccounts->szUserUin,m_szUserUin_OtherPlatform,CountArray(pLogonAccounts->szUserUin));
			lstrcpyn(pLogonAccounts->szNickName,m_szNickName_OtherPlatform,CountArray(pLogonAccounts->szNickName));
			lstrcpyn(pLogonAccounts->szCompellation,TEXT(""),CountArray(pLogonAccounts->szCompellation));
			lstrcpyn(pLogonAccounts->szMobilePhone,TEXT(""),CountArray(pLogonAccounts->szMobilePhone));

			//��������
			CGlobalUserInfo * pGlobalUserInfo=CGlobalUserInfo::GetInstance();
			tagGlobalUserData * pGlobalUserData=pGlobalUserInfo->GetGlobalUserData();
			lstrcpyn(pGlobalUserData->szPassword,TEXT("21218CCA77804D2BA1922C33E0151105"),CountArray(pGlobalUserData->szPassword));
			
			return  sizeof(CMD_GP_LogonOtherPlatform);;
		}
	case LOGON_BY_QQ:
		{
			//-------------����������-------------------------------------------------------------------------
			//��������
			CMD_GP_LogonOtherPlatform * pLogonAccounts=(CMD_GP_LogonOtherPlatform *)cbBuffer;

			//ϵͳ��Ϣ
			pLogonAccounts->dwPlazaVersion=VERSION_PLAZA;

			//������ʶ
			CWHService::GetMachineIDEx(pLogonAccounts->szMachineID);

			//��¼��Ϣ
			pLogonAccounts->cbPlatformID=2;
			pLogonAccounts->cbGender=0;
			lstrcpyn(pLogonAccounts->szUserUin,m_szUserUin_OtherPlatform,CountArray(pLogonAccounts->szUserUin));
			lstrcpyn(pLogonAccounts->szNickName,m_szNickName_OtherPlatform,CountArray(pLogonAccounts->szNickName));
			lstrcpyn(pLogonAccounts->szCompellation,TEXT(""),CountArray(pLogonAccounts->szCompellation));
			lstrcpyn(pLogonAccounts->szMobilePhone,TEXT(""),CountArray(pLogonAccounts->szMobilePhone));

			//��������
			CGlobalUserInfo * pGlobalUserInfo=CGlobalUserInfo::GetInstance();
			tagGlobalUserData * pGlobalUserData=pGlobalUserInfo->GetGlobalUserData();
			lstrcpyn(pGlobalUserData->szPassword,TEXT("21218CCA77804D2BA1922C33E0151105"),CountArray(pGlobalUserData->szPassword));
			
			return  sizeof(CMD_GP_LogonOtherPlatform);;
		}

	}

	return 0;
}

//�����ʺ�
VOID CDlgLogon::LoadAccountsInfo()
{
	//��ȡ��Ϣ
	CWHRegKey RegUserInfo;
	if (RegUserInfo.OpenRegKey(REG_USER_INFO,false)==false) return;

	//��������
	DWORD dwRegIndex=0L;
	DWORD dwLastUserID=RegUserInfo.GetValue(TEXT("LastUserID"),0L);

	//��ȡ��Ϣ
	do
	{
		//��������
		tagAccountsInfo AccountsInfo;
		ZeroMemory(&AccountsInfo,sizeof(AccountsInfo));

		//��ȡ����
		TCHAR szKeyItemName[16]=TEXT("");
		if (RegUserInfo.EnumItemString(dwRegIndex++,szKeyItemName,CountArray(szKeyItemName))==false) break;

		//���Ӽ�
		CWHRegKey RegUserItem;
		if (RegUserItem.Attach(RegUserInfo.OpenItemKey(szKeyItemName))==NULL) continue;

		//�ʻ���Ϣ
		AccountsInfo.dwUserID=_tstol(szKeyItemName);
		RegUserItem.GetString(TEXT("GameID"),AccountsInfo.szGameID,CountArray(AccountsInfo.szGameID));
		RegUserItem.GetString(TEXT("UserAccount"),AccountsInfo.szAccounts,CountArray(AccountsInfo.szAccounts));

		//��ȡ����
		TCHAR szPassword[MAX_ENCRYPT_LEN]=TEXT("");
		RegUserItem.GetString(TEXT("UserPassword"),szPassword,CountArray(szPassword));

		//�⿪����
		if (szPassword[0]!=0)
		{
			CWHEncrypt::XorCrevasse(szPassword,AccountsInfo.szPassword,CountArray(AccountsInfo.szPassword));
		}

		//��������
		tagAccountsInfo * pAccountsInfo=new tagAccountsInfo;
		CopyMemory(pAccountsInfo,&AccountsInfo,sizeof(AccountsInfo));

		//��������
		m_AccountsInfoArray.InsertAt(m_AccountsInfoArray.GetCount(),pAccountsInfo);

	} while (true);

	//���Ҷ���
	CComboUI * pComboAccounts= (CComboUI * )GetControlByName(szComboAccountsControlName);
	if(pComboAccounts==NULL) return;

	//���Ҷ���
	CEditUI * pEditAccounts = (CEditUI * )GetControlByName(szEditAccountsControlName);
	if(pEditAccounts==NULL) return;

	//��������
	CListLabelElementUI * pListLabelElement=NULL;

	//������Ϣ
	for (INT_PTR i=0;i<m_AccountsInfoArray.GetCount();i++)
	{
		//������Ϣ
		INT nGameIDItem=CB_ERR;
		INT nAccountsItem=CB_ERR;
		tagAccountsInfo * pAccountsInfo=m_AccountsInfoArray[i];
		
		//������Ϣ
		if (pAccountsInfo->szAccounts[0]!=0)
		{
			try
			{
				//��������
				pListLabelElement = new CListLabelElementUI;
				if(pListLabelElement==NULL) throw TEXT("�ڴ治�㣡");

				//��������
				pListLabelElement->SetAttribute(TEXT("text"),pAccountsInfo->szAccounts);
				pListLabelElement->SetAttribute(TEXT("height"),TEXT("23"));
				pListLabelElement->SetManager(&m_PaintManager,pComboAccounts,true);
				if(pComboAccounts->Add(pListLabelElement)==true) pListLabelElement->SetUserData(pAccountsInfo);

				//Ĭ���ʻ�
				if(dwLastUserID==pAccountsInfo->dwUserID) pListLabelElement->Select(true);
			}
			catch(...)
			{
				ASSERT(FALSE);
				break;
			}
		}
	}

	//����ѡ��
	if ((pComboAccounts->GetCount()>0)&&(pComboAccounts->GetCurSel()==LB_ERR))
	{
		pComboAccounts->SelectItem(0);
		pEditAccounts->SetText(pComboAccounts->GetText());
	}

	return;
}

//��ַ��Ϣ
VOID CDlgLogon::LoadLogonServerInfo()
{
	//��ȡ��Ŀ
	CGlobalServer GlobalServer;
	WORD wItemCount=GlobalServer.GetItemCount();

	//�ϴε�¼
	TCHAR szLastServer[LEN_SERVER]=TEXT("");
	GlobalServer.GetLastServerName(szLastServer);

	//��������
	CListLabelElementUI * pListLabelElement=NULL;

		_sntprintf(m_szLogonServer,
						CountArray(m_szLogonServer) ,
						_T("%s"), 
						szLastServer);

/*

	//��ȡ��Ϣ
	for (WORD i=0;i<wItemCount;i++)
	{
		//��ȡ��Ϣ
		TCHAR szServerItem[LEN_SERVER]=TEXT("");
		GlobalServer.GetServerItemName(i,szServerItem);

		tagServerItem ServerItem;
		GlobalServer.GetServerItemInfo(szServerItem, ServerItem);

		if(ServerItem.dwServerAddr != INADDR_NONE)
		{
			BYTE *pcb = (BYTE *)&ServerItem.dwServerAddr;
			_sntprintf(m_szLogonServer,
						CountArray(m_szLogonServer) ,
						_T("%d.%d.%d.%d"), 
						pcb[0],pcb[1],pcb[2],pcb[3]);
			break;
		}
	}
*/
	return;
}

//��ȡ��Ϣ
bool CDlgLogon::GetInformation()
{
	LoadLogonServerInfo();
	//��ȡ��Ϣ
	m_dwGameID=0;
	m_szPassPortID[0]=0;

	//���Ҷ���
	CEditUI * pEditAccounts = (CEditUI * )GetControlByName(szEditAccountsControlName);
	if(pEditAccounts!=NULL) lstrcpyn(m_szAccounts,pEditAccounts->GetText(),CountArray(m_szAccounts));

	//���Ҷ���
	CEditUI * pEditPassword = (CEditUI * )GetControlByName(szEditPasswordControlName);
	if(pEditPassword!=NULL) lstrcpyn(m_szPassword,pEditPassword->GetText(),CountArray(m_szPassword));

	//��ַ�ж�
	if (m_szLogonServer[0]==0L)
	{
		//��ʾ��Ϣ
		CInformation Information(this);
		Information.ShowMessageBox(TEXT("��ѡ�񡰵�¼�����������ٵ�¼��������������������ָ�ϡ���ȡ������"),MB_ICONERROR,0);

		//��ʾ����
		ShowWindow(SW_SHOW);
		return false;
	}

	//�ʺ��ж�
	if ((m_cbLogonMode==LOGON_BY_ACCOUNTS)&&(m_szAccounts[0]==0L))
	{
		//��ʾ��Ϣ
		CInformation Information(this);
		Information.ShowMessageBox(TEXT("���������ʺź��ٵ�¼��������������������ָ�ϡ���ȡ������"),MB_ICONERROR,0);

		//��ʾ����
		ShowWindow(SW_SHOW);

		//���ý���
		pEditAccounts->SetFocus();

		return false;
	}

	//�����ж�
	if (m_szPassword[0]==0)
	{
		//��ʾ��Ϣ
		CInformation Information(this);
		Information.ShowMessageBox(TEXT("��������������ٵ�¼��������������������ָ�ϡ���ȡ������"),MB_ICONERROR,0);

		//��ʾ����
		ShowWindow(SW_SHOW);

		//���Ҷ���
		CEditUI * pEditPassword = (CEditUI * )GetControlByName(szEditPasswordControlName);
		if(pEditPassword!=NULL) pEditPassword->SetFocus();

		return false;
	}

	//ͬ������
	CCheckButtonUI * pCheckButtonAgree=(CCheckButtonUI *)GetControlByName(szCheckButtonAgreeControlName);;
	if(pCheckButtonAgree!=NULL)
	{
		if(pCheckButtonAgree->GetCheck()==false)
		{
			CInformation Information(this);
			Information.ShowMessageBox(TEXT("��ͬ�����ǵ����"),MB_ICONERROR,0);
			return false;
		}
	}

	//��ס����
	CCheckButtonUI * pCheckButtonPasswd=(CCheckButtonUI *)GetControlByName(szCheckButtonPasswdControlName);;
	if(pCheckButtonPasswd!=NULL)
	{
		m_cbRemPassword=pCheckButtonPasswd->GetCheck();
	}

	return true;
}

//ѡ��ı�
VOID CDlgLogon::OnSelchangeAccounts()
{
	//��������
	CComboUI * pComboAccounts=(CComboUI *)GetControlByName(szComboAccountsControlName);;
	if(pComboAccounts==NULL) return;

	//���Ҷ���
	CEditUI * pEditAccounts = (CEditUI * )GetControlByName(szEditAccountsControlName);
	if(pEditAccounts!=NULL) pEditAccounts->SetText(pComboAccounts->GetText());	

	//���Ҷ���
	CEditUI * pEditPassword = (CEditUI * )GetControlByName(szEditPasswordControlName);
	if(pEditPassword==NULL) return;

	//���Ҷ���
	CCheckButtonUI * pCheckButtonPasswd=(CCheckButtonUI *)GetControlByName(szCheckButtonPasswdControlName);;
	if(pCheckButtonPasswd==NULL) return;

	//��ȡѡ��
	INT nCurrentSel=pComboAccounts->GetCurSel();
	if(nCurrentSel==LB_ERR) return;
	tagAccountsInfo * pAccountsInfo=(tagAccountsInfo *)pComboAccounts->GetItemAt(nCurrentSel)->GetUserData();	

	//���ÿؼ�
	if ((nCurrentSel!=LB_ERR)&&(pAccountsInfo!=NULL))
	{
		//��������
		pEditPassword->SetText(pAccountsInfo->szPassword);

		//��ס����
		bool bRemPassword=(pAccountsInfo->szPassword[0]!=0);
		pCheckButtonPasswd->SetCheck(bRemPassword);
	}
	else
	{
		//��������
		pEditPassword->SetText(TEXT(""));

		//��ס����
		pCheckButtonPasswd->SetCheck(false);
	}

	return;
}

//�༭�ı�
VOID CDlgLogon::OnCbnEditchangeAccounts()
{
	//��ȫ����
	CCheckButtonUI * pCheckButtonPasswd=(CCheckButtonUI *)GetControlByName(szCheckButtonPasswdControlName);;
	if(pCheckButtonPasswd!=NULL) pCheckButtonPasswd->SetCheck(false);

	//��������
	CEditUI * pEditPassword = (CEditUI * )GetControlByName(szEditPasswordControlName);
	if(pEditPassword) pEditPassword->SetText(TEXT(""));

	return;
}

//��������
VOID CDlgLogon::OnBnForgetPassword()
{
	//��ȡ����
	CGlobalWebLink * pGlobalWebLink=CGlobalWebLink::GetInstance();

	//�����ַ
	TCHAR szLogonLink[256]=TEXT("");
	_sntprintf(szLogonLink,CountArray(szLogonLink),TEXT("%s/LogonLink5.aspx"),pGlobalWebLink->GetPlatformLink());

	//��ҳ��
	ShellExecute(NULL,TEXT("OPEN"),szLogonLink,NULL,NULL,SW_NORMAL);
}

//ɾ����¼
VOID CDlgLogon::OnBnClickedDeleteRecord()
{
	//���Ҷ���
	CComboUI * pComboAccounts= (CComboUI * )GetControlByName(szComboAccountsControlName);
	if(pComboAccounts==NULL) return;

	//���Ҷ���
	CEditUI * pEditAccounts = (CEditUI * )GetControlByName(szEditAccountsControlName);
	if(pEditAccounts==NULL) return;

	//���Ҷ���
	CEditUI * pEditPassword = (CEditUI * )GetControlByName(szEditPasswordControlName);
	if(pEditPassword==NULL) return;	

	//��ȡ��Ϣ
	tagAccountsInfo * pAccountsInfo=NULL;
	INT nCurrentSel=pComboAccounts->GetCurSel();

	//ɾ������
	if (nCurrentSel!=LB_ERR)
	{
		//��ȡ����
		ASSERT(pComboAccounts->GetItemAt(nCurrentSel)->GetUserData()!=NULL);
		pAccountsInfo=(tagAccountsInfo *)pComboAccounts->GetItemAt(nCurrentSel)->GetUserData();

		//�����ʶ
		CString strUserID;
		strUserID.Format(TEXT("%ld"),pAccountsInfo->dwUserID);

		//�û�����
		CWHRegKey RegUserInfo;
		RegUserInfo.OpenRegKey(REG_USER_INFO,false);

		//ɾ������
		RegUserInfo.RecurseDeleteKey(strUserID);

		//ɾ���б�
		for (INT i=0;i<pComboAccounts->GetCount();i++)
		{
			if (pComboAccounts->GetItemAt(i)->GetUserData()==pAccountsInfo)
			{
				//ɾ���ַ�
				pComboAccounts->SetText(TEXT(""));
				pEditAccounts->SetText(TEXT(""));
				pComboAccounts->RemoveAt(i);				

				//����ѡ��
				if ((pComboAccounts->GetCurSel()==LB_ERR)&&(pComboAccounts->GetCount()>0))
				{
					pComboAccounts->SelectItem(0);
					pEditAccounts->SetText(pComboAccounts->GetText());
				}

				break;
			}
		}
	}

	//���ý���
	pComboAccounts->SetFocus();

	//��ȡ����
	nCurrentSel=pComboAccounts->GetCurSel();
	pAccountsInfo=(nCurrentSel!=LB_ERR)?pAccountsInfo=(tagAccountsInfo *)pComboAccounts->GetItemAt(nCurrentSel)->GetUserData():NULL;

	//��������
	pEditPassword->SetText((pAccountsInfo!=NULL)?pAccountsInfo->szPassword:TEXT(""));

	//���Ҷ���
	CCheckButtonUI * pCheckButtonPasswd=(CCheckButtonUI *)GetControlByName(szCheckButtonPasswdControlName);;
	if(pCheckButtonPasswd==NULL) return;

	//��ס����
	bool bRemPassword=(pAccountsInfo!=NULL)?(pAccountsInfo->szPassword[0]!=0):false;
	pCheckButtonPasswd->SetCheck(bRemPassword);

	return;
}

//ע���ʺ�
VOID CDlgLogon::OnBnClickedRegister()
{
	//���ش���
	ShowWindow(SW_HIDE);

	//��ȡ��ַ
	CString strLogonServer;
	GetDlgItemText(IDC_LOGON_SERVER,strLogonServer);

	//ע���ʺ�
	CControlUI * pControl = GetControlByName(szEditServerControlName);
	if (pControl != NULL) strLogonServer=pControl->GetText();

	//�����ַ
	strLogonServer.TrimLeft();
	strLogonServer.TrimRight();
	lstrcpyn(m_szLogonServer,(strLogonServer.IsEmpty()==true)?szLogonServer:strLogonServer,CountArray(m_szLogonServer));

	//��ʾע��
	ASSERT(CMissionLogon::GetInstance()!=NULL);
	if (CMissionLogon::GetInstance()!=NULL) CMissionLogon::GetInstance()->ShowRegister();

	return;
}

VOID CDlgLogon::OnBnClickedWebChatLogon()
{
	m_cbIsShowedWebChatLogon = TRUE;
	m_cbIsShowedQQLogon = FALSE;

	lstrcpyn(m_szNickName_OtherPlatform, _T(""),CountArray(m_szNickName_OtherPlatform));
	lstrcpyn(m_szUserUin_OtherPlatform, _T(""),CountArray(m_szUserUin_OtherPlatform));

	//CInformation Information(this);
	//Information.ShowMessageBox(TEXT("OnBnClickedWebChatLogon��"),MB_ICONERROR,0);

	m_PlatformPublicize_Logon.ShowWindow(true);
	m_PlatformPublicize_Logon.SetFocus();

	//��������
	if (m_PlatformPublicize_Logon.m_hWnd==NULL)
	{
		//������Դ
		CPngImage ImageBack;
		ImageBack.LoadImage(GetModuleHandle(PLATFORM_RESOURCE_DLL_NAME),TEXT("DLG_LOGON_BACK"));

		//���ô�С
		CSize SizeWindow(ImageBack.GetWidth(),ImageBack.GetHeight());

		CRect rcCreate_Logon(0,0,0,0);
		m_PlatformPublicize_Logon.Create(NULL,WS_CHILD|WS_VISIBLE,rcCreate_Logon,this,IDC_WEB_PUBLICIZE_LOGON);
		m_PlatformPublicize_Logon.SetWindowPos(NULL,LAYERED_SIZE,80,SizeWindow.cx-2*LAYERED_SIZE,SizeWindow.cy-80,SWP_NOZORDER|SWP_NOCOPYBITS|SWP_NOACTIVATE);
	}

	m_PlatformPublicize_Logon.Navigate(TEXT("http://www.16yi.com/oauth/webchat/qrcode_login.aspx"),NULL,NULL,NULL,NULL);

	m_PlatformPublicize.ShowWindow(false);

	m_cbLogonMode = LOGON_BY_WebChat;
}

VOID CDlgLogon::OnBnClickedQQLogon()
{
	m_cbIsShowedWebChatLogon = FALSE;
	m_cbIsShowedQQLogon = TRUE;

	lstrcpyn(m_szNickName_OtherPlatform, _T(""),CountArray(m_szNickName_OtherPlatform));
	lstrcpyn(m_szUserUin_OtherPlatform, _T(""),CountArray(m_szUserUin_OtherPlatform));

	m_PlatformPublicize_Logon.ShowWindow(true);
	m_PlatformPublicize_Logon.SetFocus();

	//��������
	if (m_PlatformPublicize_Logon.m_hWnd==NULL)
	{
		//������Դ
		CPngImage ImageBack;
		ImageBack.LoadImage(GetModuleHandle(PLATFORM_RESOURCE_DLL_NAME),TEXT("DLG_LOGON_BACK"));

		//���ô�С
		CSize SizeWindow(ImageBack.GetWidth(),ImageBack.GetHeight());

		CRect rcCreate_Logon(0,0,0,0);
		m_PlatformPublicize_Logon.Create(NULL,WS_CHILD|WS_VISIBLE,rcCreate_Logon,this,IDC_WEB_PUBLICIZE_LOGON);
		m_PlatformPublicize_Logon.SetWindowPos(NULL,LAYERED_SIZE,80,SizeWindow.cx-2*LAYERED_SIZE,SizeWindow.cy-80,SWP_NOZORDER|SWP_NOCOPYBITS|SWP_NOACTIVATE);
	}

	//m_PlatformPublicize_Logon.Navigate(TEXT("app:command&arg1=1&arg2=2"),NULL,NULL,NULL,NULL);
	m_PlatformPublicize_Logon.Navigate(TEXT("http://www.16yi.com/oauth/qq/qq_login.aspx?is_pc_qconnect=true"),NULL,NULL,NULL,NULL);
	m_PlatformPublicize.ShowWindow(false);
	m_cbLogonMode = LOGON_BY_QQ;
}


//�ؼ���ɫ
HBRUSH CDlgLogon::OnCtlColor(CDC * pDC, CWnd * pWnd, UINT nCtlColor)
{
	/*switch (nCtlColor)
	{
	case CTLCOLOR_DLG:
	case CTLCOLOR_BTN:
	case CTLCOLOR_STATIC:
		{
			pDC->SetBkMode(TRANSPARENT);
			pDC->SetTextColor(RGB(100,100,100));
			return m_brBrush;
		}
	}*/

	return __super::OnCtlColor(pDC,pWnd,nCtlColor);
}

//�ߴ�仯
VOID CDlgLogon::OnSize(UINT nType, int cx, int cy)
{
	__super::OnSize(nType, cx, cy);	
}

//������ʼ
VOID CDlgLogon::OnBeforeNavigate2Web(LPDISPATCH pDisp, VARIANT FAR * URL, VARIANT FAR * Flags, VARIANT FAR * TargetFrameName, VARIANT FAR * PostData, VARIANT FAR * Headers, BOOL FAR * Cancel)
{
	CString strURL(URL->bstrVal);  
    *Cancel = FALSE;  
    if (strURL == _T("about:blank"))  
        *Cancel = FALSE;  
    else  
    {  
        if (strURL.Find(_T("app:kd��webchat")) >= 0 )  
        {//��ֹ��ת��ָ��ҳ�棡  
			*Cancel = TRUE;  

			//if (GetInformation()==false) return;
//strURL = _T("app:kd��webchat_8406566404884&nickname_������afwer&signstring_0E2C8AD127A0650ADD83BD82E620E29D");
			//app:kd��webchat_8406566404884&nickname_������afwer&0E2C8AD127A0650ADD83BD82E620E29D

			
			lstrcpyn(m_szNickName_OtherPlatform, _T(""),CountArray(m_szNickName_OtherPlatform));
			lstrcpyn(m_szUserUin_OtherPlatform, _T(""),CountArray(m_szUserUin_OtherPlatform));
			//��ȡɨ����Ϣ
			

			CString strTemp = _T("");
			strTemp = strURL.Mid(15);

			int iIndex_1=strTemp.Find(_T("&nickname_"));
			CString strTemp_ID = _T("");
			strTemp_ID = strTemp.Left(iIndex_1);

			int iIndex_2=strTemp.Find(_T("&signstring_"));

			CString strTemp_nickname = _T("");
			strTemp_nickname = strTemp.Mid(iIndex_1+10,iIndex_2-iIndex_1-10);

			CString strTemp_sign = _T("");
			strTemp_sign = strTemp.Mid(iIndex_2+12);

			lstrcpyn(m_szNickName_OtherPlatform,strTemp_nickname,CountArray(m_szNickName_OtherPlatform));
			lstrcpyn(m_szUserUin_OtherPlatform, strTemp_ID,CountArray(m_szUserUin_OtherPlatform));

			TCHAR szSign[LEN_MD5];
			
			TCHAR szSign_temp[21];
			//o--fpvn5XGjic9jBGoXvjSM5Wfo8&
			//_sntprintf(szSign_temp,CountArray(szSign_temp),TEXT("qweqwoij%s"),strTemp_ID);

			//qweqwoijo--fpvn5XGjic9jBGoXvjSM5Wfo8
			strTemp_ID.Remove('-');
			lstrcpyn(szSign_temp,_T("qweqwoij")+strTemp_ID,CountArray(szSign_temp));

			//CWHEncrypt::MD5Encrypt(_T("qweqwoijo--fpvn5XGjic9jBGoXvjSM5Wfo8"),szSign);
			CWHEncrypt::MD5Encrypt(szSign_temp,szSign);

			//CInformation Information(this);
			//Information.ShowMessageBox(szSign_temp,MB_ICONERROR,0);
			//
			////Information.ShowMessageBox(strTemp_ID,MB_ICONERROR,0);
			////Information.ShowMessageBox(strTemp_nickname,MB_ICONERROR,0);

			//Information.ShowMessageBox(strTemp_sign,MB_ICONERROR,0);
			////Information.ShowMessageBox(m_szPassword_temp,MB_ICONERROR,0);
			//Information.ShowMessageBox(szSign,MB_ICONERROR,0);

			if(szSign == strTemp_sign)
			{
				//���ش���
				ShowWindow(SW_HIDE);
				//ִ�е�¼
				CMissionLogon * pMissionLogon=CMissionLogon::GetInstance();
				if (pMissionLogon!=NULL) pMissionLogon->PerformLogonMission(m_cbRemPassword==TRUE);
			}

			

            return;  
        }
		if (strURL.Find(_T("app:kd��qconnect")) >= 0 )  
        {
			*Cancel = TRUE;  
			lstrcpyn(m_szNickName_OtherPlatform, _T(""),CountArray(m_szNickName_OtherPlatform));
			lstrcpyn(m_szUserUin_OtherPlatform, _T(""),CountArray(m_szUserUin_OtherPlatform));

			CString strTemp = _T("");
			strTemp = strURL.Mid(16);

			int iIndex_1=strTemp.Find(_T("&nickname_"));
			CString strTemp_ID = _T("");
			strTemp_ID = strTemp.Left(iIndex_1);

			int iIndex_2=strTemp.Find(_T("&signstring_"));

			CString strTemp_nickname = _T("");
			strTemp_nickname = strTemp.Mid(iIndex_1+10,iIndex_2-iIndex_1-10);

			CString strTemp_sign = _T("");
			strTemp_sign = strTemp.Mid(iIndex_2+12);

			lstrcpyn(m_szNickName_OtherPlatform,strTemp_nickname,CountArray(m_szNickName_OtherPlatform));
			lstrcpyn(m_szUserUin_OtherPlatform, strTemp_ID,CountArray(m_szUserUin_OtherPlatform));

			TCHAR szSign[LEN_MD5];
			
			TCHAR szSign_temp[21];

			strTemp_ID.Remove('-');
			lstrcpyn(szSign_temp,_T("qweqwoij")+strTemp_ID,CountArray(szSign_temp));

			CWHEncrypt::MD5Encrypt(szSign_temp,szSign);

			if(szSign == strTemp_sign)
			{
				//���ش���
				ShowWindow(SW_HIDE);
				//ִ�е�¼
				CMissionLogon * pMissionLogon=CMissionLogon::GetInstance();
				if (pMissionLogon!=NULL) pMissionLogon->PerformLogonMission(m_cbRemPassword==TRUE);
			}

			return;
		}
    }  
  

	return;
}

//////////////////////////////////////////////////////////////////////////////////