class HttpClient
{

}