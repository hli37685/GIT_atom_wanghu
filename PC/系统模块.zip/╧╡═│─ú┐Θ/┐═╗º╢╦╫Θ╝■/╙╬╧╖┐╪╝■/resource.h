//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ShareControl.rc
//
#define IDD_PASSWORD_KEYBOARD           388
#define IDD_INSURE_MAIN                 424
#define IDC_BT_TAKE_SCORE               1017
#define IDC_BT_SAVE_SCORE               1018
#define IDC_SCORE                       1039
#define IDC_USER_NICKNAME               1040
#define IDC_NICKNAME                    1040
#define IDC_PASSWORD                    1059
#define IDD_MESSAGE_BOX                 2000
#define IDC_SCORE_STRING                2000
#define IDC_TAB_CONTROL                 2001
#define IDC_BT_QUERY_INFO               2002
#define IDC_FORGET_INSURE               2003
#define IDB_CHAT_CONTROL_BACK           2004
#define IDC_BT_TRANSFER_SCORE           2004
#define IDB_BT_CHAT_HISTORY             2005
#define IDC_BY_ID                       2005
#define IDB_BT_CHAT_CLOSE               2006
#define IDC_BY_NAME                     2006
#define IDD_BROWSER                     2007
#define IDC_TRANSFER_TYPE_TIP           2007
#define IDB_BT_KEYBOARD                 2008
#define IDC_SCROLLBAR1                  2008
#define IDB_BT_KEYBOARD_CLOSE           2009
#define IDB_KEYBOARD_ITEM1              2010
#define IDB_KEYBOARD_ITEM2              2011
#define IDB_KEYBOARD_ITEM3              2012
#define IDB_PASSWORD_KEYBORAD_BK        2013
#define IDB_BT_INSURE_SCORE             2014
#define IDB_BT_QUERY_INFO               2020
#define IDB_IMAGE_TRUMPET               2022
#define IDB_BITMAP1                     2023
#define IDB_IMAGE_TYPHON                2023
#define IDB_INSURE_BL                   2024
#define IDB_INSURE_TM                   2025
#define IDB_INSURE_TL                   2026
#define IDB_INSURE_MR                   2027
#define IDB_INSURE_ML                   2028
#define IDB_INSURE_TR                   2029
#define IDB_INSURE_BR                   2030
#define IDB_INSURE_BM                   2031
#define IDC_SELECT                      3003
#define IDC_CHAT_SHORT_LIST             3004
#define IDD_EXPRESSION                  3009
#define IDC_HAND_CUR                    3010
#define IDD_INSURE_TRANSFER             3011
#define IDB_USER_STATUS_IMAGE           3013
#define IDB_IMAGE_AFFICHE               3017
#define IDB_IMAGE_PROMPT                3018
#define IDB_IMAGE_SYSTEM                3019

#define IDD_TRANS_MESSAGE               2035
#define IDB_TRANS_BK                    2036
#define IDB_BT_DETAIL_CLOSE             3024


// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        2032
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         2009
#define _APS_NEXT_SYMED_VALUE           2000
#endif
#endif
