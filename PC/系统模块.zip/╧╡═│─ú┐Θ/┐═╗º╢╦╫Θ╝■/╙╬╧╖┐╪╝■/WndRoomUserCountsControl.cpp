#include "StdAfx.h"
#include "Resource.h"
#include "WndRoomUserCountsControl.h"

//////////////////////////////////////////////////////////////////////////


//////////////////////////////////////////////////////////////////////////

BEGIN_MESSAGE_MAP(CWndRoomUserCountsControl, CWnd)

	//ϵͳ��Ϣ
	ON_WM_SIZE()
	ON_WM_PAINT()
	ON_WM_CREATE()
	ON_WM_DESTROY()

END_MESSAGE_MAP()

//////////////////////////////////////////////////////////////////////////

//���캯��
CWndRoomUserCountsControl::CWndRoomUserCountsControl()
{
	//���ñ���

	m_RoomUserCounts=0;

	return;
}

//��������
CWndRoomUserCountsControl::~CWndRoomUserCountsControl()
{
}

//�����
BOOL CWndRoomUserCountsControl::OnCommand(WPARAM wParam, LPARAM lParam)
{
	return __super::OnCommand(wParam,lParam);
}

//������Ϣ
INT CWndRoomUserCountsControl::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (__super::OnCreate(lpCreateStruct)==-1) return -1;

	//��ȡλ��
	CRect rcWindow;
	GetWindowRect(&rcWindow);

	HINSTANCE hInstance=GetModuleHandle(SHARE_CONTROL_DLL_NAME);

	//����λ��
	CBitImage ImageBackGroud;
	ImageBackGroud.LoadFromResource(hInstance,IDB_CHAT_CONTROL_BACK);
	SetWindowPos(NULL,0,0,rcWindow.Width(),ImageBackGroud.GetHeight(),SWP_NOMOVE|SWP_NOZORDER);

	return 0;
}

//�滭����
VOID CWndRoomUserCountsControl::OnPaint()
{
	CPaintDC dc(this);

	//��ȡλ��
	CRect rcClient;
	GetClientRect(&rcClient);

		//������Դ
	CBitImage ImageBackGroud;
	ImageBackGroud.LoadFromResource(GetModuleHandle(SHARE_CONTROL_DLL_NAME),IDB_CHAT_CONTROL_BACK);

	//��Ⱦ����
	CSkinRenderManager * pSkinRenderManager=CSkinRenderManager::GetInstance();
	if (pSkinRenderManager!=NULL) pSkinRenderManager->RenderImage(ImageBackGroud);

	//�滭����
	for (INT nXPos=0;nXPos<rcClient.Width();nXPos+=ImageBackGroud.GetWidth())
	{
		ImageBackGroud.BitBlt(dc,nXPos,0);
	}


		//����λ��
		CRect rcTargetUser;
		rcTargetUser.top=rcClient.top+2;
		rcTargetUser.left=rcClient.left+26;
		rcTargetUser.bottom=rcClient.bottom;
		rcTargetUser.right=rcClient.right-40;

		//���� DC
		dc.SetBkMode(TRANSPARENT);
		dc.SetTextColor(RGB(232,196,163));
		dc.SelectObject(CSkinResourceManager::GetInstance()->GetDefaultFont());

		//�滭��Ϣ
		TCHAR szString[64]=TEXT("");
		_sntprintf(szString,CountArray(szString),TEXT("Ŀ���û���%s��"),m_RoomUserCounts);
		dc.DrawText(szString,lstrlen(szString),&rcTargetUser,DT_LEFT|DT_VCENTER|DT_END_ELLIPSIS|DT_SINGLELINE);
	

	return;
}

//������Ϣ
VOID CWndRoomUserCountsControl::OnDestroy()
{
	__super::OnDestroy();

	return;
}

//λ�ñ仯
VOID CWndRoomUserCountsControl::OnSize(UINT nType, INT cx, INT cy)
{
	__super::OnSize(nType, cx, cy);

	

	return;
}
int CWndRoomUserCountsControl::GetCounts()
{
	return m_RoomUserCounts;
}

void CWndRoomUserCountsControl::SetCounts(int iCounts)
{
	m_RoomUserCounts=iCounts;
}
