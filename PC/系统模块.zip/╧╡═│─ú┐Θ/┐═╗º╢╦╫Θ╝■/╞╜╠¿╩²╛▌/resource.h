//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by PlatformData.rc
//
#define IDB_PUBLICIZE_LOGO              12000
#define IDR_PNG1                        12002
#define IDR_PNG2                        12006

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        12007
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         12000
#define _APS_NEXT_SYMED_VALUE           12000
#endif
#endif
