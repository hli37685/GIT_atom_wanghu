//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by PlatformResource.rc
//
#define IDC_HAND_CUR                    1010
#define IDC_VIDEO_WND                   2005
#define IDC_CAMERA_CONTROL              2005
#define IDC_STRING                      2008
#define IDC_STRING_CONTROL              2008
#define IDC_BT_REPEAT                   2010
#define IDC_BT_SAVE_EDIT                2011
#define IDC_BT_CAMERA_DICT              2012
#define IDB_BITMAP1                     2016
#define IDB_SCROLLBAR                   2016
#define IDB_IMAGE_REGISTER              2017
#define IDB_GAME_TYPE_L                 2018
#define IDB_GAME_TYPE_M                 2019
#define IDB_GAME_TYPE_R                 2020
#define IDB_TASK_LIST_T                 2026
#define IDD_CAPTURE_VIDEO               3002

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        2027
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         2009
#define _APS_NEXT_SYMED_VALUE           2001
#endif
#endif
