#include "Stdafx.h"
#include "..\GamePlaza.h"
#include "DlgEnquire.h"
#include "..\Room\DlgSearchUser.h"
#include "PlatformFrame.h"
#include "..\FileIO\MyFileLog.h"
#include "..\Define.h"


//��Ļ����
#define LESS_LIST_CX				285									//�б�����
#define SPLITTER_WIDTH				8									//��ֿ���

//��Ļ����
//#define LESS_SCREEN_CY				740									//��С�߶�
//#define LESS_SCREEN_CX				1024								//��С����

//��Ļ����
#define LESS_SCREEN_CY				800									//��С�߶�
#define LESS_SCREEN_CX				1280								//��С����


//-----------------------------------------------
//�ؼ���ʶ
#define IDC_SERVER_LIST				300									//��Ϸ�б�
#define IDC_WEB_PUBLICIZE			301									//����ؼ�
#define IDC_SKIN_SPLITTER			302									//��ֿؼ�
#define IDC_SYSTEM_TRAY_ICON		303									//����ͼ��
#define IDC_PLAZA_VIEW_GAME_KIND	304									//���Ϳؼ�
#define IDC_PLAZA_VIEW_GAME			305									//��Ϸ��ͼ
#define IDC_PLAZA_GAME_CONTAINER	306									//��Ϸ����
#define IDC_PLAZA_SERVER_CONTAINER	307									//��������

//�ؼ���ʶ
#define IDC_PLAZA_VIEW_TOP_BAR		310									//��������
#define IDC_PLAZA_VIEW_USER_INFO	311									//�û���Ϣ
#define IDC_PLAZA_VIEW_SERVER_CTRL	312									//�������	


//-----------------------------------------------
//������Ŀ
#define MAX_SERVER_COUNT			5									//������Ŀ

//ʱ���ʶ
#define IDI_FLASH_TRAY_ICON			10									//����ͼ��

//ʱ���ʶ
#define IDI_UPDATA_ONLINE			16									//��������
#define TIME_UPDATA_ONLINE			10000								//��������

//////////////////////////////////////////////////////////////////////////////////
//��Ϣ����
#define WM_TASK_BAR					0x0313								//�������Ҽ�
#define WM_INSTALL_CANCEL_EVENT		8888								//ȡ����װ

//////////////////////////////////////////////////////////////////////////////////

//�ؼ�����

//��ť�ؼ�
const TCHAR* const szButtonCloseControlName		= TEXT("ButtonClose");
const TCHAR* const szButtonResoreControlName	= TEXT("ButtonResore");
const TCHAR* const szButtonMaxControlName		= TEXT("ButtonMax");
const TCHAR* const szButtonMinControlName		= TEXT("ButtonMin");
 

//-----------------------------------------------
//��̬����

CPlatformFrame * CPlatformFrame::m_pPlatformFrame=NULL;					//���ָ��


BEGIN_MESSAGE_MAP(CPlatformFrame, CFGuiFrameWnd)

	//ϵͳ��Ϣ
	ON_WM_SIZE()
	ON_WM_CLOSE()
	ON_WM_TIMER()
	ON_WM_CREATE()
	ON_WM_LBUTTONDBLCLK()
	ON_WM_GETMINMAXINFO()
	ON_WM_SETTINGCHANGE()

	//�Զ���Ϣ
	ON_MESSAGE(WM_HOTKEY, OnMessageHotKey)
	ON_MESSAGE(WM_TASK_BAR, OnMessageTaskBar)	
	ON_MESSAGE(WM_TRAY_ICON, OnMessageTrayIcon)
	ON_MESSAGE(WM_PLATFORM_EVENT, OnMessagePlatformEvent)
	ON_MESSAGE(WM_INSTALL_CANCEL_EVENT, OnMessageInstallCancelEvent)

	//�Զ���Ϣ
	ON_MESSAGE(WM_INSUREPLAZA_EVENT, OnMessageInsurePlazaEvent)

END_MESSAGE_MAP()


//-----------------------------------------------
//���캯��
CListEncircle::CListEncircle()
{
}

//��������
CListEncircle::~CListEncircle()
{
}

//�滭����
bool CListEncircle::PreDrawEncircleImage(tagEncircleBMP & EncircleImage)
{
	//��������
	CDC * pDCL=CDC::FromHandle(EncircleImage.ImageTL.GetDC());
	CDC * pDCM=CDC::FromHandle(EncircleImage.ImageTM.GetDC());
	CDC * pDCR=CDC::FromHandle(EncircleImage.ImageTR.GetDC());

	//������Դ
	CPngImage ListTitleL;
	CPngImage ListTitleM;
	CPngImage ListTitleR;
	ListTitleL.LoadImage(AfxGetInstanceHandle(),TEXT("LIST_TITLE_L"));
	ListTitleM.LoadImage(AfxGetInstanceHandle(),TEXT("LIST_TITLE_M"));
	ListTitleR.LoadImage(AfxGetInstanceHandle(),TEXT("LIST_TITLE_R"));

	//������Դ
	ListTitleL.DrawImage(pDCL,0,0);
	ListTitleM.DrawImage(pDCM,0,0);
	ListTitleR.DrawImage(pDCR,0,0);

	//�ͷ���Դ
	EncircleImage.ImageTL.ReleaseDC();
	EncircleImage.ImageTM.ReleaseDC();
	EncircleImage.ImageTR.ReleaseDC();

	return true;
}


//-----------------------------------------------
//���캯��
CFrameEncircle::CFrameEncircle()
{
}

//��������
CFrameEncircle::~CFrameEncircle()
{
}

//�滭����
bool CFrameEncircle::PreDrawEncircleImage(tagEncircleBMP & EncircleImage)
{
	//��������
	CDC * pDC=CDC::FromHandle(EncircleImage.ImageTL.GetDC());

	//������Դ
	CPngImage StationLogo;
	StationLogo.LoadImage(GetModuleHandle(PLATFORM_RESOURCE_DLL_NAME),TEXT("PLATFORM_LOGO"));

	//�����־
	StationLogo.DrawImage(pDC,6,1);
	EncircleImage.ImageTL.ReleaseDC();

	return true;
}


//-----------------------------------------------
//���캯��
CPlatformFrame::CPlatformFrame()
{
	//�������
	m_bMaxShow=false;
	m_bRectify=false;
	m_rcNormalSize.SetRect(0,0,0,0);

	//״̬����
	m_bWhisperIcon=false;
	m_bAutoMenuEnable=FALSE;

	//�������
	m_MissionManager.InsertMissionItem(&m_MissionList);
	m_MissionManager.InsertMissionItem(&m_MissionLogon);

	//ƽ̨����
	ASSERT(m_pPlatformFrame==NULL);
	if (m_pPlatformFrame==NULL) m_pPlatformFrame=this;

	//���ýӿ�
	CCustomFaceManager * pCustomFaceManager=CCustomFaceManager::GetInstance();
	pCustomFaceManager->SetCustomFaceEvent(QUERY_OBJECT_PTR_INTERFACE(this,IUnknownEx));

	//��ܻ���
	tagEncircleResource	EncircleRes;
	EncircleRes.pszImageTL	= MAKEINTRESOURCE(IDB_FRAME_TL);
	EncircleRes.pszImageTM	= MAKEINTRESOURCE(IDB_FRAME_TM);
	EncircleRes.pszImageTR	= MAKEINTRESOURCE(IDB_FRAME_TR);
	EncircleRes.pszImageML	= MAKEINTRESOURCE(IDB_FRAME_ML);
	EncircleRes.pszImageMR	= MAKEINTRESOURCE(IDB_FRAME_MR);
	EncircleRes.pszImageBL	= MAKEINTRESOURCE(IDB_FRAME_BL);
	EncircleRes.pszImageBM	= MAKEINTRESOURCE(IDB_FRAME_BM);
	EncircleRes.pszImageBR	= MAKEINTRESOURCE(IDB_FRAME_BR);
	m_FrameEncircleRes.InitEncircleResource(EncircleRes,AfxGetInstanceHandle());

	m_wAVServerPort=0;
	m_dwAVServerAddr=0;


	return;
}

//��������
CPlatformFrame::~CPlatformFrame()
{
	//ƽ̨����
	ASSERT(m_pPlatformFrame==this);
	if (m_pPlatformFrame==this) m_pPlatformFrame=NULL;

	//�ͷ���Դ
	if(m_pDlgTaskNotify!=NULL) SafeDelete(m_pDlgTaskNotify);

	return;
}

//�ӿڲ�ѯ
VOID * CPlatformFrame::QueryInterface(REFGUID Guid, DWORD dwQueryVer)
{
	QUERYINTERFACE(ICustomFaceEvent,Guid,dwQueryVer);
	QUERYINTERFACE_IUNKNOWNEX(ICustomFaceEvent,Guid,dwQueryVer);
	return NULL;
}

//����ʧ��
VOID CPlatformFrame::OnEventSystemFace(DWORD dwUserID, WORD wFaceID)
{
	//��������
	CGlobalUserInfo * pGlobalUserInfo=CGlobalUserInfo::GetInstance();
	tagGlobalUserData * pGlobalUserData=pGlobalUserInfo->GetGlobalUserData();

	//��������
	if (pGlobalUserData->dwUserID==dwUserID)
	{
		//���ñ���
		pGlobalUserData->wFaceID=wFaceID;

		//��������
		pGlobalUserData->dwCustomID=0L;
		ZeroMemory(&pGlobalUserData->CustomFaceInfo,sizeof(pGlobalUserData->CustomFaceInfo));

		//�����¼�
		CPlatformEvent * pPlatformEvent=CPlatformEvent::GetInstance();
		if (pPlatformEvent!=NULL) pPlatformEvent->SendPlatformEvent(EVENT_USER_INFO_UPDATE,0L);
	}

	return;
}

//ͷ������
VOID CPlatformFrame::OnEventCustomFace(DWORD dwUserID, DWORD dwCustomID, tagCustomFaceInfo & CustomFaceInfo)
{
	//��������
	CGlobalUserInfo * pGlobalUserInfo=CGlobalUserInfo::GetInstance();
	tagGlobalUserData * pGlobalUserData=pGlobalUserInfo->GetGlobalUserData();

	//��������
	if (pGlobalUserData->dwUserID==dwUserID)
	{
		//���ñ���
		pGlobalUserData->dwCustomID=dwCustomID;
		CopyMemory(&pGlobalUserData->CustomFaceInfo,&CustomFaceInfo,sizeof(CustomFaceInfo));

		//�����¼�
		CPlatformEvent * pPlatformEvent=CPlatformEvent::GetInstance();
		if (pPlatformEvent!=NULL) pPlatformEvent->SendPlatformEvent(EVENT_USER_INFO_UPDATE,0L);
	}

	//��ǰ����
	if (m_PlazaViewServer.m_hWnd!=NULL)
	{
		m_PlazaViewServer.UpdateUserCustomFace(dwUserID,dwCustomID,CustomFaceInfo);
	}

	return;
}


//��ȡ֪ͨ
VOID CPlatformFrame::OnGameItemFinish()
{
	//m_PlazaViewGame.ShowWindow(true);
	//��ʾ�б�
	//m_PlazaViewGame.ShowKindItemView(122,FALSE);



	return;
}
/*
//���֪ͨ
VOID CPlatformFrame::OnGameMatchFinish()
{
	//��ʾ����
	if(m_PlazaViewGame.GetShowItemMode()==VIEW_MODE_MATCH)
	{
		m_PlazaViewGame.ShowMatchItemView(FALSE);
	}

	return;
}
*/
//��ȡ֪ͨ
VOID CPlatformFrame::OnGameKindFinish(WORD wKindID)
{
	//��ʾ����
	if(wKindID!=INVALID_WORD)
	{
		//m_PlazaViewGame.ShowServerItemView(wKindID,TRUE,false);

	}

	return;
}

//����֪ͨ
VOID CPlatformFrame::OnGameItemInsert(CGameListItem * pGameListItem)
{
	//Ч�����
	ASSERT(pGameListItem!=NULL);
	if (pGameListItem==NULL) return;

	//����ʱ��
	pGameListItem->m_dwUpdateTime=(DWORD)time(NULL);

	//���봦��
	switch (pGameListItem->GetItemGenre())
	{
	case ItemGenre_Type:	//��Ϸ����
		{
			break;
		}
	case ItemGenre_Kind:	//��Ϸ����
		{
			//��������
			//m_PlazaViewGameKind.InsertGameKind((CGameKindItem *)pGameListItem);
			break;
		}
	case ItemGenre_Server:	//��Ϸ����
		{
			break;
		}
	}

	return;
}

//����֪ͨ
VOID CPlatformFrame::OnGameItemUpdate(CGameListItem * pGameListItem)
{
	//����ʱ��
	pGameListItem->m_dwUpdateTime=(DWORD)time(NULL);

	switch(pGameListItem->GetItemGenre())
	{		
	case ItemGenre_Type:	//��������
		{
			break;
		}
	case ItemGenre_Kind:	//��Ϸ����
		{
			//��ȡ����
			CGameKindItem * pGameKindItem = (CGameKindItem *)pGameListItem;
		//	m_PlazaViewGame.UpdateKindViewItem(pGameKindItem->m_GameKind.wKindID);
			m_ServerListView.OnGameItemUpdate(pGameListItem);

			break;
		}
	case ItemGenre_Server:	//��������
		{
			//��ȡ����
			CGameServerItem * pGameServerItem = (CGameServerItem *)pGameListItem;
			//m_PlazaViewGame.UpdateServerViewItem();
			break;
		}
	}

	return;
}

//ɾ��֪ͨ
VOID CPlatformFrame::OnGameItemDelete(CGameListItem * pGameListItem)
{
	return;
}

//��Ϣ����
BOOL CPlatformFrame::PreTranslateMessage(MSG * pMsg)
{
	//��������
	if (pMsg->message==WM_KEYDOWN)
	{
		if(pMsg->wParam==VK_RETURN) return TRUE;
	}

	return __super::PreTranslateMessage(pMsg);
}

//�����
BOOL CPlatformFrame::OnCommand(WPARAM wParam, LPARAM lParam)
{
	//��������
	UINT nCommandID=LOWORD(wParam);

	//�˵�����
	switch (nCommandID)
	{
	case IDM_USER_LOGON:		//�û���¼
		{
			m_MissionLogon.ShowLogon();

			return TRUE;
		}
	case IDM_SWITCH_ACCOUNTS:	//�л��ʺ�
		{
			//�л�ѯ��
			if (m_PlazaViewServer.m_hWnd!=NULL)
			{
				CInformation Information(this);
				if (Information.ShowMessageBox(TEXT("��Ϸ���伴���رգ�ȷ��Ҫ���л��ʺš��� "),MB_YESNO)!=IDYES) return TRUE;
			}

		
			//ȫ������
			CGlobalUnits::GetInstance()->DeleteUserCookie();
			CGlobalUserInfo::GetInstance()->ResetUserInfoData();
			

			//������ͼ
			//m_PlazaViewGameKind.ResetGameKindView();
/*
			//��ȡ����
			CServerListData * pServerListData = CServerListData::GetInstance();

			//�������
			POSITION Position=NULL;
			do
			{
				//��ȡ����
				CGameServerItem * pGameServerItem=pServerListData->EmunGameServerItem(Position);
				if(pGameServerItem!=NULL)
				{
					pGameServerItem->m_bSignuped=false;
					ZeroMemory(&pGameServerItem->m_GameMatch,sizeof(pGameServerItem->m_GameMatch));
				}

			} while (Position!=NULL);
*/


			//�����¼�
			CPlatformEvent * pPlatformEvent=CPlatformEvent::GetInstance();
			if (pPlatformEvent!=NULL) pPlatformEvent->SendPlatformEvent(EVENT_USER_LOGOUT,0L);
			



				//����Ŀ¼
	TCHAR szMouduleFileName[MAX_PATH]=TEXT("");
	CWHService::GetWorkDirectory(szMouduleFileName,CountArray(szMouduleFileName));

	//�����ַ
	TCHAR szMainSetupPath[MAX_PATH]=TEXT("");
	_sntprintf(szMainSetupPath,CountArray(szMainSetupPath),TEXT("%s/GamePlaza.exe"),szMouduleFileName);

	//�رմ���
	AfxGetMainWnd()->PostMessage(WM_CLOSE,0,0);

	//��������
	ShellExecute(0,TEXT("open"),szMainSetupPath,TEXT("UPDATED"),NULL,true );

			return TRUE;
		}
	case IDM_CLOSE:		//�ر�
		{
			//Ͷ����Ϣ
			PostMessage(WM_CLOSE,0,0);

			return TRUE;
		}
	case IDM_RESTORE:   //��ԭ
		{
			if(IsIconic())
			{
				ShowWindow(SW_RESTORE);
			}
			return TRUE;
		}
	case IDM_MINIMIZE:  //��С��
		{
			if(IsWindowVisible())
			{
				ShowWindow(SW_MINIMIZE);
			}
			return TRUE;
		}
	case IDM_MAXIMIZE:  //���
		{
			if(IsIconic())
			{
				ShowWindow(SW_RESTORE);
			}
			MaxSizeWindow();
			return TRUE;
		}
	case IDM_SHOW_LOGON: //��ʾ��¼
		{
			m_MissionLogon.ShowLogon(SW_RESTORE);

			return TRUE;
		}
	}

	return __super::OnCommand(wParam,lParam);
}

//��ʼ�滭
void CPlatformFrame::OnBeginPaintWindow(HDC hDC)
{
	//��������
	CDC * pDC = CDC::FromHandle(hDC);

	//��ȡλ��
	CRect rctClient;
	GetClientRect(&rctClient);

	//���λ��
	tagEncircleInfo FrameEncircleResInfo;
	m_FrameEncircleRes.GetEncircleInfo(FrameEncircleResInfo);

	//�滭���
	m_FrameEncircleRes.DrawEncircleFrame(pDC,rctClient);
	//��䱳��
	//pDC->FillSolidRect(&rctClient,CLR_DEBUG);

	return;
}

//��Ϣ����
void CPlatformFrame::Notify(TNotifyUI &  msg)
{	
	//��ȡ����
	CControlUI * pControlUI = msg.pSender;

	//����¼�
	if (lstrcmp(msg.sType, TEXT("click")) == 0)
	{
		if(lstrcmp(pControlUI->GetName(), szButtonCloseControlName)==0) 
		{
			PostMessage(WM_CLOSE,0,0);
			return;
		}
		else if(lstrcmp(pControlUI->GetName(), szButtonMinControlName)==0)
		{
			ShowWindow(SW_MINIMIZE);
			return;
		}
		else if(lstrcmp(pControlUI->GetName(), szButtonMaxControlName)==0)
		{
			//���ڿ���
			if (m_bMaxShow==false) 
			{
				//��󻯴���
				MaxSizeWindow();				
			}

			//���½���
			RedrawWindow(NULL,NULL,RDW_ERASE|RDW_INVALIDATE|RDW_ERASENOW|RDW_UPDATENOW);

			return;
		}
		else if(lstrcmp(pControlUI->GetName(), szButtonResoreControlName)==0)
		{
			//���ڿ���
			if (m_bMaxShow==true)
			{
				//��ԭ����
				RestoreWindow();

				//���ÿؼ�
				pControlUI->SetVisible(false);
				pControlUI = GetControlByName(szButtonMaxControlName);
				if(pControlUI!=NULL) pControlUI->SetVisible();
			}

			//���½���
			RedrawWindow(NULL,NULL,RDW_ERASE|RDW_INVALIDATE|RDW_ERASENOW|RDW_UPDATENOW);

			return;
		}
	}
}


//�����ؼ�
VOID CPlatformFrame::RectifyControl(INT nWidth, INT nHeight)
{
	//״̬�ж�
	if ((nWidth==0)||(nHeight==0)) return;

	//������Ϣ
	tagEncircleInfo FrameEncircleResInfo;
	m_FrameEncircleRes.GetEncircleInfo(FrameEncircleResInfo);

	//�ƶ�׼��
	HDWP hDwp=BeginDeferWindowPos(32);
	UINT uFlags=SWP_NOACTIVATE|SWP_NOCOPYBITS|SWP_NOZORDER;

/*	//��������
	DeferWindowPos(hDwp,m_PlazaViewContainer,NULL,
						FrameEncircleResInfo.nLBorder,
						FrameEncircleResInfo.nTBorder,
						nWidth-FrameEncircleResInfo.nLBorder-FrameEncircleResInfo.nRBorder,
						nHeight-FrameEncircleResInfo.nTBorder-FrameEncircleResInfo.nBBorder,
						uFlags);
*/
	

	//DeferWindowPos(hDwp,m_PlazaViewGame,NULL,FrameEncircleResInfo.nLBorder+240+1,FrameEncircleResInfo.nTBorder+74,nWidth-FrameEncircleResInfo.nLBorder-FrameEncircleResInfo.nRBorder-240-240+3,nHeight-FrameEncircleResInfo.nTBorder-FrameEncircleResInfo.nBBorder-10,uFlags);//��Ϸ�б�
	DeferWindowPos(hDwp,m_PlazaViewGame,NULL,(nWidth-150)/2,(nHeight-150)/2,250,150,uFlags);//��Ϸ�б�
DeferWindowPos(hDwp,m_PlazaViewTopBar,NULL,0,27,nWidth-FrameEncircleResInfo.nLBorder-FrameEncircleResInfo.nRBorder+3,95,uFlags);//

DeferWindowPos(hDwp,m_PlazaViewUserInfo,NULL,FrameEncircleResInfo.nLBorder,FrameEncircleResInfo.nTBorder+95,300,142+60,uFlags);//


DeferWindowPos(hDwp,m_ServerListView,NULL,FrameEncircleResInfo.nLBorder,FrameEncircleResInfo.nTBorder+95+142+38,300,nHeight-FrameEncircleResInfo.nTBorder-FrameEncircleResInfo.nBBorder-95-180,uFlags);//��Ϸ�б�//ethj




DeferWindowPos(hDwp,m_PlazaViewServer,NULL,FrameEncircleResInfo.nLBorder,FrameEncircleResInfo.nTBorder+95,nWidth-FrameEncircleResInfo.nLBorder-FrameEncircleResInfo.nRBorder-300+1,nHeight-FrameEncircleResInfo.nTBorder-FrameEncircleResInfo.nBBorder-10-80,uFlags);//��Ϸ�б�

	DeferWindowPos(hDwp,m_PlazaViewServerCtrl,NULL,nWidth-300,FrameEncircleResInfo.nTBorder+95,300,nHeight-FrameEncircleResInfo.nTBorder-FrameEncircleResInfo.nBBorder-10-82,uFlags);//��Ϸ�б�


		//m_PlazaViewContainer.InsertViewItem(&m_PlazaViewUserInfo,VIA_Right);	
	//m_PlazaViewContainer.InsertViewItem(&m_PlazaViewTopBar,VIA_Top);	


	DeferWindowPos(hDwp,m_PlatformPublicize,NULL,FrameEncircleResInfo.nLBorder+300+1,FrameEncircleResInfo.nTBorder+95,nWidth-FrameEncircleResInfo.nLBorder-FrameEncircleResInfo.nRBorder-240+3,nHeight-FrameEncircleResInfo.nTBorder-FrameEncircleResInfo.nBBorder-10,uFlags);//��Ϸ�б�




	//��������
	LockWindowUpdate();
	EndDeferWindowPos(hDwp);
	UnlockWindowUpdate();		

	//���½���
	RedrawWindow(NULL,NULL,RDW_ERASE|RDW_INVALIDATE);

	return;
}

//��������
CRect CPlatformFrame::MapSelectedTypeRect()
{
return NULL;
	/*
	//��������
	CRect rcSourceType,rcDestType;

	//��ȡ����
	m_PlazaViewGame.GetWindowRect(&rcDestType);
	rcSourceType = m_PlazaViewGameKind.GetSelectedKindRect();	

	//��������
	rcDestType.left = rcSourceType.left;
	rcDestType.right= rcSourceType.right;
	rcDestType.bottom = rcDestType.top + rcSourceType.Height();

	//ת������
	ScreenToClient(&rcDestType);

	return rcDestType;*/
}

//��������
VOID CPlatformFrame::ShowTaskNotifyer(LPCTSTR pszTaskName)
{
	//�ؼ�����
	if(IsWindow(m_pDlgTaskNotify->m_hWnd)==false)
	{
		m_pDlgTaskNotify->Create(IDD_DLG_TASK,NULL);
	}	

	//����λ��
	CRect rcArce;
	SystemParametersInfo(SPI_GETWORKAREA,0,&rcArce,SPIF_SENDCHANGE);

	//���ô�С
	CRect rcTaskNotify;
	m_pDlgTaskNotify->GetWindowRect(&rcTaskNotify);
	m_pDlgTaskNotify->SetWindowPos(NULL,rcArce.right-rcTaskNotify.Width(),rcArce.bottom-rcTaskNotify.Height(),0,0,SWP_NOZORDER|SWP_NOSIZE|SWP_NOREDRAW);

	//���ô���
	m_pDlgTaskNotify->SetTaskName(pszTaskName);		
	m_pDlgTaskNotify->ShowWindow(SW_SHOWNOACTIVATE);
	//m_pDlgTaskNotify->SetForegroundWindow();

	return;
}

//���ҳ��
bool CPlatformFrame::WebBrowse(LPCTSTR pszURL, bool bAutoFullView)
{
	//���ù��
	m_PlatformPublicize.Navigate(pszURL);
	
	//���ҳ��
	//CPlazaViewGame::GetInstance()->WebBrowse(pszURL);

	//�������
	//m_WndViewItemCtrl.ActiveViewItem(&m_PlazaViewGame);

	//�������
	if (bAutoFullView==true)
	{
		CParameterGlobal * pParameterGlobal=CParameterGlobal::GetInstance();
	//	if (pParameterGlobal->m_bFullScreenBrowse==true) ControlServerList(ServerListControl_Hide,false);
	}

	return true;
}

//��ȡ˽��
bool CPlatformFrame::ShowWhisperItem()
{
	//��ȡ��Ϣ
	if (m_DlgWhisperItemArray.GetCount()>0L)
	{
		//��ȡ����
		CDlgWhisper * pDlgWhisper=m_DlgWhisperItemArray[0];

		//��ʾ����
		pDlgWhisper->ShowWindow(SW_RESTORE);

		//�ö�����
		pDlgWhisper->SetActiveWindow();
		pDlgWhisper->BringWindowToTop();
		pDlgWhisper->SetForegroundWindow();

		//ɾ������
		m_DlgWhisperItemArray.RemoveAt(0L);

		//ɾ��ͼ��
		if (m_DlgWhisperItemArray.GetCount()==0L)
		{
			//���ñ���
			m_bWhisperIcon=false;

			//ɾ��ʱ��
			KillTimer(IDI_FLASH_TRAY_ICON);

			//����ͼ��
			m_SystemTrayIcon.ShowTrayIcon(LoadIcon(AfxGetInstanceHandle(),MAKEINTRESOURCE(IDR_MAINFRAME)));
		}

		return true;
	}

	return false;
}

//����˽��
bool CPlatformFrame::InsertWhisperItem(CDlgWhisper * pDlgWhisper)
{
	//����Ч��
	ASSERT((pDlgWhisper!=NULL)&&(pDlgWhisper->m_hWnd!=NULL));
	if ((pDlgWhisper==NULL)||(pDlgWhisper->m_hWnd==NULL)) return false;

	//״̬�ж�
	if (pDlgWhisper->IsWindowVisible()) return false;

	//��������
	for (INT_PTR i=0;i<m_DlgWhisperItemArray.GetCount();i++)
	{
		if (m_DlgWhisperItemArray[i]==pDlgWhisper) return false;
	}

	//����˽��
	m_DlgWhisperItemArray.Add(pDlgWhisper);

	//����ͼ��
	if (m_DlgWhisperItemArray.GetCount()==1L)
	{
		//���ñ���
		m_bWhisperIcon=true;

		//����ʱ��
		SetTimer(IDI_FLASH_TRAY_ICON,500,NULL);

		//����ͼ��
		m_SystemTrayIcon.ShowTrayIcon(LoadIcon(AfxGetInstanceHandle(),MAKEINTRESOURCE(IDI_WHISPER)));
	}

	return true;
}

//ɾ��˽��
bool CPlatformFrame::RemoveWhisperItem(CDlgWhisper * pDlgWhisper)
{
	//��������
	for (INT_PTR i=0;i<m_DlgWhisperItemArray.GetCount();i++)
	{
		if (m_DlgWhisperItemArray[i]==pDlgWhisper)
		{
			//ɾ������
			m_DlgWhisperItemArray.RemoveAt(i);

			//ɾ��ͼ��
			if (m_DlgWhisperItemArray.GetCount()==0L)
			{
				//���ñ���
				m_bWhisperIcon=false;

				//ɾ��ʱ��
				KillTimer(IDI_FLASH_TRAY_ICON);

				//����ͼ��
				m_SystemTrayIcon.ShowTrayIcon(LoadIcon(AfxGetInstanceHandle(),MAKEINTRESOURCE(IDR_MAINFRAME)));
			}

			return true;
		}
	}

	return false;
}

//��ʾ�����б�
bool CPlatformFrame::setPlazaViewGame(bool isok)
{
	
	//��ס����
	LockWindowUpdate();
	

	//��������
	CRect rctCreate(0,0,0,0);


m_PlazaViewGame.ShowWindow(isok);

	
	//����λ��
	CRect rctClient;
	GetClientRect(&rctClient);
	RectifyControl(rctClient.Width(),rctClient.Height());
	//��������
	UnlockWindowUpdate();
	return true;
}
//�����
bool CPlatformFrame::ActiveServerViewItem()
{
	CString strLog;

	//��־
	strLog.Format(_T("%s,%d,"), 
				__FUNCTIONW__, __LINE__);
	g_FileLog.Write(strLog);

	//�����ж�
	ASSERT(m_PlazaViewServer.m_hWnd!=NULL);
	if (m_PlazaViewServer.m_hWnd==NULL) return false;

	//��ס����
	LockWindowUpdate();

	//������ͼ
	//m_PlazaViewContainer.RemoveViewItem(VIA_Left);
	//m_PlazaViewContainer.RemoveViewItem(VIA_Center);	
	//m_PlazaViewContainer.RemoveViewItem(VIA_Right);	
//m_PlazaViewContainer.ShowWindow(false);

	
m_ServerListView.ShowWindow(false);
m_PlazaViewGame.ShowWindow(false);
m_PlazaViewUserInfo.ShowWindow(false);
m_PlatformPublicize.ShowWindow(false);
	
	//��������
	CRect rctCreate(0,0,0,0);



m_PlazaViewServer.ShowWindow(true);
m_PlazaViewServerCtrl.ShowWindow(true);

	//m_PlazaViewContainer.InsertViewItem(&m_PlazaViewServer,VIA_Center);	
	//m_PlazaViewContainer.InsertViewItem(&m_PlazaViewServerCtrl,VIA_Right);		


	//����λ��
	CRect rctClient;
	GetClientRect(&rctClient);
	RectifyControl(rctClient.Width(),rctClient.Height());



	//��������
	UnlockWindowUpdate();

	//��������
	//m_PlazaViewContainer.RectifyViewItem();

	return true;
}

//ɾ������
bool CPlatformFrame::DeleteServerViewItem()
{
	//�����ж�
	if (m_PlazaViewServer.m_hWnd==NULL) return false;

	//��ס����
	LockWindowUpdate();

	//���ٷ���
	m_PlazaViewServer.DestroyWindow();	
	m_PlazaViewServerCtrl.DestroyWindow();
	
	m_ServerListView.ShowWindow(true);
//m_PlazaViewGame.ShowWindow(true);
m_PlazaViewUserInfo.ShowWindow(true);
	m_PlatformPublicize.ShowWindow(true);


	/*m_PlazaViewContainer.InsertViewItem(&m_PlazaViewGameKind,VIA_Left);	
	m_PlazaViewContainer.InsertViewItem(&m_PlazaViewUserInfo,VIA_Right);	
	m_PlazaViewContainer.InsertViewItem(&m_PlazaViewTopBar,VIA_Top);	
	m_PlazaViewContainer.InsertViewItem(&m_PlazaViewGame,VIA_Center);

	*/
	//��������
	UnlockWindowUpdate();

	//��������
	//m_PlazaViewContainer.RectifyViewItem();

	//m_ServerListView.ShowWindow(true);

	//���µȼ�
	//m_PlazaViewUserInfo.m_pLevelControl->UpdateGrowLevelInfo();	 

	return true;
}

//���뷿��
bool CPlatformFrame::EntranceServerItem(CGameServerItem * pGameServerItem,bool isok)
{

	
	//Ч�����
	ASSERT(pGameServerItem!=NULL);
	if (pGameServerItem==NULL) return NULL;

	m_pGameServerItem=pGameServerItem;
	//��������
	CGlobalUserInfo * pGlobalUserInfo=CGlobalUserInfo::GetInstance();
	tagGlobalUserData * pGlobalUserData=pGlobalUserInfo->GetGlobalUserData();

	//��¼�ж�
	if (pGlobalUserData->dwUserID==0L) return NULL;

	//��������
	tagGameServer * pGameServer=&pGameServerItem->m_GameServer;
	tagGameKind * pGameKind=&pGameServerItem->m_pGameKindItem->m_GameKind;

	

	
/*
		//������Ϸ
		if (pGameServerItem->m_pGameKindItem->m_dwProcessVersion==0L)
		{
			CGlobalUnits * pCGlobalUnits=CGlobalUnits::GetInstance();
			pCGlobalUnits->DownLoadClient(pGameKind->szKindName,pGameKind->wKindID,pGameServer->wServerID);

			return NULL;
		}

	*/



	
	//��װ�ж�
	//if (pGameServerItem->m_pGameKindItem->m_dwProcessVersion==0L)
	if (isok==false)
	{
		

//ethj��û�а�װ��Ӧ���µ�һ����Ϸ�б�������ȥ�Զ����º�����
		//��ʾ��ͼ
		m_PlazaViewGame.ShowWindow(true);
		CGlobalUnits::GetInstance()->SetTrackServerID(pGameServerItem->m_GameServer.wServerID);
			m_PlazaViewGame.ShowServerItemView(pGameKind->wKindID,false,false);
			//m_PlazaViewGame.UpdateKindViewItem(pGameKind->wKindID);
			
			//��ȡ�汾
		CGameKindItem * pGameKindItem=pGameServerItem->m_pGameKindItem;
		CWHService::GetModuleVersion(pGameKind->szProcessName,pGameKindItem->m_dwProcessVersion);

if (pGameServerItem->m_pGameKindItem->m_dwProcessVersion==0L)
{
//��������
				//CMissionList * pMissionList=CMissionList::GetInstance();
				//if (pMissionList!=NULL) pMissionList->UpdateServerInfo(pGameKind->wKindID);

return NULL;

}

if (isok==false)return NULL;

//AfxMessageBox(_T("CPlatformFrame::EntranceServerItem1.0"));
//��ǰ�ж�
	if (m_PlazaViewServer.m_hWnd!=NULL)
	{
		//��ʾ��Ϣ
		TCHAR szBuffer[256]=TEXT("");
		_sntprintf(szBuffer,CountArray(szBuffer),TEXT("���ڽ��� [ %s ] ��Ϸ�����У����Ժ�ȴ�Ƭ��..."),m_PlazaViewServer.GetServerName());

		//��ʾ��Ϣ
		CInformation Information(this);
		Information.ShowMessageBox(szBuffer,MB_OK|MB_ICONWARNING,30);
m_PlazaViewGame.ShowWindow(false);
m_pGameServerItem=NULL;
		return true;
	}





/*

		//������Ϸ
		if (pGameServerItem->m_pGameKindItem->m_dwProcessVersion==0L)
		{
			CGlobalUnits * pCGlobalUnits=CGlobalUnits::GetInstance();
			pCGlobalUnits->DownLoadClient(pGameKind->szKindName,pGameKind->wKindID,pGameServer->wServerID);

			return NULL;
		}*/

		//�����б�
		//OnGameItemUpdate(pGameKindItem);

//�����б�
		m_ServerListView.OnGameItemUpdate(pGameKindItem);
	}

	//��������
	try
	{
		//���÷���
		m_PlazaViewServer.Create(IDD_DLG_CHILD,this);
		m_PlazaViewServer.InitServerViewItem(pGameServerItem,m_wAVServerPort,m_dwAVServerAddr);

		//���ÿؼ�
		m_PlazaViewServerCtrl.Create(IDD_GAME_RIGHT_CONTROL,this);

		m_PlazaViewGame.ShowWindow(false);
		m_pGameServerItem=NULL;
	}
	catch (LPCTSTR pszString)
	{
		//���ٴ���
		if(m_PlazaViewServer.m_hWnd) m_PlazaViewServer.DestroyWindow();
		if(m_PlazaViewServerCtrl.m_hWnd) m_PlazaViewServerCtrl.DestroyWindow();

		//��ʾ��Ϣ
		CInformation Information(this);
		Information.ShowMessageBox(pGameServer->szServerName,pszString,MB_ICONERROR);

		return false;
	}

	return true;
}

//��ԭ����
bool CPlatformFrame::RestoreWindow()
{
	//״̬�ж�
	if (m_bMaxShow==true)
	{
		//���ñ���
		m_bMaxShow=false;
		m_bRectify=false;

		//��󻯰�ť
		CControlUI * pControlUI = GetControlByName(szButtonResoreControlName); 
		if(pControlUI!=NULL) pControlUI->SetVisible(false);

		//��ԭ��ť
		pControlUI = GetControlByName(szButtonMaxControlName);
		if(pControlUI!=NULL) pControlUI->SetVisible();

		//�ƶ�����
		LockWindowUpdate();
		SetWindowPos(NULL,m_rcNormalSize.left,m_rcNormalSize.top,m_rcNormalSize.Width(),m_rcNormalSize.Height(),SWP_NOZORDER);
		UnlockWindowUpdate();
	}

	return true;
}

//��󴰿�
bool CPlatformFrame::MaxSizeWindow(bool bRecordPosition)
{
	//״̬�ж�
	if (m_bMaxShow==false)
	{
		//���ñ���
		m_bMaxShow=true;
		m_bRectify=false;

		//Ĭ��λ��
		if(bRecordPosition==true) GetWindowRect(&m_rcNormalSize);

		//��󻯰�ť
		CControlUI * pControlUI = GetControlByName(szButtonMaxControlName); 
		if(pControlUI!=NULL) pControlUI->SetVisible(false);

		//��ԭ��ť
		pControlUI = GetControlByName(szButtonResoreControlName);
		if(pControlUI!=NULL) pControlUI->SetVisible();

		//��ȡλ��
		CRect rcArce;
		SystemParametersInfo(SPI_GETWORKAREA,0,&rcArce,SPIF_SENDCHANGE);

		//�ƶ�����
		LockWindowUpdate();
		SetWindowPos(NULL,rcArce.left-2,rcArce.top-2,rcArce.Width()+4,rcArce.Height()+4,SWP_NOZORDER);
		UnlockWindowUpdate();
	}

	return true;
}

//�ر���Ϣ
VOID CPlatformFrame::OnClose()
{
	//��������
	CGlobalUserInfo * pGlobalUserInfo=CGlobalUserInfo::GetInstance();
	tagGlobalUserData * pGlobalUserData=pGlobalUserInfo->GetGlobalUserData();

	//�ر���ʾ
	if ((pGlobalUserData->dwUserID!=0L)&&(m_MissionLogon.GetActiveStatus()==false))
	{
		//��ʾ����
		CDlgEnquire DlgEnquire;
		INT_PTR nResult=DlgEnquire.DoModal();

		//�����
		switch (nResult)
		{
		case IDCANCEL:				//ȡ������
			{
				return;
			}
		case IDC_CLOSE_SERVER:		//�˳�����
			{
				//�رշ���
				if(m_PlazaViewServer.m_hWnd!=NULL)
				{
					m_PlazaViewServer.SendMessage(WM_COMMAND,IDM_DELETE_SERVER_ITEM,0L);
				}

				return;
			}
		case IDC_SWITCH_ACCOUNTS:	//�л��ʺ�
			{
				//Ͷ����Ϣ
				PostMessage(WM_COMMAND,IDM_SWITCH_ACCOUNTS,0);

				return;
			}
		}
	}

	//ע���ȼ�
	UnregisterHotKey(m_hWnd,IDI_HOT_KEY_BOSS);
	UnregisterHotKey(m_hWnd,IDI_HOT_KEY_WHISPER);

	__super::OnClose();
}

//ʱ����Ϣ
VOID CPlatformFrame::OnTimer(UINT_PTR nIDEvent)
{
	switch (nIDEvent)
	{
	case IDI_FLASH_TRAY_ICON:	//����ͼ��
		{
			//���ñ���
			m_bWhisperIcon=!m_bWhisperIcon;

			//����ͼ��
			UINT uIconID=(m_bWhisperIcon==true)?IDI_WHISPER:IDI_NULL;
			m_SystemTrayIcon.ShowTrayIcon(LoadIcon(AfxGetInstanceHandle(),MAKEINTRESOURCE(uIconID)));

			return;
		}
	}

	__super::OnTimer(nIDEvent);
}

//λ����Ϣ
VOID CPlatformFrame::OnSize(UINT nType, INT cx, INT cy) 
{
	__super::OnSize(nType, cx, cy);

	//�����ؼ�
	RectifyControl(cx,cy);

	return;
}

//λ����Ϣ
VOID CPlatformFrame::OnGetMinMaxInfo(MINMAXINFO * lpMMI)
{
	__super::OnGetMinMaxInfo(lpMMI);

	//����λ��
	CRect rcArce;
	SystemParametersInfo(SPI_GETWORKAREA,0,&rcArce,SPIF_SENDCHANGE);

	//����λ��
	lpMMI->ptMinTrackSize.x=__min(LESS_SCREEN_CX,rcArce.Width());
	lpMMI->ptMinTrackSize.y=__min(LESS_SCREEN_CY,rcArce.Height());

	return;
}

//������Ϣ
INT CPlatformFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (__super::OnCreate(lpCreateStruct)==-1) return -1;

	//���ô���
	ModifyStyle(WS_CAPTION|WS_BORDER, WS_MINIMIZEBOX|WS_MAXIMIZEBOX);
	ModifyStyleEx(WS_EX_CLIENTEDGE|WS_EX_WINDOWEDGE,0,0);	

	//��������
	CRect rctCreate(0,0,0,0);

	//��������
	//m_PlazaViewContainer.Create(NULL,NULL,WS_VISIBLE|WS_CHILD|WS_CLIPCHILDREN,rctCreate,this,IDC_PLAZA_GAME_CONTAINER);

	//��ͼ�ؼ�	
	m_PlazaViewGame.Create(NULL,NULL,WS_VISIBLE|WS_CHILD|WS_CLIPCHILDREN,rctCreate,this,IDC_PLAZA_VIEW_GAME);
	//m_PlazaViewGameKind.Create(NULL,NULL,WS_VISIBLE|WS_CHILD|WS_CLIPCHILDREN,rctCreate,this,IDC_PLAZA_VIEW_GAME_KIND);
	m_PlazaViewUserInfo.Create(NULL,NULL,WS_VISIBLE|WS_CHILD|WS_CLIPCHILDREN,rctCreate,this,IDC_PLAZA_VIEW_USER_INFO);
	m_PlazaViewTopBar.Create(NULL,NULL,WS_VISIBLE|WS_CHILD|WS_CLIPCHILDREN,rctCreate,this,IDC_PLAZA_VIEW_TOP_BAR);

	m_ServerListView.Create(WS_CHILD|WS_VISIBLE,rctCreate,this,IDC_SERVER_LIST);
//m_PlazaViewGameKind.Create(WS_VISIBLE|WS_CHILD|WS_CLIPCHILDREN,rctCreate,this,IDC_PLAZA_VIEW_GAME_KIND);
	//��Ϸ��ͼ
//	m_PlazaViewContainer.InsertViewItem(&m_PlazaViewGameKind,VIA_Left);	
	
	//m_PlazaViewContainer.InsertViewItem(&m_PlazaViewUserInfo,VIA_Right);	
   // m_PlazaViewContainer.InsertViewItem(&m_PlazaViewTopBar,VIA_Top);	
  //  m_PlazaViewContainer.InsertViewItem(&m_PlazaViewGame,VIA_Center);

//	m_PlazaViewContainer.ShowWindow(true);

	m_PlazaViewGame.ShowWindow(false);
	//�����ؼ�
	m_pDlgTaskNotify = new CDlgTaskNotifyer();

	//��Ϸ�б�
	//CServerListData::GetInstance()->SetServerListDataSink(this);

	//ע���¼�
	CPlatformEvent * pPlatformEvent=CPlatformEvent::GetInstance();
	if (pPlatformEvent!=NULL) pPlatformEvent->RegisterEventWnd(m_hWnd);

	//����λ��
	CSize SizeRestrict;
	SizeRestrict.SetSize(LESS_SCREEN_CX,LESS_SCREEN_CY);

	//����λ��
	CRect rcArce;
	SystemParametersInfo(SPI_GETWORKAREA,0,&rcArce,SPIF_SENDCHANGE);

	//��ȡλ��
	CWHRegKey InfoKeyItem;
	if (InfoKeyItem.OpenRegKey(REG_INTERFACE_INFO,false)==true)
	{
		SizeRestrict.cx=InfoKeyItem.GetValue(TEXT("ScreenWidth"),rcArce.Width()/2);
		SizeRestrict.cy=InfoKeyItem.GetValue(TEXT("ScreenHeight"),rcArce.Height()/2);
	}

	//λ�õ���
	SizeRestrict.cx=__max(LESS_SCREEN_CX,SizeRestrict.cx);
	SizeRestrict.cy=__max(LESS_SCREEN_CY,SizeRestrict.cy);
	SizeRestrict.cx=__min(rcArce.Width(),SizeRestrict.cx);
	SizeRestrict.cy=__min(rcArce.Height(),SizeRestrict.cy);

	//�ƶ�����
	m_rcNormalSize.top=(rcArce.Height()-SizeRestrict.cy)/2;
	m_rcNormalSize.left=(rcArce.Width()-SizeRestrict.cx)/2;
	m_rcNormalSize.right=m_rcNormalSize.left+SizeRestrict.cx;
	m_rcNormalSize.bottom=m_rcNormalSize.top+SizeRestrict.cy;

	//�ƶ�����
	SetWindowPos(NULL,m_rcNormalSize.left,m_rcNormalSize.top,m_rcNormalSize.Width(),m_rcNormalSize.Height(),SWP_NOZORDER);

	//��ʾ����
	SetWindowRgn(NULL,TRUE);

	//��¼ϵͳ
	PostMessage(WM_COMMAND,IDM_USER_LOGON,0);

	//ע���ȼ�
	CParameterGlobal * pParameterGlobal=CParameterGlobal::GetInstance();
	CWHService::RegisterHotKey(m_hWnd,IDI_HOT_KEY_BOSS,pParameterGlobal->m_wBossHotKey);
	CWHService::RegisterHotKey(m_hWnd,IDI_HOT_KEY_WHISPER,pParameterGlobal->m_wWhisperHotKey);

	//��������
	m_SystemTrayIcon.InitTrayIcon(m_hWnd,IDC_SYSTEM_TRAY_ICON);
	m_SystemTrayIcon.ShowTrayIcon(LoadIcon(AfxGetInstanceHandle(),MAKEINTRESOURCE(IDR_MAINFRAME)),szProduct);

	//��������
	SetTimer(IDI_UPDATA_ONLINE, TIME_UPDATA_ONLINE, NULL);

	//��������
	CSkinDialog::SetWndFont(this,NULL);


	//��Ϸ�б�
	m_ServerListView.InitServerTreeView();
	CServerListData::GetInstance()->SetServerListDataSink(&m_ServerListView);


	//���ؼ�
//	CRect rctCreate(0,0,0,0);
	m_PlatformPublicize.Create(NULL,NULL,WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN,rctCreate,this,IDC_WEB_PUBLICIZE);


	//��ȡ����
	CGlobalWebLink * pGlobalWebLink=CGlobalWebLink::GetInstance();

	//��ȡ����
	CGlobalUserInfo * pGlobalUserInfo=CGlobalUserInfo::GetInstance();
	tagGlobalUserData * pGlobalUserData=pGlobalUserInfo->GetGlobalUserData();



	//�����ַ
	TCHAR szBillUrl[256]=TEXT("");
	_sntprintf(szBillUrl,CountArray(szBillUrl),TEXT("%s"),pGlobalWebLink->GetPlatformLink());
	m_PlatformPublicize.SetBoradColor(RGB(255,0,0));

	//���ù��
	m_PlatformPublicize.Navigate(szBillUrl);
	m_PlatformPublicize.SetWindowPos(NULL,240,120,488,508,SWP_NOZORDER|SWP_NOCOPYBITS|SWP_NOACTIVATE);


	m_bMaxShow=false;
//��󻯴���
				MaxSizeWindow();	

	return 0;
}

//�����Ϣ
VOID CPlatformFrame::OnLButtonDblClk(UINT nFlags, CPoint Point)
{
	__super::OnLButtonDblClk(nFlags,Point);

	//״̬�ж�
	if (Point.y>GetCaptionRect().Height()) return;

	//���ڿ���
	if (m_bMaxShow==true)
	{
		RestoreWindow();
	}
	else
	{
		MaxSizeWindow();
	}
	
	return;
}

//���øı�
VOID CPlatformFrame::OnSettingChange(UINT uFlags, LPCTSTR lpszSection)
{
	__super::OnSettingChange(uFlags,lpszSection);

	//���ڿ���
	if (m_bMaxShow==true)
	{
		m_bMaxShow=false;
		MaxSizeWindow(false);
	}
	else
	{
		m_bMaxShow=true;
		RestoreWindow();
	}

	return;
}

//�ȼ���Ϣ
LRESULT CPlatformFrame::OnMessageHotKey(WPARAM wParam, LPARAM lParam)
{
	switch (wParam)
	{
	case IDI_HOT_KEY_BOSS:		//�ϰ��ȼ�
		{
			//��������
			CGlobalUserInfo * pGlobalUserInfo=CGlobalUserInfo::GetInstance();
			tagGlobalUserData * pGlobalUserData=pGlobalUserInfo->GetGlobalUserData();

			//��¼�ж�
			if (pGlobalUserData->dwUserID!=0L)
			{
				//��������
				bool bBossCome=(IsWindowVisible()==FALSE)?false:true;

				//���ش���
				if (bBossCome==false)
				{
					//��ԭ����
					ShowWindow(SW_RESTORE);
					ShowWindow(SW_SHOW);

					//�ö�����
					SetActiveWindow();
					BringWindowToTop();
					SetForegroundWindow();

					//��ʾͼ��
					m_SystemTrayIcon.ShowTrayIcon(LoadIcon(AfxGetInstanceHandle(),MAKEINTRESOURCE(IDR_MAINFRAME)));
				}
				else
				{
					//���ش���
					ShowWindow(SW_MINIMIZE);
					ShowWindow(SW_HIDE);

					//����ͼ��
					m_SystemTrayIcon.HideTrayIcon();
				}

				////������Ϣ
				//for (INT_PTR i=0;i<m_PlazaViewServerArray.GetCount();i++)
				//{
				//	ASSERT(m_PlazaViewServerArray[i]!=NULL);
				//	m_PlazaViewServerArray[i]->NotifyBossCome(bBossCome);
				//}
			}

			return 0;
		}
	case IDI_HOT_KEY_WHISPER:	//˽���ȼ�
		{
			//��ȡ��Ϣ
			if (m_DlgWhisperItemArray.GetCount()>0L)
			{
				ShowWhisperItem();
				return 1;
			}

			return 0;
		}
	}

	return 0;
}

//������Ϣ
LRESULT CPlatformFrame::OnMessageTaskBar(WPARAM wParam, LPARAM lParam)
{
	//�����˵�
	CSkinMenu Menu;
	Menu.CreateMenu();

	//����˵�
	Menu.AppendMenu(IDM_RESTORE,TEXT("��ԭ"), (IsIconic()||IsWindowVisible()==FALSE)?MF_ENABLED:MF_GRAYED);
	Menu.AppendMenu(IDM_MINIMIZE,TEXT("��С��"),(IsIconic()==FALSE||IsWindowVisible())?MF_ENABLED:MF_GRAYED);
	Menu.AppendMenu(IDM_MAXIMIZE,TEXT("���"));
	Menu.AppendSeparator();
	Menu.AppendMenu(IDM_CLOSE,TEXT("�˳��㳡"));

	//��ʾ�˵�
	CPoint MousePoint;
	GetCursorPos(&MousePoint);
	Menu.TrackPopupMenu(MousePoint.x,MousePoint.y,this);

	return 0L;
}

//ͼ����Ϣ
LRESULT CPlatformFrame::OnMessageTrayIcon(WPARAM wParam, LPARAM lParam)
{
	//�¼�����
	switch (lParam)
	{
	case WM_LBUTTONDOWN:		//��굥��
		{
			if(IsIconic())
			{
				ShowWindow(SW_RESTORE);
			}

			//�����
			SetActiveWindow();
			BringWindowToTop();
			SetForegroundWindow();

			return 1;
		}
	case WM_LBUTTONDBLCLK:		//���˫��
		{
			//��ȡ��Ϣ
			if (m_DlgWhisperItemArray.GetCount()>0L)
			{
				ShowWhisperItem();
				return 1;
			}			

			return 1;
		}
	case WM_RBUTTONDOWN:		//��굥��
	case WM_RBUTTONDBLCLK:		//���˫��
		{
			//�����˵�
			CSkinMenu Menu;
			Menu.CreateMenu();

			//��������
			CGlobalUserInfo * pGlobalUserInfo=CGlobalUserInfo::GetInstance();
			tagGlobalUserData * pGlobalUserData=pGlobalUserInfo->GetGlobalUserData();

			//�û�δ��½
			if(pGlobalUserData->dwUserID == 0)
			{
				Menu.AppendMenu(IDM_SHOW_LOGON, TEXT("��ʾ�����"), MF_ENABLED);
				Menu.AppendMenu(IDM_CLOSE, TEXT("�˳��㳡"), MF_ENABLED);
			}
			else
			{
				//����˵�
				Menu.AppendMenu(IDM_RESTORE,TEXT("��ԭ"), (IsIconic()||IsWindowVisible()==FALSE)?MF_ENABLED:MF_GRAYED);
				Menu.AppendMenu(IDM_MINIMIZE,TEXT("��С��"),(IsIconic()==FALSE||IsWindowVisible())?MF_ENABLED:MF_GRAYED);
				Menu.AppendMenu(IDM_MAXIMIZE,TEXT("���"));
				Menu.AppendSeparator();
				Menu.AppendMenu(IDM_CLOSE,TEXT("�˳��㳡"));
			}			
			
			//Menu.AppendMenu(IDM_NULL_COMMAND,TEXT("����..."));

			//��ʾ�˵�
			CPoint MousePoint;
			GetCursorPos(&MousePoint);
			Menu.TrackPopupMenu(MousePoint.x,MousePoint.y,this);

			return 1;
		}
	}

	return 0;
}

//�¼���Ϣ
LRESULT CPlatformFrame::OnMessagePlatformEvent(WPARAM wParam, LPARAM lParam)
{
	CString strLog;

	//�¼�����
	switch (wParam)
	{
	case EVENT_USER_LOGON:			//��¼���
		{
			//��ʾ����
			ShowWindow(SW_SHOW);
			SetForegroundWindow();

			//�û����
			ASSERT(CGlobalUnits::GetInstance()!=NULL);
			CGlobalUnits::GetInstance()->WriteUserCookie();

			//��ѯ�ȼ�
			m_PlazaViewUserInfo.m_pLevelControl->UpdateGrowLevelInfo();		

			//��־
			strLog.Format(_T("%s,%d,"), __FUNCTIONW__, __LINE__);
			g_FileLog.Write(strLog);

			return 0L;
		}
	case EVENT_USER_LOGOUT:			//ע���ɹ�
		{
			//���ش���
			ShowWindow(SW_HIDE);

			//�رշ���			
			if(m_PlazaViewServer.m_hWnd!=NULL)
			{
				m_PlazaViewServer.SendMessage(WM_COMMAND,IDM_DELETE_SERVER_ITEM,0L);
			}

			//��ʾ��¼
			m_MissionLogon.ShowLogon();

			return 0L;
		}
	case EVENT_DOWN_LOAD_FINISH:	//�������
		{
			//��ȡ����
			WORD wKindID=LOWORD(lParam);
			WORD wServerID=HIWORD(lParam);

			//�����б�
			CServerListData * pServerListData=CServerListData::GetInstance();
			if (pServerListData!=NULL) pServerListData->OnEventDownLoadFinish(wKindID);

			//���뷿��
			if ((wKindID!=0)&&(wServerID!=0))
			{
				CGameServerItem * pGameServerItem=m_ServerListData.SearchGameServer(wServerID);
				//if (pGameServerItem!=NULL) EntranceServerItem(pGameServerItem,true);
			}

			return 0L;
		}
	case EVENT_USER_SHOW_CHECKIN:	//��ʾǩ��
		{
			ASSERT(CGlobalUnits::GetInstance()!=NULL);
			CGlobalUnits::GetInstance()->PerformShowCheckIn();

			return 0L;
		}
	case EVENT_USER_SHOW_MY_SPREAD:	//��ʾ�ƹ�
		{
			ASSERT(CGlobalUnits::GetInstance()!=NULL);
			CGlobalUnits::GetInstance()->PerformShowMySpread();

			return 0L;
		}
	case EVENT_USER_SHOW_TASKVIEW:	//��ʾ����
		{
			ASSERT(CGlobalUnits::GetInstance()!=NULL);
			CGlobalUnits::GetInstance()->PerformShowTaskView();

			return 0L;
		}
	case EVENT_USER_TRACK_ACCOUNTS:	//׷�ٶ���
		{
			//��ȡ����
			tagTrackAccountsInfo * pTrackAccountsInfo= (tagTrackAccountsInfo *)lParam;
			if(pTrackAccountsInfo!=NULL)
			{
				//��ȡ����
				ASSERT(CServerListData::GetInstance());
				CServerListData * pServerListData = CServerListData::GetInstance();
				if(pServerListData!=NULL)
				{
					//���ҷ���
					CGameServerItem * pGameServerItem = pServerListData->SearchGameServer(pTrackAccountsInfo->wServerID);
					if(pGameServerItem!=NULL)
					{
						//���ñ�ʶ
						ASSERT(CGlobalUnits::GetInstance()!=NULL);
						CGlobalUnits::GetInstance()->SetTrackUserID(pTrackAccountsInfo->dwTargetID);
						
						//���뷿��
						EntranceServerItem(pGameServerItem,false);

						return 0L;
					}
				}

				//��������
				CGameKindItem * pGameKindItem = pServerListData->SearchGameKind(pTrackAccountsInfo->wKindID);
                if(pGameKindItem != NULL)
				{
					//���ñ�ʶ
					ASSERT(CGlobalUnits::GetInstance()!=NULL);
					CGlobalUnits::GetInstance()->SetTrackUserID(pTrackAccountsInfo->dwTargetID);
					CGlobalUnits::GetInstance()->SetTrackServerID(pTrackAccountsInfo->wServerID);

					//��������
					tagGameKindInfo GameKindInfo;
					GameKindInfo.pGameKindItem=pGameKindItem;
					m_PlazaViewGame.OnViewPageKindItemClicked(&GameKindInfo);

					return 0L;
				}
			}
			
			//ʧ����ʾ
			CInformation Information;
			Information.ShowMessageBox(TEXT("��ʾ"),TEXT("û���ҵ���������ڵķ��䣡"));

			return 0L;
		}
	}

	return 0L;
}

//�¼���Ϣ
LRESULT CPlatformFrame::OnMessageInstallCancelEvent(WPARAM wParam, LPARAM lParam)
{
	//��ʾ��¼
	m_MissionLogon.ShowLogon();

	return 0L;
}

void CPlatformFrame::SetVideoOption(WORD wAVServerPort, DWORD dwAVServerAddr)
{
	m_wAVServerPort=wAVServerPort;
	m_dwAVServerAddr=dwAVServerAddr;
}

//�¼���Ϣ
LRESULT CPlatformFrame::OnMessageInsurePlazaEvent(WPARAM wParam, LPARAM lParam)
{
	tagInsurePlazaEvent * pInsureEvent = (tagInsurePlazaEvent*)wParam;
	if(pInsureEvent==NULL) return 0L;

	//��������
	if(pInsureEvent->wCommandID==INSURE_COMMAND_UPDATE)
	{
		///��������
		CGlobalUserInfo * pGlobalUserInfo=CGlobalUserInfo::GetInstance();
		tagGlobalUserData * pGlobalUserData=pGlobalUserInfo->GetGlobalUserData();

		//����
		pGlobalUserData->lUserScore = pInsureEvent->lUserScore;
		pGlobalUserData->lUserInsure = pInsureEvent->lUserInsure;

		//������Ϣ
	m_PlazaViewUserInfo.UpdateUserInfo();



	}

	//�һ�����
	if(pInsureEvent->wCommandID==INSURE_COMMAND_EXCHANGE)
	{
		//��ʾ�һ�
		ASSERT(CGlobalUnits::GetInstance());
		CGlobalUnits::GetInstance()->PerformShowExchange();		
	}

	//�ͷŶ���
	if(pInsureEvent->bHeapData==true) SafeDelete(pInsureEvent);

	return 0;
}





//-----------------------------------------------
//					the end
//-----------------------------------------------
