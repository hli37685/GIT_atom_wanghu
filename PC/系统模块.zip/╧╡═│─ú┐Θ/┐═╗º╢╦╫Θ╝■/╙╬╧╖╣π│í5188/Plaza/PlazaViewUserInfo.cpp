#include "Stdafx.h"
#include "..\GamePlaza.h"
#include "..\Dialog\DlgService.h"
#include "DlgCustomFace.h"
#include "PlatformFrame.h"
#include "PlazaViewUserInfo.h"
#include "..\FileIO\MyFileLog.h"
#include "..\Define.h"


//���ư�ť
#define IDC_USER_INFO_EDIT			104									//�༭�ؼ�

//��������
#define POINT_ROUND_CX				5									//Բ���С
#define	IDC_BROWER_CTRL_NOTICE		100								
#define	IDC_BROWER_CTRL_HOT			101


//�ؼ�����

//��ť�ؼ�
const TCHAR* const szButtonUserCenterControlName	= TEXT("ButtonUserCenter");
const TCHAR* const szButtonLockMachineControlName	= TEXT("ButtonLockMachine");
//const TCHAR* const szButtonFindFriendControlName	= TEXT("ButtonFindFriend");
const TCHAR* const szButtonBindWXControlName		= TEXT("ButtonBindWX");
//const TCHAR* const szButtonBaseMoneyControlName		= TEXT("ButtonBaseMoney");
//const TCHAR* const szButtonExchangeControlName		= TEXT("ButtonExchange");


//��ǩ�ؼ�
const TCHAR* const szLabelLevelControlName = TEXT("LabelLevel");

//�ļ��ؼ�
const TCHAR* const szTextNickNameControlName = TEXT("TextNickName");
const TCHAR* const szTextGameIngotControlName = TEXT("TextGameIngot");
const TCHAR* const szTextTextGameIDName = TEXT("TextGameID");
const TCHAR* const szTextGameScoreControlName = TEXT("TextGameScore");

//////////////////////////////////////////////////////////////////////////////////

//��̬����
CStdString  CLevelControl::m_ImageLevelBack=TEXT("file='IMAGE_LEVEL_BACK' restype='PNG'");
CStdString  CLevelControl::m_ImageLevelNumber=TEXT("file='IMAGE_LEVEL_NUMBER' restype='PNG'");


BEGIN_MESSAGE_MAP(CPlazaViewUserInfo, CFGuiWnd)

	//ϵͳ��Ϣ
	ON_WM_SIZE()
	ON_WM_CREATE()
	ON_WM_SETCURSOR()
	ON_WM_LBUTTONUP()
	ON_WM_LBUTTONDOWN()

	//�Զ���Ϣ
	ON_MESSAGE(WM_MOUSELEAVE, OnMouseLeave)
	ON_MESSAGE(WM_PLATFORM_EVENT, OnMessagePlatformEvent)

END_MESSAGE_MAP()



//���캯��
CLevelTipControl::CLevelTipControl()
{
	//���ñ���
	m_pGrowLevelParameter=NULL;
}

//��������
CLevelTipControl::~CLevelTipControl()
{

}

//�滭��Ϣ
VOID CLevelTipControl::OnDrawClientArea(CDC * pDC, INT nWidth, INT nHeight)
{
	//����У��
	if(m_pGrowLevelParameter==NULL) return;

	//��ȡλ��
	CRect rctClient;
	GetClientRect(m_hWnd,&rctClient);

	//���û���
	pDC->SetBkMode(TRANSPARENT);	
	pDC->SelectObject(CSkinResourceManager::GetInstance()->GetDefaultFont());

	//��ȡ����
	CUserItemElement * pUserItemElement = CUserItemElement::GetInstance();

	//��ȡ���
	HINSTANCE hInstance = GetModuleHandle(PLATFORM_RESOURCE_DLL_NAME);

	//��������
	CPngImage ImageXp,ImageGift;
	CPngImage ImageProgressLine;
	CPngImage ImageProgressPoint;
	CPngImage ImageProgressNumber;	

	//������Դ	
	ImageXp.LoadImage(hInstance,TEXT("IMAGE_XP"));
	ImageGift.LoadImage(hInstance,TEXT("IMAGE_GIFT"));

	//������Դ	
	ImageProgressLine.LoadImage(hInstance,TEXT("IMAGE_PROGRESS_LINE"));
	ImageProgressPoint.LoadImage(hInstance,TEXT("IMAGE_PROGRESS_POINT"));	
	ImageProgressNumber.LoadImage(hInstance,TEXT("IMAGE_PROGRESS_NUMBER"));		

	//��ȡ��С
	CSize SizeProgressLine;
	CSize SizeProgressPoint;
	SizeProgressLine.SetSize(ImageProgressLine.GetWidth(),ImageProgressLine.GetHeight()/2);
	SizeProgressPoint.SetSize(ImageProgressPoint.GetWidth(),ImageProgressPoint.GetHeight());

	//�������
	DWORD dwMaxExperience=m_pGrowLevelParameter->dwUpgradeExperience;
	dwMaxExperience=__max(dwMaxExperience,m_pGrowLevelParameter->dwExperience);
	dwMaxExperience=__max(dwMaxExperience,1);

	WORD wProgress = (WORD)((m_pGrowLevelParameter->dwExperience/(double)dwMaxExperience)*100);

	//��������
	CPoint ptLineStart(38,12);

	//���Ʊ�־
	ImageXp.DrawImage(pDC,13,ptLineStart.y+23);
	ImageGift.DrawImage(pDC,12,ptLineStart.y+42);
	pUserItemElement->DrawExperience(pDC,12,ptLineStart.y-5,m_pGrowLevelParameter->dwExperience);

	//�������
	INT nXPoint=SizeProgressLine.cx*wProgress/100L;		
	nXPoint=__max(nXPoint,POINT_ROUND_CX);
	nXPoint=__min(nXPoint,SizeProgressLine.cx-POINT_ROUND_CX);

	//�滭����
	ImageProgressLine.DrawImage(pDC,ptLineStart.x,ptLineStart.y,SizeProgressLine.cx,SizeProgressLine.cy,0,0);
	ImageProgressLine.DrawImage(pDC,ptLineStart.x,ptLineStart.y,nXPoint,SizeProgressLine.cy,0,SizeProgressLine.cy);
	ImageProgressLine.DrawImage(pDC,ptLineStart.x+nXPoint,ptLineStart.y,POINT_ROUND_CX,SizeProgressLine.cy,SizeProgressLine.cx-POINT_ROUND_CX,SizeProgressLine.cy);

	//�滭����
	TCHAR szFormat[16]=TEXT("");
	_sntprintf(szFormat,CountArray(szFormat),TEXT("%s/%d"),TEXT("%d"),dwMaxExperience);
	pUserItemElement->DrawNumber(pDC,&ImageProgressNumber,ptLineStart.x+SizeProgressLine.cx/2,ptLineStart.y+2,TEXT("0123456789/"),m_pGrowLevelParameter->dwExperience,szFormat,DT_CENTER);

	//��������
	CGlobalUserInfo * pGlobalUserInfo=CGlobalUserInfo::GetInstance();
	tagGlobalUserData * pGlobalUserData=pGlobalUserInfo->GetGlobalUserData();

	//������ʾ
	TCHAR szDescribe[128]=TEXT("");
	INT nNeedExperience = dwMaxExperience-m_pGrowLevelParameter->dwExperience;
	_sntprintf(szDescribe,CountArray(szDescribe),TEXT("�´��������� %d ����ֵ"),nNeedExperience);

	//��������
	TCHAR szUpgradeReward[128]=TEXT("");
	TCHAR szUpgradeReward1[128]=TEXT("����������");	
	_sntprintf(szUpgradeReward,CountArray(szUpgradeReward),TEXT("%I64d ��Ϸ�� + %I64d Ԫ��"),m_pGrowLevelParameter->lUpgradeRewardGold,m_pGrowLevelParameter->lUpgradeRewardIngot);

	//λ�ö���
	CRect rcDescribe(ptLineStart.x,ptLineStart.y+22,rctClient.Width()-ptLineStart.x,ptLineStart.y+36);
	CRect rcUpgradeReward(ptLineStart.x,ptLineStart.y+44,rctClient.Width()-ptLineStart.x,ptLineStart.y+58);

	//������ɫ
	pDC->SetTextColor(RGB(255,255,102));	
	pDC->DrawText(szDescribe,rcDescribe,DT_LEFT|DT_VCENTER|DT_END_ELLIPSIS|DT_SINGLELINE);
	pDC->DrawText(szUpgradeReward1,rcUpgradeReward,DT_LEFT|DT_VCENTER|DT_END_ELLIPSIS|DT_SINGLELINE);

	//������ɫ	
	pDC->SetTextColor(RGB(255,204,1));
	rcUpgradeReward.OffsetRect(65,0);
	pDC->DrawText(szUpgradeReward,rcUpgradeReward,DT_LEFT|DT_VCENTER|DT_END_ELLIPSIS|DT_SINGLELINE);	
}

//���ò���
VOID CLevelTipControl::SetGrowLevelParameter(tagGrowLevelParameter * pGrowLevelParameter)
{
	m_pGrowLevelParameter = pGrowLevelParameter;
}

//////////////////////////////////////////////////////////////////////////////////

//���캯��
CLevelControl::CLevelControl()
{
	//���ÿؼ�
	m_MissionManager.InsertMissionItem(this);

	//���ñ���
	ZeroMemory(&m_GrowLevelParameter,sizeof(m_GrowLevelParameter));		
}

//��������
CLevelControl::~CLevelControl()
{
}

//�����¼�
bool CLevelControl::OnEventMissionLink(INT nErrorCode)
{
	//�����ж�
	if (nErrorCode!=0L) return true;

	//��������
	ASSERT(GetMissionManager()!=NULL);
	CMissionManager * pMissionManager=GetMissionManager();

	//�û���Ϣ
	CGlobalUserInfo * pGlobalUserInfo=CGlobalUserInfo::GetInstance();
	tagGlobalUserData * pGlobalUserData=pGlobalUserInfo->GetGlobalUserData();

	//��������
	CMD_GP_GrowLevelQueryInfo GrowLevelQueryInfo;
	ZeroMemory(&GrowLevelQueryInfo,sizeof(GrowLevelQueryInfo));

	//��������
	GrowLevelQueryInfo.dwUserID=pGlobalUserData->dwUserID;
	CWHService::GetMachineIDEx(GrowLevelQueryInfo.szMachineID);
	lstrcpyn(GrowLevelQueryInfo.szPassword,pGlobalUserData->szPassword,CountArray(GrowLevelQueryInfo.szPassword));

	//��������
	pMissionManager->SendData(MDM_GP_USER_SERVICE,SUB_GP_GROWLEVEL_QUERY,&GrowLevelQueryInfo,sizeof(GrowLevelQueryInfo));

	return true;
}

//�ر��¼�
bool CLevelControl::OnEventMissionShut(BYTE cbShutReason)
{
	return true;
}

//��ȡ�¼�
bool CLevelControl::OnEventMissionRead(TCP_Command Command, VOID * pData, WORD wDataSize)
{
	//�����
	if (Command.wMainCmdID==MDM_GP_USER_SERVICE)
	{
		switch (Command.wSubCmdID)
		{
		case SUB_GP_GROWLEVEL_PARAMETER:	//�ȼ�����
			{
				//Ч�����
				ASSERT(wDataSize==sizeof(CMD_GP_GrowLevelParameter));				
				if (wDataSize!=sizeof(CMD_GP_GrowLevelParameter)) return false;

                //��ȡ����
				CMD_GP_GrowLevelParameter * pGrowLevelParameter=(CMD_GP_GrowLevelParameter *)pData;

				//���ñ���
				m_GrowLevelParameter.wCurrLevelID=pGrowLevelParameter->wCurrLevelID;				
				m_GrowLevelParameter.dwExperience=pGrowLevelParameter->dwExperience;
				m_GrowLevelParameter.dwUpgradeExperience=pGrowLevelParameter->dwUpgradeExperience;
				m_GrowLevelParameter.lUpgradeRewardGold=pGrowLevelParameter->lUpgradeRewardGold;
				m_GrowLevelParameter.lUpgradeRewardIngot=pGrowLevelParameter->lUpgradeRewardIngot;

				//�ر�����
				CMissionManager * pMissionManager=GetMissionManager();
				if (pMissionManager!=NULL) pMissionManager->ConcludeMissionItem(this,false);

				//���½���
				Invalidate();

				return true;
			}
		case SUB_GP_GROWLEVEL_UPGRADE:		//�ȼ�����
			{
				//��������
				CMD_GP_GrowLevelUpgrade * pGrowLevelUpgrade=(CMD_GP_GrowLevelUpgrade *)pData;

				//Ч������
				ASSERT(wDataSize>=CountStringBuffer(pGrowLevelUpgrade->szNotifyContent));
				if (wDataSize<CountStringBuffer(pGrowLevelUpgrade->szNotifyContent)) return false;

				//��ȡ����
				CGlobalUserInfo * pGlobalUserInfo = CGlobalUserInfo::GetInstance();
				tagGlobalUserData * pGlobalUserData = pGlobalUserInfo->GetGlobalUserData();

				//���²Ƹ�
				pGlobalUserData->lUserScore=pGrowLevelUpgrade->lCurrScore;
				pGlobalUserData->lUserIngot=pGrowLevelUpgrade->lCurrIngot;				

				//��ʾ��Ϣ
				if (pGrowLevelUpgrade->szNotifyContent[0]!=0)
				{
					CInformation Information;
					Information.ShowMessageBox(pGrowLevelUpgrade->szNotifyContent,MB_ICONINFORMATION,60);
				}	

				//�����¼�
				CPlatformEvent * pPlatformEvent=CPlatformEvent::GetInstance();
				if (pPlatformEvent!=NULL) pPlatformEvent->SendPlatformEvent(EVENT_USER_INFO_UPDATE,0L);

				//���½���
				Invalidate();

				return true;
			}
		}
	}

	return true;
}

//����λ��
void CLevelControl::SetPos(RECT rc)
{
	__super::SetPos(rc);
}

//�¼�����
void CLevelControl::DoEvent(TEventUI& event)
{
	/*
	//������  ethj�������ľ�����ʾ
	if( event.Type == UIEVENT_MOUSEENTER ) 
    {
		//��������
		CPoint ptPosition(GetFixedXY());		
		ClientToScreen(m_pManager->GetPaintWindow(),&ptPosition);

		//��������
		CRect rcPosition(ptPosition.x,ptPosition.y,ptPosition.x+GetFixedWidth(),ptPosition.y+GetFixedHeight());
		m_LevelTipControl.RelayShowWindow(ptPosition.x-21,ptPosition.y-86,rcPosition);

        return;
	}
*/
	return __super::DoEvent(event);
}

//�滭����
void CLevelControl::DoPaint(HDC hDC, const RECT& rcPaint)
{ return;
/*

	if( !::IntersectRect(&m_rcPaint, &rcPaint, &m_rcItem) ) return;

	//�滭�ȼ�
	CUserItemElement * pUserItemElement = CUserItemElement::GetInstance();
	pUserItemElement->DrawExperience(CDC::FromHandle(hDC),m_rcItem.left,m_rcItem.top,m_GrowLevelParameter.dwExperience);
	*/
}

//��ʼ�ؼ�
void CLevelControl::InitLevelControl()
{
	//���ÿؼ�
	m_LevelTipControl.SetControlResource(GetModuleHandle(PLATFORM_RESOURCE_DLL_NAME),TEXT("IMAGE_LEVEL_PROGRESS"));
	m_LevelTipControl.SetGrowLevelParameter(&m_GrowLevelParameter);
	m_LevelTipControl.CreateTipControl(252,88,255);	
}

//��ѯ�ȼ�
void CLevelControl::UpdateGrowLevelInfo()
{
	//��ֹ����
	CMissionManager * pMissionManager=GetMissionManager();
	if (GetActiveStatus()==true) pMissionManager->ConcludeMissionItem(this,false);

	//���õ�ַ
	LPCTSTR pszCurrentServer=pMissionManager->GetCurrentServer();
	if ((pszCurrentServer!=NULL)&&(pszCurrentServer[0]!=0)) pMissionManager->SetCustomServer(pszCurrentServer);

	//��������
	pMissionManager->AvtiveMissionItem(this,false);

	return;
}

//���Ը���
void CLevelControl::AttemptUpdateGrowLevel()
{
	//��������
	CGlobalUserInfo * pGlobalUserInfo=CGlobalUserInfo::GetInstance();
	tagGlobalUserData * pGlobalUserData=pGlobalUserInfo->GetGlobalUserData();

	//��ǰ����
	if(pGlobalUserData->dwExperience>=m_GrowLevelParameter.dwUpgradeExperience)
	{
		//���µȼ�
		UpdateGrowLevelInfo();
	}

	return;
}


//-----------------------------------------------
//���캯��
CPlazaViewUserInfo::CPlazaViewUserInfo()
{
	//״̬��־
	m_bClickFace=false;
	m_bMouseEvent=false;

	//������־
	m_bHoverFace=false;

	//����ؼ�
	m_pLevelControl=NULL;

	//��������
	m_rctFaceArea.SetRect(32,65,32+48,65+48);

	//��ܻ���
	tagEncircleResource	EncircleRes;
	EncircleRes.pszImageTL=MAKEINTRESOURCE(IDB_PLAZA_VIEW_USER_INFO_TL);
	EncircleRes.pszImageTM=MAKEINTRESOURCE(IDB_PLAZA_VIEW_USER_INFO_TM);
	EncircleRes.pszImageTR=MAKEINTRESOURCE(IDB_PLAZA_VIEW_USER_INFO_TR);
	EncircleRes.pszImageML=MAKEINTRESOURCE(IDB_PLAZA_VIEW_USER_INFO_ML);
	EncircleRes.pszImageMR=MAKEINTRESOURCE(IDB_PLAZA_VIEW_USER_INFO_MR);
	EncircleRes.pszImageBL=MAKEINTRESOURCE(IDB_PLAZA_VIEW_USER_INFO_BL);
	EncircleRes.pszImageBM=MAKEINTRESOURCE(IDB_PLAZA_VIEW_USER_INFO_BM);
	EncircleRes.pszImageBR=MAKEINTRESOURCE(IDB_PLAZA_VIEW_USER_INFO_BR);
	m_EncircleRes[0].InitEncircleResource(EncircleRes,AfxGetInstanceHandle());

	//��ܻ���
	tagEncircleResource	EncircleResWeb;
	EncircleResWeb.pszImageTL=MAKEINTRESOURCE(IDB_PLAZA_VIEW_USER_INFO_WEB_TL);
	EncircleResWeb.pszImageTM=MAKEINTRESOURCE(IDB_PLAZA_VIEW_USER_INFO_WEB_TM);
	EncircleResWeb.pszImageTR=MAKEINTRESOURCE(IDB_PLAZA_VIEW_USER_INFO_WEB_TR);
	EncircleResWeb.pszImageML=MAKEINTRESOURCE(IDB_PLAZA_VIEW_USER_INFO_WEB_ML);
	EncircleResWeb.pszImageMR=MAKEINTRESOURCE(IDB_PLAZA_VIEW_USER_INFO_WEB_MR);
	EncircleResWeb.pszImageBL=MAKEINTRESOURCE(IDB_PLAZA_VIEW_USER_INFO_WEB_BL);
	EncircleResWeb.pszImageBM=MAKEINTRESOURCE(IDB_PLAZA_VIEW_USER_INFO_WEB_BM);
	EncircleResWeb.pszImageBR=MAKEINTRESOURCE(IDB_PLAZA_VIEW_USER_INFO_WEB_BR);
	m_EncircleRes[1].InitEncircleResource(EncircleResWeb,AfxGetInstanceHandle());

	//�ؼ�����
	//m_pDlgInsurePlaza=NULL;

	return;
}

//��������
CPlazaViewUserInfo::~CPlazaViewUserInfo()
{
}

//��Ϣ����
BOOL CPlazaViewUserInfo::PreTranslateMessage(MSG * pMsg)
{
	return __super::PreTranslateMessage(pMsg);
}

//�����
BOOL CPlazaViewUserInfo::OnCommand(WPARAM wParam, LPARAM lParam)
{
	//��������
	UINT nCommandID=LOWORD(wParam);

	//���ܰ�ť
	/*switch (nCommandID)
	{
	}*/

	return __super::OnCommand(wParam,lParam);
}

//��ʼ�滭
void CPlazaViewUserInfo::OnBeginPaintWindow(HDC hDC)
{
	//׼���豸
	CDC * pDC = CDC::FromHandle(hDC);

	//��ȡλ��
	CRect rctClient;
	GetClientRect(&rctClient);

	//��䱳��
	pDC->FillSolidRect(&rctClient,RGB(20,85,146));
	//pDC->FillSolidRect(&rctClient,CLR_DEBUG);

	//�滭����		
	m_EncircleRes[0].DrawEncircleFrame(pDC,m_rctEncircle[0]);
	m_EncircleRes[1].DrawEncircleFrame(pDC,m_rctEncircle[1]);

	tagEncircleInfo EncircleResInfo;
	m_EncircleRes[0].GetEncircleInfo(EncircleResInfo);

	//��ȡ���
	HINSTANCE hInstance = AfxGetResourceHandle();

	//������Դ
	CBitImage ImageTitleL;
	CBitImage ImageTitleM;
	CBitImage ImageTitleR;
	ImageTitleL.LoadFromResource(hInstance,IDB_USER_INFO_L);
	ImageTitleM.LoadFromResource(hInstance,IDB_USER_INFO_M);
	ImageTitleR.LoadFromResource(hInstance,IDB_USER_INFO_R);

	const int nYPos = -10;
	//�滭����
	ImageTitleL.BitBlt(hDC,EncircleResInfo.nLBorder,EncircleResInfo.nTBorder+nYPos);
	//����м�
	for(INT nXPos=EncircleResInfo.nLBorder+ImageTitleL.GetWidth();
		nXPos<(rctClient.Width()-EncircleResInfo.nRBorder-ImageTitleR.GetWidth());
		nXPos+=ImageTitleM.GetWidth())
	{
		ImageTitleM.BitBlt(hDC,nXPos,EncircleResInfo.nTBorder+nYPos);
	}

	//�滭����
	ImageTitleR.BitBlt(hDC,
					rctClient.Width()-EncircleResInfo.nRBorder-ImageTitleR.GetWidth(),
					EncircleResInfo.nTBorder+nYPos);

	//��ȡ����
	CGlobalUserInfo * pGlobalUserInfo=CGlobalUserInfo::GetInstance();
	tagGlobalUserData * pGlobalUserData=pGlobalUserInfo->GetGlobalUserData();

	//�滭�û�
	if (pGlobalUserData->dwUserID!=0L)
	{
		////�滭�׿�
		//if ((m_bHoverUnderWrite==true)||((m_EditUnderWrite.m_hWnd!=NULL)&&(m_EditUnderWrite.IsWindowVisible()==TRUE)))
		//{
		//	//������Դ
		//	CPngImage ImageUnderWriteL;
		//	CPngImage ImageUnderWriteM;
		//	CPngImage ImageUnderWriteR;
		//	ImageUnderWriteL.LoadImage(AfxGetInstanceHandle(),TEXT("UNDER_WRITE_L"));
		//	ImageUnderWriteM.LoadImage(AfxGetInstanceHandle(),TEXT("UNDER_WRITE_M"));
		//	ImageUnderWriteR.LoadImage(AfxGetInstanceHandle(),TEXT("UNDER_WRITE_R"));

		//	//�滭����
		//	ImageUnderWriteL.DrawImage(pBufferDC,m_rcUnderWrite.left,m_rcUnderWrite.top);
		//	ImageUnderWriteR.DrawImage(pBufferDC,m_rcUnderWrite.right-ImageUnderWriteR.GetWidth(),m_rcUnderWrite.top);

		//	//�滭�м�
		//	INT nXStart=m_rcUnderWrite.left+ImageUnderWriteL.GetWidth();
		//	INT nXTerminate=m_rcUnderWrite.right-ImageUnderWriteR.GetWidth();
		//	for (INT nXPos=nXStart;nXPos<nXTerminate;nXPos+=ImageUnderWriteM.GetWidth())
		//	{
		//		ImageUnderWriteM.DrawImage(pBufferDC,nXPos,m_rcUnderWrite.top,__min(nXTerminate-nXPos,ImageUnderWriteM.GetWidth()),ImageUnderWriteM.GetHeight(),0,0);
		//	}
		//}

		/*//�滭ͷ��//ethjͷ�� �ĳɰ��������ͷ���ж��ַ�ʽ���ֿ�����ͷ������ȥ�ж�����һ����ֱ��д���������򵥵�
		if (pGlobalUserData->CustomFaceInfo.dwDataSize!=0)
		{
			DWORD * pdwCustomFace=pGlobalUserData->CustomFaceInfo.dwCustomFace;
			g_theApp.m_FaceItemControlModule->DrawFaceNormal(pDC,m_rctFaceArea.left,m_rctFaceArea.top,pdwCustomFace);
		}
		else*/

		{
			//g_theApp.m_FaceItemControlModule->DrawFaceNormal(pDC,m_rctFaceArea.left,m_rctFaceArea.top,pGlobalUserData->wFaceID);
            
			WORD wFaceIDtemp=0;
	//�ȼ�����
	static SCORE lLevelScore[]=
	{	0,10000,100000,200000,500000,1000000,2000000,5000000,10000000,	20000000,30000000,50000000,
	};	
	
	//��ȡ�ȼ�	
	for (INT i=0;i<CountArray(lLevelScore);i++)	
	{		
		if (pGlobalUserData->lUserScore>=lLevelScore[i]) 
		{		
			wFaceIDtemp=i;
		}
	}	
if (pGlobalUserData->cbGender==GENDER_FEMALE)
wFaceIDtemp+=12;

			g_theApp.m_FaceItemControlModule->DrawFaceNormal(pDC,m_rctFaceArea.left,m_rctFaceArea.top,wFaceIDtemp);
		}
		/*

		//�滭����
		TCHAR m_strDescribe[64]=TEXT("���з�������Ƽ��������ι�˾");
		CRect rcDescribe;
		rcDescribe.SetRect(800,16,1070,32);
		pDC->SetBkMode(TRANSPARENT);
		pDC->SetTextColor(RGB(100,100,100));
		pDC->DrawText(m_strDescribe,rcDescribe,DT_CENTER|DT_VCENTER|DT_END_ELLIPSIS|DT_SINGLELINE);

		TCHAR m_strDescribe2[64]=TEXT("�����ģ�[2015]0448-168��");
		CRect rcDescribe2;
		rcDescribe2.SetRect(800,36,1070,52);
		pDC->SetBkMode(TRANSPARENT);
		pDC->SetTextColor(RGB(100,100,100));
		pDC->DrawText(m_strDescribe2,rcDescribe2,DT_CENTER|DT_VCENTER|DT_END_ELLIPSIS|DT_SINGLELINE);

		TCHAR m_strDescribe3[64]=TEXT("��ICP��15019667��");
		CRect rcDescribe3;
		rcDescribe3.SetRect(800,56,1070,72);
		pDC->SetBkMode(TRANSPARENT);
		pDC->SetTextColor(RGB(100,100,100));
		pDC->DrawText(m_strDescribe3,rcDescribe3,DT_CENTER|DT_VCENTER|DT_END_ELLIPSIS|DT_SINGLELINE);*/

		////�滭����
		//pBufferDC->SetTextColor(RGB(0,0,0));
		//pBufferDC->TextOut(88,16,TEXT("�� �ƣ�"));
		//pBufferDC->TextOut(88,36,TEXT("�� �ƣ�"));
		//pBufferDC->TextOut(88,56,TEXT("ǩ ����"));

		////���콱��
		//TCHAR szUserMedal[64]=TEXT("");
		//_sntprintf(szUserMedal,CountArray(szUserMedal),TEXT("%ld"),pGlobalUserData->dwUserMedal);

		////�������
		//CRect rcUserMedal;
		//rcUserMedal.SetRect(130,36,rctClient.Width()-15,48);
		//pBufferDC->DrawText(szUserMedal,lstrlen(szUserMedal),&rcUserMedal,DT_SINGLELINE|DT_VCENTER|DT_END_ELLIPSIS);

		////����ʺ�
		//CRect rcNickName;
		//rcNickName.SetRect(130,16,rctClient.Width()-15,28);
		//pBufferDC->DrawText(pGlobalUserData->szNickName,lstrlen(pGlobalUserData->szNickName),&rcNickName,DT_SINGLELINE|DT_VCENTER|DT_END_ELLIPSIS);

		////��������
		//LPCTSTR pszUnderWrite=NULL;
		//COLORREF crUnderWrite=RGB(0,0,0);

		////ǩ��λ��
		//CRect rcUnderWrite;
		//rcUnderWrite.SetRect(130,56,rctClient.Width()-15,68);

		////����״̬
		//if ((m_EditUnderWrite.IsModifyStatus()==false)&&(pGlobalUserData->szUnderWrite[0]!=0))
		//{
		//	crUnderWrite=RGB(0,0,0);
		//	pszUnderWrite=pGlobalUserData->szUnderWrite;
		//}

		////�޸�״̬
		//if ((m_EditUnderWrite.IsModifyStatus()==true)&&(m_EditUnderWrite.m_szUnderWrite[0]!=0))
		//{
		//	crUnderWrite=RGB(100,100,100);
		//	pszUnderWrite=m_EditUnderWrite.m_szUnderWrite;
		//}

		////��ʾ״̬
		//if (pszUnderWrite==NULL)
		//{
		//	crUnderWrite=RGB(150,150,150);
		//	pszUnderWrite=TEXT("�༭����ǩ��");
		//}

		////���ǩ��
		//pBufferDC->SetTextColor(crUnderWrite);
		//pBufferDC->DrawText(pszUnderWrite,lstrlen(pszUnderWrite),&rcUnderWrite,DT_SINGLELINE|DT_VCENTER|DT_END_ELLIPSIS);
	}
}

//��Ϣ����
void CPlazaViewUserInfo::Notify(TNotifyUI &  msg)
{
	//��ȡ����
	CControlUI * pControlUI = msg.pSender;

	//����¼�
	if (lstrcmp(msg.sType, TEXT("click")) == 0)
	{
		if(lstrcmp(pControlUI->GetName(), szButtonUserCenterControlName)==0) 
		{
			//��������
			CDlgService DlgService;
			DlgService.DoModal();

			return;
		}
		else if(lstrcmp(pControlUI->GetName(), szButtonLockMachineControlName)==0)
		{
			ASSERT(CGlobalUnits::GetInstance());
			CGlobalUnits::GetInstance()->PerformShowLockMachine();

			return;
		}
		else if(lstrcmp(pControlUI->GetName(), szButtonBindWXControlName)==0)
		{
			ASSERT(CGlobalUnits::GetInstance());
			CGlobalUnits::GetInstance()->PerformShowBindWX();			

			return;
		}/*
         //�һ�
		else if(lstrcmp(pControlUI->GetName(), szButtonExchangeControlName)==0)
		{
			ASSERT(CGlobalUnits::GetInstance());
			CGlobalUnits::GetInstance()->PerformShowExchange();

			return;
		}
		else if(lstrcmp(pControlUI->GetName(), szButtonFindFriendControlName)==0)
		{
			ASSERT(CGlobalUnits::GetInstance());
			CGlobalUnits::GetInstance()->PerformShowSearchUser();			

			return;
		}
		//��ȡ�ͱ�
		else if(lstrcmp(pControlUI->GetName(), szButtonBaseMoneyControlName)==0) 
		{
			ASSERT(CGlobalUnits::GetInstance());
			CGlobalUnits::GetInstance()->PerformShowBaseEnsure();

			return;
		}*/
		


	}
}

//��ʼ�ؼ�
void CPlazaViewUserInfo::InitControlUI()
{
	//��ȡ����
	CContainerUI * pParent = static_cast<CContainerUI *>(m_PaintManager.GetRoot());

	//�ȼ��ؼ�
	m_pLevelControl = new CLevelControl();
	m_pLevelControl->SetManager(&m_PaintManager,pParent);
	m_pLevelControl->SetFloat(true);
	m_pLevelControl->SetFixedWidth(25);
	m_pLevelControl->SetFixedHeight(20);
	m_pLevelControl->SetFixedXY(CPoint(40,110));
	m_pLevelControl->InitLevelControl();
	pParent->Add(m_pLevelControl);	
}


//��������
void CPlazaViewUserInfo::SetCustomAttribute(LPCTSTR pszName,LPCTSTR pszValue)
{
}

//λ����Ϣ
VOID CPlazaViewUserInfo::OnSize(UINT nType, INT cx, INT cy)
{
	__super::OnSize(nType, cx, cy);

	//�����ؼ�
	RectifyControl(cx,cy);

	return;
}

//������Ϣ
INT CPlazaViewUserInfo::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (__super::OnCreate(lpCreateStruct)==-1) return -1;

	//ע���¼�
	CPlatformEvent * pPlatformEvent=CPlatformEvent::GetInstance();
	if (pPlatformEvent!=NULL) pPlatformEvent->RegisterEventWnd(m_hWnd);

	CRect rctCreate(0,0,0,0);

	//��ȡ����
	CGlobalWebLink * pGlobalWebLink=CGlobalWebLink::GetInstance();
	//�����ַ
	TCHAR szBillUrl[256]=TEXT("");

	//1 ����ؼ�,����
	m_BrowerCtrlNotice.Create(NULL,NULL,WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN,rctCreate,this,IDC_BROWER_CTRL_NOTICE);

	_sntprintf(szBillUrl,CountArray(szBillUrl),TEXT("%s/News/adNewsList.aspx"),pGlobalWebLink->GetPlatformLink());
	m_BrowerCtrlNotice.Navigate(szBillUrl);
	m_BrowerCtrlNotice.ShowWindow(false);

	//2 ����ؼ�,�����Ƽ�
	m_BrowerCtrlHot.Create(NULL,NULL,WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN,rctCreate,this,IDC_BROWER_CTRL_HOT);

	//������
	_sntprintf(szBillUrl,CountArray(szBillUrl),TEXT("%s/ads/PlatformBottom.aspx"),pGlobalWebLink->GetPlatformLink());
	m_BrowerCtrlHot.Navigate(szBillUrl);
m_BrowerCtrlHot.ShowWindow(false);
	return 0;
}

//�����ؼ�
VOID CPlazaViewUserInfo::RectifyControl(INT nWidth, INT nHeight)
{
	if( nWidth==0 || nHeight==0) return;

	m_rctEncircle[0].left	= 0;
	m_rctEncircle[0].top	= 0;
	m_rctEncircle[0].right	= m_rctEncircle[0].left + nWidth;
	m_rctEncircle[0].bottom	= m_rctEncircle[0].top + nHeight*10.0/10-60;

	m_rctEncircle[1]		= m_rctEncircle[0];
	m_rctEncircle[1].top	= m_rctEncircle[0].bottom;
	m_rctEncircle[1].bottom	= nHeight;


	tagEncircleInfo EncircleResInfo[2];
	m_EncircleRes[0].GetEncircleInfo(EncircleResInfo[0]);
	m_EncircleRes[1].GetEncircleInfo(EncircleResInfo[1]);

	//�ƶ�׼��
	HDWP hDwp=BeginDeferWindowPos(64);
	UINT uFlags=SWP_NOACTIVATE|SWP_NOCOPYBITS|SWP_NOZORDER;

	//1 ����ؼ�,����
	const int nHeightWebCtrlNotice = m_rctEncircle[0].bottom - 275;
	DeferWindowPos(hDwp,m_BrowerCtrlNotice,NULL,
					m_rctEncircle[0].left+EncircleResInfo[0].nLBorder-13,
					m_rctEncircle[0].bottom - EncircleResInfo[0].nBBorder - nHeightWebCtrlNotice,
					m_rctEncircle[0].Width()-EncircleResInfo[0].nRBorder-EncircleResInfo[0].nLBorder+24,
					nHeightWebCtrlNotice,
					uFlags);	

	//2 ����ؼ�,�����Ƽ�
	DeferWindowPos(hDwp,m_BrowerCtrlHot,NULL,
					m_rctEncircle[1].left+EncircleResInfo[1].nLBorder,
					m_rctEncircle[1].top+EncircleResInfo[1].nTBorder,
					m_rctEncircle[1].Width()-EncircleResInfo[1].nRBorder-EncircleResInfo[1].nLBorder,
					m_rctEncircle[1].Height()-EncircleResInfo[1].nBBorder-EncircleResInfo[1].nTBorder,
					uFlags);	

	//��������
	LockWindowUpdate();
	EndDeferWindowPos(hDwp);
	UnlockWindowUpdate();

	//���½���
	RedrawWindow(NULL,NULL,RDW_ERASE|RDW_INVALIDATE);
	return;
}

//������Ϣ
VOID CPlazaViewUserInfo::UpdateUserInfo()
{
	
	//�û���Ϣ
	CGlobalUserInfo * pGlobalUserInfo=CGlobalUserInfo::GetInstance();
	tagGlobalUserData * pGlobalUserData=pGlobalUserInfo->GetGlobalUserData();

	//�û��ǳ�
	CControlUI * pControlUI = GetControlByName(szTextNickNameControlName);
	if(pControlUI)
	{
		pControlUI->SetText(pGlobalUserData->szNickName);
		pControlUI->SetToolTip(pGlobalUserData->szNickName);
	}

	//�û�Ԫ��
	pControlUI = GetControlByName(szTextGameIngotControlName);
	if(pControlUI)
	{
		TCHAR szUserGoldIngot[16]=TEXT("");
		SwitchScoreFormat(pGlobalUserData->lUserIngot,3L,TEXT("%I64d"),szUserGoldIngot,CountArray(szUserGoldIngot));
		pControlUI->SetText(szUserGoldIngot);
	}

	//�û���Ϸ��
	//pControlUI = GetControlByName(szTextGameBeanControlName);
	//if(pControlUI)
	//{
	//	TCHAR szUserScore[32]=TEXT("");
	//	SwitchScoreFormat(pGlobalUserData->dUserBeans,3L,TEXT("%0.2f"),szUserScore,CountArray(szUserScore));
	//	pControlUI->SetText(szUserScore);
	//}
	
	//�û�ID-20150811 
	pControlUI = GetControlByName(szTextTextGameIDName);
	if(pControlUI)
	{
		TCHAR szUserScore[64]=TEXT("");
		//SwitchScoreFormat((SCORE)pGlobalUserData->dwGameID,3L,TEXT("%ld"),szUserScore,CountArray(szUserScore));
		swprintf(szUserScore,L"%d",pGlobalUserData->dwGameID);//DWORDתΪTCHAR-20150812
		pControlUI->SetText(szUserScore);
	}

	//�û���Ϸ��
	pControlUI = GetControlByName(szTextGameScoreControlName);
	if(pControlUI)
	{
		TCHAR szUserScore[32]=TEXT("");
		SwitchScoreFormat(pGlobalUserData->lUserScore,3L,TEXT("%I64d"),szUserScore,CountArray(szUserScore));
		pControlUI->SetText(szUserScore);
	}

/*	//��Ա�ȼ�
	pControlUI = GetControlByName(szLabelLevelControlName);
	if(pControlUI)
	{
		pControlUI->SetBkImage(TEXT(""));
		if(pGlobalUserData->cbMemberOrder>0)
		{
			const TImageInfo * pImageInfo=m_PaintManager.GetImageEx(TEXT("file='IMAGE_MEMBER_LEVEL' restype='PNG'"));
			if(pImageInfo!=NULL)
			{
				//��������
				BYTE cbMemberOrder=pGlobalUserData->cbMemberOrder-1;
				CSize SizeMemberLevel(pImageInfo->nX/5,pImageInfo->nY);

				//�����ַ���
				CStdString strLevelImage;
				strLevelImage.SmallFormat(TEXT("file='IMAGE_MEMBER_LEVEL' restype='PNG' source='%d,%d,%d,%d'"),cbMemberOrder*SizeMemberLevel.cx,0,(cbMemberOrder+1)*SizeMemberLevel.cx,SizeMemberLevel.cy);

				//��ȡλ��
				CSize SizeXY(pControlUI->GetFixedXY());

				//���ÿؼ�
				pControlUI->SetBkImage(strLevelImage);
				pControlUI->SetFixedWidth(SizeMemberLevel.cx);
				pControlUI->SetFixedHeight(SizeMemberLevel.cy);
				pControlUI->SetPos(SizeXY.cx,SizeXY.cy);
			}
		}
	}
	*/

	//ˢ�½���
	//RedrawWindow(NULL,NULL,RDW_INVALIDATE|RDW_ERASE|RDW_UPDATENOW|RDW_ERASENOW);
}

//�����Ϣ
VOID CPlazaViewUserInfo::OnLButtonUp(UINT nFlags, CPoint MousePoint)
{
	__super::OnLButtonUp(nFlags,MousePoint);
/*
	if ((m_bHoverFace==true)&&(m_bClickFace==true))
	{
		//�ͷŲ���
		ReleaseCapture();

		//���ñ���
		m_bClickFace=false;

		//�ϴ�ͷ��
		if (m_rctFaceArea.PtInRect(MousePoint)==TRUE)
		{
			//��ʾ����
			CDlgCustomFace DlgCustomFace;
			DlgCustomFace.SetCustomFaceEvent(QUERY_OBJECT_PTR_INTERFACE(CPlatformFrame::GetInstance(),IUnknownEx));

			//��ʾ����
			DlgCustomFace.DoModal();
		}
	}
*/
	return;
}

//�����Ϣ
VOID CPlazaViewUserInfo::OnLButtonDown(UINT nFlags, CPoint MousePoint)
{
	__super::OnLButtonDown(nFlags,MousePoint);

	/*
	//���ý���
	SetFocus();

	//��������
	if ((m_bHoverFace==true)&&(m_bClickFace==false))
	{
		//����˻�
		SetCapture();

		//���ñ���
		m_bClickFace=true;
	}*/

	return;
}

//�����Ϣ
BOOL CPlazaViewUserInfo::OnSetCursor(CWnd * pWnd, UINT nHitTest, UINT uMessage)
{
	/*
	//��ȡ���
	CPoint MousePoint;
	GetCursorPos(&MousePoint);
	ScreenToClient(&MousePoint);

	//��������
	bool bMouseEvent=false;
	bool bRedrawWindow=false;

	//�����ж�
	if ((m_bHoverFace==false)&&(m_rctFaceArea.PtInRect(MousePoint)==TRUE))
	{
		//���ñ���
		bMouseEvent=true;
		bRedrawWindow=true;

		//���ñ���
		m_bHoverFace=true;
	}

	//�뿪�ж�
	if ((m_bHoverFace==true)&&(m_rctFaceArea.PtInRect(MousePoint)==FALSE))
	{
		//���ñ���
		bRedrawWindow=true;

		//���ñ���
		m_bHoverFace=false;
	}

	//ע���¼�
	if ((m_bMouseEvent==false)&&(bMouseEvent==true))
	{
		//���ñ���
		m_bMouseEvent=true;

		//��������
		TRACKMOUSEEVENT TrackMouseEvent;
		ZeroMemory(&TrackMouseEvent,sizeof(TrackMouseEvent));

		//ע����Ϣ
		TrackMouseEvent.hwndTrack=m_hWnd;
		TrackMouseEvent.dwFlags=TME_LEAVE;
		TrackMouseEvent.dwHoverTime=HOVER_DEFAULT;
		TrackMouseEvent.cbSize=sizeof(TrackMouseEvent);

		//ע���¼�
		_TrackMouseEvent(&TrackMouseEvent);
	}

	//���½���
	if (bRedrawWindow==true)
	{
		RedrawWindow(NULL,NULL,RDW_INVALIDATE|RDW_ERASE|RDW_UPDATENOW|RDW_ERASENOW);
	}

	//���ù��
	if (m_bHoverFace==true)
	{
		SetCursor(LoadCursor(AfxGetInstanceHandle(),MAKEINTRESOURCE(IDC_HAND_CUR)));
		return true;
	}
*/
	return __super::OnSetCursor(pWnd,nHitTest,uMessage);
}

//�����Ϣ
LRESULT CPlazaViewUserInfo::OnMouseLeave(WPARAM wParam, LPARAM lParam)
{
	//���ñ���
	m_bMouseEvent=false;

	//�뿪����
	if (m_bHoverFace==true)
	{
		//���ñ���
		m_bMouseEvent=false;

		//���½���
		RedrawWindow(NULL,NULL,RDW_INVALIDATE|RDW_ERASE|RDW_UPDATENOW|RDW_ERASENOW);
	}

	return 0;
}

//�¼���Ϣ
LRESULT CPlazaViewUserInfo::OnMessagePlatformEvent(WPARAM wParam, LPARAM lParam)
{
	CString strLog;

	switch (wParam)
	{
	case EVENT_USER_LOGON:			//��¼���
		{
			//���´���
			Invalidate();

			//������Ϣ
			UpdateUserInfo();

			//��־
			strLog.Format(_T("%s,%d,"), __FUNCTIONW__, __LINE__);
			g_FileLog.Write(strLog);

			return 0L;
		}
	case EVENT_USER_LOGOUT:			//ע���ɹ�
		{
			//���´���
			Invalidate();

			return 0L;
		}
	case EVENT_USER_INFO_UPDATE:	//���ϸ���
		{
			//������Ϣ
			UpdateUserInfo();

			//���Ը���
			m_pLevelControl->AttemptUpdateGrowLevel();

			return 0L;
		}
	case EVENT_USER_MOOR_MACHINE:	//�󶨻���
		{
			return 0L;
		}
	}

	return 0L;
}




//-----------------------------------------------
//					the end
//-----------------------------------------------
