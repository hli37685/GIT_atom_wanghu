#include "StdAfx.h"
#include "..\Resource.h"
#include "..\GlobalUnits.h"
#include "..\Define.h"
#include "PlazaViewTopBar.h"
#include "..\Dialog\DlgService.h"

//////////////////////////////////////////////////////////////////////////////////
//��ʶ����
#define IDC_PULICIZE_NOTICE			100								//����ؼ�
#define IDC_PULICIZE_MESSAGE		101								//����ؼ�
#define IDC_PULICIZE_AFFICEH		102								//����ؼ�

//////////////////////////////////////////////////////////////////////////////////

BEGIN_MESSAGE_MAP(CPlazaViewTopBar, CFGuiWnd)
	ON_WM_SIZE()
	ON_WM_CREATE()
END_MESSAGE_MAP()

//////////////////////////////////////////////////////////////////////////////////
//�ؼ�����
const TCHAR* const szButtonUserControlName		= TEXT("ButtonUSER");
const TCHAR* const szButtonBankControlName		= TEXT("ButtonBANK");
const TCHAR* const szButtonFillControlName		= TEXT("ButtonFill");
const TCHAR* const szButtonWXControlName	= TEXT("ButtonWX");
const TCHAR* const szButtonLOCKControlName	= TEXT("ButtonLOCK");
const TCHAR* const szButtonHomeControlName		= TEXT("ButtonHome");



//////////////////////////////////////////////////////////////////////////////////

//���캯��
CPlazaViewTopBar::CPlazaViewTopBar()
{
	//��ʶ����
	m_bCreateFlag=false;

	//���ñ���
	m_nHegihtADFrame = 285;
	m_nSeparateRatio = 30;

	//��ܻ���
	tagEncircleResource	EncircleRes;
	EncircleRes.pszImageTL	= MAKEINTRESOURCE(IDB_PLAZA_VIEW_TOP_BAR_TL);
	EncircleRes.pszImageTM	= MAKEINTRESOURCE(IDB_PLAZA_VIEW_TOP_BAR_TM);
	EncircleRes.pszImageTR	= MAKEINTRESOURCE(IDB_PLAZA_VIEW_TOP_BAR_TR);
	EncircleRes.pszImageML	= MAKEINTRESOURCE(IDB_PLAZA_VIEW_TOP_BAR_ML);
	EncircleRes.pszImageMR	= MAKEINTRESOURCE(IDB_PLAZA_VIEW_TOP_BAR_MR);
	EncircleRes.pszImageBL	= MAKEINTRESOURCE(IDB_PLAZA_VIEW_TOP_BAR_BL);
	EncircleRes.pszImageBM	= MAKEINTRESOURCE(IDB_PLAZA_VIEW_TOP_BAR_BM);
	EncircleRes.pszImageBR	= MAKEINTRESOURCE(IDB_PLAZA_VIEW_TOP_BAR_BR);

	m_EncircleRes.InitEncircleResource(EncircleRes,AfxGetInstanceHandle());

	return;
}

//��������
CPlazaViewTopBar::~CPlazaViewTopBar()
{
}

//��ʼ�滭
void CPlazaViewTopBar::OnBeginPaintWindow(HDC hDC)
{
	//��ȡ����
	CDC * pDC = CDC::FromHandle(hDC);

	//��ȡ����
	CRect rctClient;
	GetClientRect(&rctClient);

	//��䱳��
	pDC->FillSolidRect(rctClient,RGB(40,144,216));
	//pDC->FillSolidRect(&rctClient,CLR_DEBUG);

	//�滭����		
	m_EncircleRes.DrawEncircleFrame(pDC,rctClient);
	
	////��Ϣ����
	//CPngImage ImageTitleSM;
	//ImageTitleSM.LoadImage(AfxGetInstanceHandle(),TEXT("TITLE_SYSTEM_MESSAGE"));
	//ImageTitleSM.DrawImage(pDC,m_rcAfficheArea[0].left+(m_rcAfficheArea[0].Width()-ImageTitleSM.GetWidth())/2,m_rcAfficheArea[0].top+8);

	////�������
	//CPngImage ImageTitleAffiche;
	//ImageTitleAffiche.LoadImage(AfxGetInstanceHandle(),TEXT("TITLE_AFFICHE"));
	//ImageTitleAffiche.DrawImage(pDC,m_rcAfficheArea[0].left+(m_rcAfficheArea[1].Width()-ImageTitleAffiche.GetWidth())/2,m_rcAfficheArea[1].top+3);
}

//��Ϣ����
void CPlazaViewTopBar::Notify(TNotifyUI &  msg)
{
	//��ȡ����
	CControlUI * pControlUI = msg.pSender;

	//����¼�
	if (lstrcmp(msg.sType, TEXT("click")) == 0)
	{
		if(lstrcmp(pControlUI->GetName(), szButtonUserControlName)==0) 
		{
			//��������
			CDlgService DlgService;
			DlgService.DoModal();

			return;
		}//����
		else if(lstrcmp(pControlUI->GetName(), szButtonLOCKControlName)==0)
		{
			ASSERT(CGlobalUnits::GetInstance());
			CGlobalUnits::GetInstance()->PerformShowLockMachine();

			return;
		}//΢��
		else if(lstrcmp(pControlUI->GetName(), szButtonWXControlName)==0)
		{
			ASSERT(CGlobalUnits::GetInstance());
			CGlobalUnits::GetInstance()->PerformShowBindWX();			

			return;
		}
		//��ҳ
		if(lstrcmp(pControlUI->GetName(), szButtonHomeControlName)==0) 
		{
			this->OpenOuterBrowser(pControlUI);
			return ;
		}	//��ֵ
		else if(lstrcmp(pControlUI->GetName(), szButtonFillControlName)==0) 
		{
			this->OpenOuterBrowser(pControlUI);
			return ;
		}
		
		//���չ�
		else if(lstrcmp(pControlUI->GetName(), szButtonBankControlName)==0) 
		{
			ASSERT(CGlobalUnits::GetInstance());
			CGlobalUnits::GetInstance()->PerformShowInsure();			
			return ;
		}
		/*//���
		else if(lstrcmp(pControlUI->GetName(), szButtonPresentControlName)==0) 
		{
			this->OpenOuterBrowser(pControlUI);
			return ;
		}
		//�ͷ�
		else if(lstrcmp(pControlUI->GetName(), szButtonServiceControlName)==0) 
		{
			this->OpenOuterBrowser(pControlUI);
			return ;
		}*/
	

	}
}

//��������
void CPlazaViewTopBar::SetCustomAttribute(LPCTSTR pszName,LPCTSTR pszValue)
{
	//��������
	LPTSTR pstr = NULL;
	if( lstrcmp(pszName,TEXT("heightadframe")) ==0 )
	{
		m_nHegihtADFrame = _ttoi(pszValue);
	}
	else if( lstrcmp(pszName,TEXT("separateratio")) ==0 )
	{
		m_nSeparateRatio = __max(_ttoi(pszValue),30);
		m_nSeparateRatio = __min(_ttoi(pszValue),50);
	}
}

//�����ؼ�
void CPlazaViewTopBar::RectifyControl(INT nWidth,INT nHeight)
{	
	if( m_bCreateFlag==false ) return;
	if( nWidth==0 || nHeight==0) return;

	//��������

	//������Ϣ
	tagEncircleInfo EncircleResInfo;
	m_EncircleRes.GetEncircleInfo(EncircleResInfo);

	const int nButtonY = 16;
	const int nButtonX = 150;

	//��ť
	CControlUI * pControlUI = NULL;

	const TCHAR *szButtonName_[] =
	{
		szButtonHomeControlName,
			 szButtonLOCKControlName,
			  szButtonWXControlName,
			   szButtonFillControlName,
			     szButtonBankControlName,
		szButtonUserControlName
      
       
       
       
           
	};

	for(int i=0; i<sizeof(szButtonName_)/sizeof(szButtonName_[0]); i++)
	{
		pControlUI = GetControlByName(szButtonName_[i]);
		if(!pControlUI) continue;

		CPoint ptControl;
		ptControl.x = nWidth - 120 - i*100;
		ptControl.y = nButtonY;
		pControlUI->SetPos(ptControl.x,ptControl.y);
	}

	//�ƶ�׼��
	HDWP hDwp=BeginDeferWindowPos(64);
	UINT uFlags=SWP_NOACTIVATE|SWP_NOCOPYBITS|SWP_NOZORDER;

	//��������
	LockWindowUpdate();
	EndDeferWindowPos(hDwp);
	UnlockWindowUpdate();

	//���½���
	RedrawWindow(NULL,NULL,RDW_ERASE|RDW_INVALIDATE);
}

//������Ϣ
int CPlazaViewTopBar::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFGuiWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

	return 0;
}

//λ����Ϣ
void CPlazaViewTopBar::OnSize(UINT nType, int cx, int cy)
{
	__super::OnSize(nType, cx, cy);

	//�����ؼ�
	RectifyControl(cx,cy);
}


//���ⲿ�����
bool	CPlazaViewTopBar::OpenOuterBrowser(CControlUI *pControlUI)
{
	if(!pControlUI) return false;

	//��������
	ASSERT(CParameterGlobal::GetInstance()!=NULL);
	CParameterGlobal * pParameterGlobal=CParameterGlobal::GetInstance();

	//��ȡ����
	ASSERT(CGlobalWebLink::GetInstance()!=NULL);
	CGlobalWebLink * pGlobalWebLink=CGlobalWebLink::GetInstance();

	//�����ַ
	TCHAR szNavigation[256]=TEXT("");
	_sntprintf(szNavigation,CountArray(szNavigation),TEXT("%s/%sNavigation%ld.aspx"),pGlobalWebLink->GetPlatformLink(),pGlobalWebLink->GetValidateLink(),pControlUI->GetTag());

	//��ҳ��
	ShellExecute(NULL,TEXT("OPEN"),szNavigation,NULL,NULL,SW_NORMAL);

	return true;
}



//-----------------------------------------------
//					the end
//-----------------------------------------------

