#include "StdAfx.h"
#include "Resource.h"
#include "PlatformFrame.h"
#include "PlazaViewGame.h"
#include "PlazaViewGameKind.h"
#include "..\Define.h"
#include "..\FileIO\MyFileLog.h"

#define IDI_UPDATE_GIF			203									//����


//��ť�ؼ�
const TCHAR* const szButtonGameKindControlName	= TEXT("ButtonGameKind");
const TCHAR* const szButtonLeftControlName		= TEXT("ButtonLeft");
const TCHAR* const szButtonRightControlName		= TEXT("ButtonRight");


BEGIN_MESSAGE_MAP(CPlazaViewGameKind, CFGuiWnd)
	ON_WM_SIZE()
	ON_WM_TIMER()
END_MESSAGE_MAP()



//���캯��
CPlazaViewGameKind::CPlazaViewGameKind()
{
	//�����Ϣ
	m_wActiveKindID=INVALID_WORD;

	//��ҳ����
	m_nXPitch=0;
	m_wItemStartIndex=0;
	m_wPageItemCount=0;

	//������Ϣ
	m_SizeButton.SetSize(133,107);
	m_SizeBorder.SetSize(35,35);
	m_SizeTypeArea.SetSize(1,7);

	//����Ŀ¼
	TCHAR szDirectory[MAX_PATH]=TEXT("");
	CWHService::GetWorkDirectory(szDirectory,CountArray(szDirectory));

	//��ܻ���
	tagEncircleResource	EncircleRes;

	EncircleRes.pszImageTL	= MAKEINTRESOURCE(IDB_PLAZA_VIEW_GAME_TYPE_TL);
	EncircleRes.pszImageTM	= MAKEINTRESOURCE(IDB_PLAZA_VIEW_GAME_TYPE_TM);
	EncircleRes.pszImageTR	= MAKEINTRESOURCE(IDB_PLAZA_VIEW_GAME_TYPE_TR);
	EncircleRes.pszImageML	= MAKEINTRESOURCE(IDB_PLAZA_VIEW_GAME_TYPE_ML);
	EncircleRes.pszImageMR	= MAKEINTRESOURCE(IDB_PLAZA_VIEW_GAME_TYPE_MR);
	EncircleRes.pszImageBL	= MAKEINTRESOURCE(IDB_PLAZA_VIEW_GAME_TYPE_BL);
	EncircleRes.pszImageBM	= MAKEINTRESOURCE(IDB_PLAZA_VIEW_GAME_TYPE_BM);
	EncircleRes.pszImageBR	= MAKEINTRESOURCE(IDB_PLAZA_VIEW_GAME_TYPE_BR);
	m_EncircleRes.InitEncircleResource(EncircleRes,AfxGetInstanceHandle());

	m_pGameKindItem = NULL;

	m_nXHot =0;
	return;
}

//��������
CPlazaViewGameKind::~CPlazaViewGameKind()
{
}

//��ʼ�滭
void CPlazaViewGameKind::OnBeginPaintWindow(HDC hDC)
{
	
	//��������
	CDC * pDC = CDC::FromHandle(hDC);

	//��ȡ���
	HINSTANCE hResInstance = AfxGetResourceHandle();

	//��ȡλ��
	CRect rctClient;
	GetClientRect(&rctClient);

	//��䱳��
	pDC->FillSolidRect(&rctClient,RGB(20,85,146));
	//pDC->FillSolidRect(&rctClient,CLR_DEBUG);

	//�滭����		
	m_EncircleRes.DrawEncircleFrame(pDC,rctClient);


		if (m_wActiveKindID!=INVALID_WORD)
		{
		CRect rctClient;
	GetClientRect(&rctClient);
	
	CString strLog;

	//������Ϣ
	tagEncircleInfo EncircleResInfo;
	m_EncircleRes.GetEncircleInfo(EncircleResInfo);

	//��������
	const int nXSpace = EncircleResInfo.nLBorder + (rctClient.Width()-EncircleResInfo.nLBorder-EncircleResInfo.nRBorder - m_SizeButton.cx)/2;
	
	const INT nItemCount = (INT)m_GameKindItemArray.GetCount();        

	//��������
	CControlUI *pControlUI=NULL;
	TCHAR szControlName[64]=TEXT("");			

	int nValidCnt = 0;
	
	for(INT i=0; i<nItemCount; i++)
	{
		if(!m_GameKindItemArray[i]) continue;
		const WORD wKindID = m_GameKindItemArray[i]->m_GameKind.wKindID;
	
		//����ؼ���
		_sntprintf(szControlName,CountArray(szControlName),TEXT("%s%d"),szButtonGameKindControlName,wKindID);
		pControlUI = GetControlByName(szControlName);

		nValidCnt++;

		if (m_wActiveKindID!=wKindID)continue;

		//if (wKindID==0)continue;

	TCHAR szBtnName[64]=TEXT("");	
	
	
		_sntprintf(szBtnName,CountArray(szBtnName),TEXT("BTN_GAME_KIND_%d"),wKindID);

		//������Դ
	CPngImage ImageBack;
	ImageBack.LoadImage(GetModuleHandle(PLATFORM_RESOURCE_DLL_NAME),szBtnName);


	ImageBack.DrawImage(pDC,nXSpace+2,
							EncircleResInfo.nTBorder+(nValidCnt-1)*(m_SizeButton.cy+m_SizeItemSpace.cy),ImageBack.GetWidth()/5,ImageBack.GetHeight(),ImageBack.GetWidth()/5*3,0);
		

	}


		}


	return;
}

//��������
void CPlazaViewGameKind::SetCustomAttribute(LPCTSTR pszName,LPCTSTR pszValue)
{
	//��������
	LPTSTR pstr = NULL;
	if( lstrcmp(pszName,TEXT("sizebutton")) ==0 )
	{
		m_SizeButton.cx = _tcstol(pszValue, &pstr, 10);
		m_SizeButton.cy = _tcstol(pstr + 1, &pstr, 10);
	}
	else if(lstrcmp(pszName,TEXT("sizeborder")) ==0 )
	{
		m_SizeBorder.cx = _tcstol(pszValue, &pstr, 10);
		m_SizeBorder.cy = _tcstol(pstr + 1, &pstr, 10);
	}
	else if(lstrcmp(pszName,TEXT("sizetypearea")) ==0 )
	{		
		m_SizeTypeArea.cx = _tcstol(pszValue, &pstr, 10);
		m_SizeTypeArea.cy = _tcstol(pstr + 1, &pstr, 10);
	}
	else if(lstrcmp(pszName,TEXT("sizeitemspace")) ==0 )
	{
		m_SizeItemSpace.cx = _tcstol(pszValue, &pstr, 10);
		m_SizeItemSpace.cy = _tcstol(pstr + 1, &pstr, 10);		
	}
}

//��Ϣ����
void CPlazaViewGameKind::Notify(TNotifyUI &  msg)
{
	//��ȡ����
	CControlUI * pControlUI = msg.pSender;

	//����¼�
	if (lstrcmp(msg.sType, TEXT("click")) == 0)
	{
		if(lstrcmp(pControlUI->GetName(), szButtonLeftControlName)==0) 
		{
			//��������
			if(m_wItemStartIndex>0) --m_wItemStartIndex;

			//�����ؼ�
			RectifyControl(true);	

			return;
		}
		else if(lstrcmp(pControlUI->GetName(), szButtonRightControlName)==0)
		{
			//��������
			//if((m_wItemStartIndex+m_wPageItemCount)<m_GameTypeItemArray.GetCount()) ++m_wItemStartIndex;

			//�����ؼ�
			RectifyControl(true);

			return;
		}
		//��ϷKind
		else if(_tcsstr(pControlUI->GetName(),szButtonGameKindControlName)!=NULL)
		{
			//����У��
			const WORD wControlTag = (WORD)pControlUI->GetTag();


            //��������
			BOOL bResetPageIndex=m_wActiveKindID!=wControlTag;
			m_wActiveKindID = wControlTag;

		pControlUI->SetVisible(false);
		


this->RectifyControl();
RedrawWindow(NULL,NULL,RDW_ERASE|RDW_INVALIDATE);


			//��������
			ASSERT(CPlatformFrame::GetInstance()!=NULL);
			CPlazaViewGame * pPlazaViewItem = CPlatformFrame::GetInstance()->GetPlazaViewGame();

			//��ʾ��ͼ
		//	pPlazaViewItem->ShowServerItemView(wControlTag,bResetPageIndex,false);
			return;
		}
	}
}

//��ʼ�ؼ�
void CPlazaViewGameKind::InitControlUI()
{
	//SetTimer(IDI_UPDATE_GIF,100,NULL);
	
	//�������Ұ�ť
	//��ʱ����,������Ҫ����,����Ϸ��������֮��
	CControlUI * pControlUI = GetControlByName(szButtonLeftControlName);
	if(pControlUI) pControlUI->SetVisible(false);

	pControlUI = GetControlByName(szButtonRightControlName);
	if(pControlUI) pControlUI->SetVisible(false);



	if(!m_pGameKindItem)
	{
		CString strLog;

	//��־
	strLog.Format(_T("11111   %s,%d"), 
				__FUNCTIONW__, __LINE__
			);
	g_FileLog.Write(strLog);


		m_pGameKindItem = new CGameKindItem;
		memset(m_pGameKindItem,0,sizeof(CGameKindItem));

		
		if (m_pGameKindItem->m_GameKind.wKindID!=0)
		this->InsertGameKind(m_pGameKindItem);
	}else
	{
		CString strLog;

	//��־
	strLog.Format(_T("22222   %s,%d"), 
				__FUNCTIONW__, __LINE__
			);
	g_FileLog.Write(strLog);


	}
}

//�����ؼ�
VOID CPlazaViewGameKind::RectifyControl(bool bRectifyGameView)
{
	CRect rctClient;
	GetClientRect(&rctClient);
	RectifyControl(rctClient.Width(),rctClient.Height(),bRectifyGameView);
}

//�����ؼ�
VOID CPlazaViewGameKind::RectifyControl(INT nWidth,INT nHeight,bool bRectifyGameView)
{
	//����У��
	if(nWidth==0 || nHeight==0) return;
	if(m_GameKindItemArray.GetCount() <= 0) return ;

	CString strLog;

	//������Ϣ
	tagEncircleInfo EncircleResInfo;
	m_EncircleRes.GetEncircleInfo(EncircleResInfo);

	//��������
	const int nXSpace = EncircleResInfo.nLBorder + (nWidth-EncircleResInfo.nLBorder-EncircleResInfo.nRBorder - m_SizeButton.cx)/2;
	
	const INT nItemCount = (INT)m_GameKindItemArray.GetCount();        

	//��������
	CControlUI *pControlUI=NULL;
	TCHAR szControlName[64]=TEXT("");			

	int nValidCnt = 0;
	
	for(INT i=0; i<nItemCount; i++)
	{
		if(!m_GameKindItemArray[i]) continue;
		const WORD wKindID = m_GameKindItemArray[i]->m_GameKind.wKindID;
	
		//����ؼ���
		_sntprintf(szControlName,CountArray(szControlName),TEXT("%s%d"),szButtonGameKindControlName,wKindID);
		pControlUI = GetControlByName(szControlName);
		if(!pControlUI)
		{
			//��־
			strLog.Format(_T("%s,%d,wKindID:%d,ʧ��,"), 
						__FUNCTIONW__, __LINE__,
						wKindID);
			g_FileLog.Write(strLog);

			continue;
		}

		nValidCnt++;

		//��־
		strLog.Format(_T("%s,%d,wKindID:%d,nValidCnt:%d,"), 
					__FUNCTIONW__, __LINE__,
					wKindID,
					nValidCnt);
		g_FileLog.Write(strLog);

		//���ÿؼ�
	if (m_wActiveKindID==wKindID)continue;

		pControlUI->SetVisible(true);
		pControlUI->SetTag(wKindID);
		pControlUI->SetPos(nXSpace+2,
							EncircleResInfo.nTBorder+(nValidCnt-1)*(m_SizeButton.cy+m_SizeItemSpace.cy));

		
		
		
	}




	////������ͼ
	//if(bRectifyGameView==true)
	//{
	//	//��ȡ����
	//	ASSERT(CPlatformFrame::GetInstance()!=NULL);
	//	CPlazaViewGame * pPlazaViewItem = CPlatformFrame::GetInstance()->GetPlazaViewGame();

	//	//��������
	//	bool bResetPageIndex=true;

	//	//��������
	//	if(m_wActiveKindID<m_wItemStartIndex) 
	//	{
	//		m_wActiveKindID=m_wItemStartIndex;							
	//	}
	//	else if(m_wActiveKindID>m_wItemStartIndex+m_wPageItemCount-1)
	//	{
	//		m_wActiveKindID=m_wItemStartIndex+m_wPageItemCount-1;				
	//	}
	//	else bResetPageIndex=false;
	//	
	//	//��ʾ��ͼ
	//	pPlazaViewItem->ShowKindItemView(m_wActiveKindID,bResetPageIndex);
	//}
}

VOID CPlazaViewGameKind::InsertGameKind(CGameKindItem * pGameKindItem)
{
	//Ч�����
	if (pGameKindItem==NULL) return;

	CString strLog;

	//��־
	strLog.Format(_T("%s,%d,wSortID:%d,wKindID:%d,szKindName:%s,"), 
				__FUNCTIONW__, __LINE__,
				pGameKindItem->m_GameKind.wSortID,
				pGameKindItem->m_GameKind.wKindID,
				pGameKindItem->m_GameKind.szKindName);
	g_FileLog.Write(strLog);


	//��������
	for (INT i=0;i<m_GameKindItemArray.GetCount();i++)
	{
		//��ȡ����
		ASSERT(m_GameKindItemArray[i]!=NULL);
		CGameKindItem * pGameKindTemp=m_GameKindItemArray[i];

		//�����ж�
		if (pGameKindItem->m_GameKind.wSortID<=pGameKindTemp->m_GameKind.wSortID)
		{
			m_GameKindItemArray.InsertAt(i,pGameKindItem);
			break;
		}
	}

	//Ĭ�ϲ���
	if (i==m_GameKindItemArray.GetCount())
	{		
		m_GameKindItemArray.Add(pGameKindItem);
	}

	//��������
	//if (m_wKindActive==INVALID_WORD) m_wKindActive=RECOM_TYPE_ID;

	//�����ؼ�
	this->RectifyControl();

	return;

}

//������ͼ
VOID CPlazaViewGameKind::ResetGameKindView()
{
	//�����Ϣ
	m_wActiveKindID=RECOM_TYPE_ID;
		//�����ؼ�
	this->RectifyControl();//��ֹ�л��˺ŵ�ʱ����һ���˵�����ʾ
//RedrawWindow(NULL,NULL,RDW_ERASE|RDW_INVALIDATE);


}

//��������
CRect CPlazaViewGameKind::GetSelectedKindRect()
{
	//��������
	CRect rcKindWindowRect(0,0,0,0);

	//��������
	TCHAR szControlName[64]=TEXT("");
	_sntprintf(szControlName,CountArray(szControlName),TEXT("%s%d"),szButtonGameKindControlName,m_wActiveKindID);

	//���Ҷ���
	CControlUI * pControlUI = GetControlByName(szControlName);
	if(pControlUI!=NULL)
	{
		rcKindWindowRect = pControlUI->GetPos();
		ClientToScreen(&rcKindWindowRect);
	}

	return rcKindWindowRect;
}

//��������
WORD CPlazaViewGameKind::GetKindItemIndex(WORD wKindID)
{
	//��������
	for (INT_PTR i=0;i<m_GameKindItemArray.GetCount();i++)
	{
		//��ȡ����
		ASSERT(m_GameKindItemArray[i]!=NULL);
		CGameKindItem * pGameKindItem=m_GameKindItemArray[i];

		//��ʶ�ж�
		if (pGameKindItem->m_GameKind.wKindID==wKindID)
		{
			return (WORD)i;
		}
	}

	return INVALID_WORD;
}

//�ߴ���Ϣ
VOID CPlazaViewGameKind::OnSize(UINT nType, int cx, int cy)
{
	__super::OnSize(nType, cx, cy);

	//�����ؼ�
	RectifyControl(cx,cy);
}

VOID CPlazaViewGameKind::OnTimer(UINT nIDEvent)
{
	if(nIDEvent==IDI_UPDATE_GIF)
	{
		
	}
	
	__super::OnTimer(nIDEvent);
}

//////////////////////////////////////////////////////////////////////////////////


