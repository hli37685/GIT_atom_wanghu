//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by GameProperty.rc
//
#define IDC_EXPRESSION                  1047
#define IDC_COLOR_SET                   1049
#define IDC_NICK_NAME                   2000
#define IDC_PROPERTY_COUNT              2005
#define IDC_HAND_CUR                    2006
#define IDC_PROPERTY_NAME               2007
#define IDC_PROPERTY_DESCRIBE           2008
#define IDD_DLG_PROPERTY                2008
#define IDC_PROPERTY_GOLD               2009
#define IDC_PAY_BY_SCORE                2010
#define IDC_PAY_BY_INSURE               2011
#define IDB_BITMAP1                     2011
#define IDC_MAX_BUYCOUNT                2012
#define IDC_RADIO_TRUMPET               2013
#define IDB_BT_LEFT                     2014
#define IDC_RADIO_TYPHON                2014
#define IDB_BT_RIGHT                    2015
#define IDC_STATIC_NAME                 2015
#define IDB_BT_COLOR_SET                2016
#define IDC_STATIC_PRICE                2016
#define IDB_BT_EXPRESSION               2017
#define IDC_STATIC_COUNT                2017
#define IDC_InputChat                   8013
#define IDC_PROPERTY_INFO               8019
#define IDD_BUGLE                       8098
#define IDD_TRUMPET                     8098
#define IDD_DLG_TRUMPET                 8098

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        2018
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         2018
#define _APS_NEXT_SYMED_VALUE           2000
#endif
#endif
