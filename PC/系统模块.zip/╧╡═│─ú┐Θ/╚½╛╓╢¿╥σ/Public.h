#pragma once


#define __STR2WSTR(str) 	L##str
#define _STR2WSTR(str) 		__STR2WSTR(str)
#define __FUNCTIONW__ 		_STR2WSTR(__FUNCTION__)

#define	FILE_LOG_FOLDER		_T("Log")
#define CONFIG_FOLDER		_T("Config")